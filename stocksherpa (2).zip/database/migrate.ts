import {closeDatabase, getDatabase} from './connection.ts';
import {runMigrations} from './migrations.ts';

const db = getDatabase();
const applied = runMigrations(db);
console.log(
  `[StockSherpa DB] Migrations applied: ${applied.length > 0 ? applied.join(', ') : 'none (up to date)'}.`
);
closeDatabase();
