import type Database from 'better-sqlite3';

interface Migration {
  version: number;
  name: string;
  sql: string;
}

const MIGRATIONS: Migration[] = [
  {
    version: 1,
    name: '001_initial_schema',
    sql: `
      CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        description TEXT
      );

      CREATE TABLE IF NOT EXISTS wholesalers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        contact_person TEXT,
        notes TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        sku TEXT NOT NULL UNIQUE,
        barcode TEXT UNIQUE,
        category_id INTEGER NOT NULL,
        wholesaler_id INTEGER,
        cost_price REAL NOT NULL CHECK (cost_price >= 0),
        selling_price REAL NOT NULL CHECK (selling_price >= 0),
        current_qty INTEGER NOT NULL DEFAULT 0 CHECK (current_qty >= 0),
        min_stock_threshold INTEGER NOT NULL DEFAULT 5 CHECK (min_stock_threshold >= 0),
        reorder_qty INTEGER NOT NULL DEFAULT 10 CHECK (reorder_qty >= 1),
        unit_label TEXT NOT NULL DEFAULT 'units',
        reorder_unit_label TEXT NOT NULL DEFAULT 'units',
        reorder_unit_cost REAL,
        avg_daily_demand REAL NOT NULL DEFAULT 1 CHECK (avg_daily_demand >= 0),
        lead_time_days INTEGER NOT NULL DEFAULT 2 CHECK (lead_time_days >= 0),
        safety_stock INTEGER NOT NULL DEFAULT 2 CHECK (safety_stock >= 0),
        expiry_date TEXT,
        is_demo INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
        FOREIGN KEY (wholesaler_id) REFERENCES wholesalers(id) ON DELETE SET NULL
      );

      CREATE INDEX IF NOT EXISTS idx_products_sku ON products(sku);
      CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
      CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
      CREATE INDEX IF NOT EXISTS idx_products_wholesaler ON products(wholesaler_id);
      CREATE INDEX IF NOT EXISTS idx_products_expiry ON products(expiry_date);

      CREATE TABLE IF NOT EXISTS stock_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        prev_qty INTEGER NOT NULL,
        new_qty INTEGER NOT NULL,
        qty_changed INTEGER NOT NULL,
        transaction_type TEXT NOT NULL CHECK (
          transaction_type IN ('SALE', 'RESTOCK', 'ADJUSTMENT', 'INITIAL', 'RETURN', 'SPOILAGE')
        ),
        operation_id TEXT,
        notes TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
      );

      CREATE UNIQUE INDEX IF NOT EXISTS idx_stock_logs_operation_id
        ON stock_logs(operation_id)
        WHERE operation_id IS NOT NULL;

      CREATE INDEX IF NOT EXISTS idx_stock_logs_product_date
        ON stock_logs(product_id, created_at DESC);

      CREATE TABLE IF NOT EXISTS store_profile (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        shop_name TEXT NOT NULL,
        owner_name TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        gstin TEXT,
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS purchase_orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        wholesaler_id INTEGER,
        wholesaler_name TEXT NOT NULL,
        wholesaler_phone TEXT NOT NULL,
        message_text TEXT NOT NULL,
        total_estimated_cost REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'DISPATCHED')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (wholesaler_id) REFERENCES wholesalers(id) ON DELETE SET NULL
      );

      CREATE TABLE IF NOT EXISTS purchase_order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        purchase_order_id INTEGER NOT NULL,
        product_id INTEGER,
        product_name TEXT NOT NULL,
        sku TEXT NOT NULL,
        qty_ordered INTEGER NOT NULL,
        unit_label TEXT NOT NULL,
        estimated_cost REAL NOT NULL,
        FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
      );
    `,
  },
];

export function runMigrations(db: Database.Database): number[] {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const appliedRows = db
    .prepare('SELECT version FROM schema_migrations')
    .all() as Array<{version: number}>;
  const appliedSet = new Set(appliedRows.map((r) => r.version));

  const newlyApplied: number[] = [];

  for (const migration of MIGRATIONS) {
    if (appliedSet.has(migration.version)) {
      continue;
    }
    const applyTx = db.transaction(() => {
      db.exec(migration.sql);
      db.prepare(
        'INSERT INTO schema_migrations (version, name) VALUES (?, ?)'
      ).run(migration.version, migration.name);
    });
    applyTx();
    newlyApplied.push(migration.version);
  }

  return newlyApplied;
}
