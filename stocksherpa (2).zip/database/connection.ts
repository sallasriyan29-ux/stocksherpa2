import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

let singletonDb: Database.Database | null = null;

export function createDatabaseConnection(dbPath?: string): Database.Database {
  const targetPath =
    dbPath ?? process.env.DATABASE_PATH ?? './database/stocksherpa.db';

  if (targetPath !== ':memory:') {
    const resolvedDir = path.dirname(path.resolve(targetPath));
    if (!fs.existsSync(resolvedDir)) {
      fs.mkdirSync(resolvedDir, {recursive: true});
    }
  }

  const db = new Database(targetPath);
  db.pragma('foreign_keys = ON');
  if (targetPath !== ':memory:') {
    db.pragma('journal_mode = WAL');
  }
  return db;
}

export function getDatabase(): Database.Database {
  if (!singletonDb) {
    singletonDb = createDatabaseConnection();
  }
  return singletonDb;
}

export function closeDatabase(): void {
  if (singletonDb) {
    singletonDb.close();
    singletonDb = null;
  }
}
