import {closeDatabase, getDatabase} from './connection.ts';
import {runMigrations} from './migrations.ts';
import {seedInitialDatabase} from './seedData.ts';

const db = getDatabase();
const applied = runMigrations(db);
const seeded = seedInitialDatabase(db);

console.log(
  `[StockSherpa DB] Migrations applied: ${applied.length > 0 ? applied.join(', ') : 'none (up to date)'}.`
);
console.log(
  `[StockSherpa DB] Initial demonstration seed: ${seeded ? '45 products seeded (Rs 84,000).' : 'already populated.'}`
);

closeDatabase();
