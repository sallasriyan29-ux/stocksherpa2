export type StockStatus = 'IN_STOCK' | 'LOW_STOCK' | 'OUT_OF_STOCK';

export type ExpiryStatus =
  | 'NONE'
  | 'EXPIRED'
  | 'EXPIRING_7'
  | 'EXPIRING_15'
  | 'EXPIRING_30'
  | 'HEALTHY';

export type TransactionType =
  | 'SALE'
  | 'RESTOCK'
  | 'ADJUSTMENT'
  | 'INITIAL'
  | 'RETURN'
  | 'SPOILAGE';

export interface Category {
  id: number;
  name: string;
  description: string | null;
  productCount?: number;
}

export interface Wholesaler {
  id: number;
  name: string;
  phone: string;
  contactPerson: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface StoreProfile {
  id: number;
  shopName: string;
  ownerName: string;
  phone: string;
  address: string;
  gstin: string | null;
  updatedAt: string;
}

export interface Product {
  id: number;
  name: string;
  sku: string;
  barcode: string | null;
  categoryId: number;
  categoryName: string;
  wholesalerId: number | null;
  wholesalerName: string | null;
  wholesalerPhone: string | null;
  costPrice: number;
  sellingPrice: number;
  currentQty: number;
  minStockThreshold: number;
  reorderQty: number;
  unitLabel: string;
  reorderUnitLabel: string;
  reorderUnitCost: number | null;
  avgDailyDemand: number;
  leadTimeDays: number;
  safetyStock: number;
  expiryDate: string | null;
  isDemo: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ProductDTO extends Product {
  stockStatus: StockStatus;
  expiryStatus: ExpiryStatus;
  daysUntilExpiry: number | null;
  reorderPoint: number;
  needsReorder: boolean;
  suggestedReorderQty: number;
  inventoryValue: number;
  retailValue: number;
}

export interface ProductInput {
  name: string;
  sku: string;
  barcode?: string | null;
  categoryId: number;
  wholesalerId?: number | null;
  costPrice: number;
  sellingPrice: number;
  currentQty: number;
  minStockThreshold: number;
  reorderQty: number;
  unitLabel?: string;
  reorderUnitLabel?: string;
  reorderUnitCost?: number | null;
  avgDailyDemand?: number;
  leadTimeDays?: number;
  safetyStock?: number;
  expiryDate?: string | null;
}

export interface StockLog {
  id: number;
  productId: number;
  productName?: string;
  sku?: string;
  unitLabel?: string;
  prevQty: number;
  newQty: number;
  qtyChanged: number;
  transactionType: TransactionType;
  operationId: string | null;
  notes: string | null;
  createdAt: string;
}

export interface DashboardSummary {
  totalProducts: number;
  totalInventoryQty: number;
  inventoryValueAtCost: number;
  expectedRetailTurnover: number;
  expectedGrossProfit: number;
  grossProfitMarginPct: number;
  inventoryTurnoverRatio: number | null;
  totalSalesCogs: number;
  lowStockCount: number;
  outOfStockCount: number;
  expiringCount: number;
  expiredCount: number;
  recentActivities: StockLog[];
}

export interface ReorderItem {
  productId: number;
  productName: string;
  sku: string;
  categoryName: string;
  currentQty: number;
  unitLabel: string;
  minStockThreshold: number;
  reorderPoint: number;
  suggestedReorderQty: number;
  reorderUnitLabel: string;
  unitCost: number;
  estimatedCost: number;
  stockStatus: StockStatus;
  wholesalerId: number | null;
  wholesalerName: string;
  wholesalerPhone: string;
}

export interface WholesalerOrderGroup {
  wholesalerId: number | null;
  wholesalerName: string;
  wholesalerPhone: string;
  items: ReorderItem[];
  totalEstimatedCost: number;
}

export interface PurchaseOrderRecord {
  id: number;
  wholesalerId: number | null;
  wholesalerName: string;
  wholesalerPhone: string;
  messageText: string;
  totalEstimatedCost: number;
  status: 'DRAFT' | 'DISPATCHED';
  createdAt: string;
  items: Array<{
    productId: number;
    productName: string;
    sku: string;
    qtyOrdered: number;
    unitLabel: string;
    estimatedCost: number;
  }>;
}

export interface OfflineSyncOperation {
  operationId: string;
  productId: number;
  productName: string;
  sku: string;
  delta: number;
  expectedPrevQty: number;
  transactionType: TransactionType;
  notes?: string;
  createdAt: string;
  resolutionMode?: 'STRICT' | 'APPLY_DELTA' | 'OVERWRITE_LOCAL';
  localTargetQty?: number;
}

export interface SyncOperationResult {
  operationId: string;
  productId: number;
  status: 'APPLIED' | 'DUPLICATE_IGNORED' | 'CONFLICT' | 'ERROR';
  message: string;
  serverQty?: number;
  expectedPrevQty?: number;
  delta?: number;
  updatedProduct?: ProductDTO;
}

export interface CatalogTemplate {
  sku: string;
  name: string;
  barcode: string;
  categoryName: string;
  wholesalerName: string;
  costPrice: number;
  sellingPrice: number;
  defaultQty: number;
  minStockThreshold: number;
  reorderQty: number;
  unitLabel: string;
  reorderUnitLabel: string;
  reorderUnitCost: number | null;
  avgDailyDemand: number;
  leadTimeDays: number;
  safetyStock: number;
  expiryDaysFromNow: number | null;
}
