import type {
  ExpiryStatus,
  Product,
  ProductDTO,
  ReorderItem,
  StockStatus,
  StoreProfile,
  WholesalerOrderGroup,
} from './types.ts';

export function roundCurrency(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

/**
 * G. Low-Stock Monitoring
 * Whenever Current Quantity === 0 -> OUT_OF_STOCK
 * Whenever Current Quantity < Minimum Stock Threshold -> LOW_STOCK
 * Otherwise -> IN_STOCK
 */
export function evaluateStockStatus(
  currentQty: number,
  minStockThreshold: number
): StockStatus {
  if (currentQty <= 0) {
    return 'OUT_OF_STOCK';
  }
  if (currentQty < minStockThreshold) {
    return 'LOW_STOCK';
  }
  return 'IN_STOCK';
}

/**
 * A. Reorder Point Calculation
 * ROP = max(minStockThreshold, ceil(avgDailyDemand * leadTimeDays) + safetyStock)
 */
export function calculateReorderPoint(params: {
  minStockThreshold: number;
  avgDailyDemand?: number;
  leadTimeDays?: number;
  safetyStock?: number;
}): number {
  const demand = Math.max(0, params.avgDailyDemand ?? 0);
  const lead = Math.max(0, params.leadTimeDays ?? 0);
  const safety = Math.max(0, params.safetyStock ?? 0);
  const leadDemandRop = Math.ceil(demand * lead) + safety;
  return Math.max(params.minStockThreshold, leadDemandRop);
}

/**
 * E. Suggested Reorder Quantity
 * Uses configured reorderQty as the standard pack/batch floor,
 * scaling up if deficit beyond ROP requires additional cover.
 */
export function calculateSuggestedReorderQty(params: {
  currentQty: number;
  minStockThreshold: number;
  reorderQty: number;
  reorderPoint: number;
}): number {
  const baseOrder = Math.max(1, params.reorderQty);
  const needsReorder =
    params.currentQty === 0 ||
    params.currentQty < params.minStockThreshold ||
    params.currentQty <= params.reorderPoint;

  if (!needsReorder) {
    return 0;
  }

  // If unit matches stock unit and deficit exceeds configured reorderQty, top up safely
  const deficit = Math.max(0, params.reorderPoint - params.currentQty);
  return Math.max(baseOrder, deficit > baseOrder ? deficit + baseOrder : baseOrder);
}

/**
 * F. Expiry Monitoring
 * Compares expiry_date (YYYY-MM-DD) against reference date (local midnight).
 */
export function evaluateExpiryStatus(
  expiryDate: string | null,
  referenceDate: Date = new Date()
): {status: ExpiryStatus; daysUntilExpiry: number | null} {
  if (!expiryDate) {
    return {status: 'NONE', daysUntilExpiry: null};
  }

  const parsed = new Date(`${expiryDate}T00:00:00`);
  if (Number.isNaN(parsed.getTime())) {
    return {status: 'NONE', daysUntilExpiry: null};
  }

  const todayStart = new Date(
    referenceDate.getFullYear(),
    referenceDate.getMonth(),
    referenceDate.getDate()
  );
  const diffMs = parsed.getTime() - todayStart.getTime();
  const days = Math.round(diffMs / (1000 * 60 * 60 * 24));

  if (days < 0) {
    return {status: 'EXPIRED', daysUntilExpiry: days};
  }
  if (days <= 7) {
    return {status: 'EXPIRING_7', daysUntilExpiry: days};
  }
  if (days <= 15) {
    return {status: 'EXPIRING_15', daysUntilExpiry: days};
  }
  if (days <= 30) {
    return {status: 'EXPIRING_30', daysUntilExpiry: days};
  }
  return {status: 'HEALTHY', daysUntilExpiry: days};
}

/**
 * B, C, D. Inventory Valuation, Retail Turnover, Gross Profit & Margin
 */
export function calculateFinancialMetrics(
  products: Array<{currentQty: number; costPrice: number; sellingPrice: number}>
): {
  totalInventoryQty: number;
  inventoryValueAtCost: number;
  expectedRetailTurnover: number;
  expectedGrossProfit: number;
  grossProfitMarginPct: number;
} {
  let totalInventoryQty = 0;
  let inventoryValueAtCost = 0;
  let expectedRetailTurnover = 0;

  for (const item of products) {
    const qty = Math.max(0, item.currentQty);
    totalInventoryQty += qty;
    inventoryValueAtCost += qty * item.costPrice;
    expectedRetailTurnover += qty * item.sellingPrice;
  }

  const roundedCost = roundCurrency(inventoryValueAtCost);
  const roundedTurnover = roundCurrency(expectedRetailTurnover);
  const expectedGrossProfit = roundCurrency(roundedTurnover - roundedCost);
  const grossProfitMarginPct =
    roundedTurnover > 0
      ? roundCurrency((expectedGrossProfit / roundedTurnover) * 100)
      : 0;

  return {
    totalInventoryQty,
    inventoryValueAtCost: roundedCost,
    expectedRetailTurnover: roundedTurnover,
    expectedGrossProfit,
    grossProfitMarginPct,
  };
}

/**
 * E. Inventory Turnover from actual recorded SALE COGS
 * Returns null if no sales COGS or zero inventory value exists (never fabricated).
 */
export function calculateInventoryTurnover(params: {
  totalSalesCogs: number;
  inventoryValueAtCost: number;
}): number | null {
  if (params.totalSalesCogs <= 0 || params.inventoryValueAtCost <= 0) {
    return null;
  }
  return roundCurrency(params.totalSalesCogs / params.inventoryValueAtCost);
}

export function enrichProduct(
  product: Product,
  referenceDate: Date = new Date()
): ProductDTO {
  const stockStatus = evaluateStockStatus(
    product.currentQty,
    product.minStockThreshold
  );
  const {status: expiryStatus, daysUntilExpiry} = evaluateExpiryStatus(
    product.expiryDate,
    referenceDate
  );
  const reorderPoint = calculateReorderPoint({
    minStockThreshold: product.minStockThreshold,
    avgDailyDemand: product.avgDailyDemand,
    leadTimeDays: product.leadTimeDays,
    safetyStock: product.safetyStock,
  });

  const needsReorder =
    product.currentQty === 0 ||
    product.currentQty < product.minStockThreshold ||
    product.currentQty <= reorderPoint;

  // Keep Atta (or custom reorderUnitLabel items) cleanly honoring configured reorderQty
  const suggestedReorderQty = needsReorder
    ? product.reorderUnitLabel !== product.unitLabel
      ? Math.max(1, product.reorderQty)
      : calculateSuggestedReorderQty({
          currentQty: product.currentQty,
          minStockThreshold: product.minStockThreshold,
          reorderQty: product.reorderQty,
          reorderPoint,
        })
    : 0;

  return {
    ...product,
    stockStatus,
    expiryStatus,
    daysUntilExpiry,
    reorderPoint,
    needsReorder,
    suggestedReorderQty,
    inventoryValue: roundCurrency(product.currentQty * product.costPrice),
    retailValue: roundCurrency(product.currentQty * product.sellingPrice),
  };
}

export function buildReorderGroups(
  products: ProductDTO[]
): WholesalerOrderGroup[] {
  const groupsMap = new Map<string, WholesalerOrderGroup>();

  for (const p of products) {
    if (!p.needsReorder || p.suggestedReorderQty <= 0) {
      continue;
    }

    const wholesalerName = p.wholesalerName || 'Unassigned Supplier';
    const wholesalerPhone = p.wholesalerPhone || '';
    const key = `${p.wholesalerId ?? 'none'}::${wholesalerName}`;

    const unitCost = p.reorderUnitCost ?? p.costPrice;
    const estimatedCost = roundCurrency(p.suggestedReorderQty * unitCost);

    const reorderItem: ReorderItem = {
      productId: p.id,
      productName: p.name,
      sku: p.sku,
      categoryName: p.categoryName,
      currentQty: p.currentQty,
      unitLabel: p.unitLabel,
      minStockThreshold: p.minStockThreshold,
      reorderPoint: p.reorderPoint,
      suggestedReorderQty: p.suggestedReorderQty,
      reorderUnitLabel: p.reorderUnitLabel || p.unitLabel,
      unitCost,
      estimatedCost,
      stockStatus: p.stockStatus,
      wholesalerId: p.wholesalerId,
      wholesalerName,
      wholesalerPhone,
    };

    const existing = groupsMap.get(key);
    if (existing) {
      existing.items.push(reorderItem);
      existing.totalEstimatedCost = roundCurrency(
        existing.totalEstimatedCost + estimatedCost
      );
    } else {
      groupsMap.set(key, {
        wholesalerId: p.wholesalerId,
        wholesalerName,
        wholesalerPhone,
        items: [reorderItem],
        totalEstimatedCost: estimatedCost,
      });
    }
  }

  return Array.from(groupsMap.values()).sort((a, b) =>
    a.wholesalerName.localeCompare(b.wholesalerName)
  );
}

export function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: amount % 1 === 0 ? 0 : 2,
  }).format(amount);
}

export function formatWhatsAppPurchaseOrder(params: {
  store: Pick<StoreProfile, 'shopName' | 'ownerName' | 'phone' | 'address' | 'gstin'>;
  wholesalerName: string;
  items: Array<{
    productName: string;
    sku: string;
    qty: number;
    unitLabel: string;
    estimatedCost: number;
  }>;
  totalEstimatedCost: number;
  date?: Date;
}): string {
  const dateStr = (params.date ?? new Date()).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  const lines: string[] = [
    `*PURCHASE ORDER — ${params.store.shopName}*`,
    `Date: ${dateStr}`,
    `To: ${params.wholesalerName}`,
    '',
    '*Order Items:*',
  ];

  params.items.forEach((item, index) => {
    lines.push(
      `${index + 1}. ${item.productName} (${item.sku}) — *${item.qty} ${item.unitLabel}* (Est. ${formatINR(item.estimatedCost)})`
    );
  });

  lines.push('');
  lines.push(`*Estimated Total:* ${formatINR(params.totalEstimatedCost)}`);
  lines.push('');
  lines.push(`From: ${params.store.shopName} (${params.store.ownerName})`);
  lines.push(`Contact: ${params.store.phone}`);
  if (params.store.address) {
    lines.push(`Delivery Address: ${params.store.address}`);
  }
  if (params.store.gstin) {
    lines.push(`GSTIN: ${params.store.gstin}`);
  }
  lines.push('Please confirm stock availability and delivery slot.');

  return lines.join('\n');
}

export function buildWhatsAppUrl(phone: string, message: string): string {
  const digits = phone.replace(/[^\d]/g, '');
  const encoded = encodeURIComponent(message);
  if (digits.length >= 10) {
    const normalized = digits.length === 10 ? `91${digits}` : digits;
    return `https://wa.me/${normalized}?text=${encoded}`;
  }
  return `https://wa.me/?text=${encoded}`;
}
