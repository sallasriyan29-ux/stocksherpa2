import {describe, expect, it} from 'vitest';
import {
  buildWhatsAppUrl,
  calculateFinancialMetrics,
  calculateInventoryTurnover,
  calculateReorderPoint,
  calculateSuggestedReorderQty,
  evaluateExpiryStatus,
  evaluateStockStatus,
  formatWhatsAppPurchaseOrder,
} from '../shared/businessLogic.ts';

describe('StockSherpa Business Logic', () => {
  it('evaluates low-stock, out-of-stock, and healthy stock statuses accurately', () => {
    expect(evaluateStockStatus(0, 5)).toBe('OUT_OF_STOCK');
    expect(evaluateStockStatus(4, 5)).toBe('LOW_STOCK');
    expect(evaluateStockStatus(5, 5)).toBe('IN_STOCK');
    expect(evaluateStockStatus(12, 5)).toBe('IN_STOCK');
  });

  it('calculates inventory valuation, retail turnover, gross profit, and handles zero denominators', () => {
    const metrics = calculateFinancialMetrics([
      {currentQty: 10, costPrice: 100, sellingPrice: 125},
      {currentQty: 4, costPrice: 250, sellingPrice: 300},
    ]);

    expect(metrics.totalInventoryQty).toBe(14);
    expect(metrics.inventoryValueAtCost).toBe(2000);
    expect(metrics.expectedRetailTurnover).toBe(2450);
    expect(metrics.expectedGrossProfit).toBe(450);
    expect(metrics.grossProfitMarginPct).toBe(18.37);

    // Zero-denominator safety
    const empty = calculateFinancialMetrics([]);
    expect(empty.inventoryValueAtCost).toBe(0);
    expect(empty.expectedRetailTurnover).toBe(0);
    expect(empty.expectedGrossProfit).toBe(0);
    expect(empty.grossProfitMarginPct).toBe(0);
  });

  it('calculates inventory turnover strictly from recorded sales COGS', () => {
    expect(
      calculateInventoryTurnover({totalSalesCogs: 0, inventoryValueAtCost: 84000})
    ).toBeNull();
    expect(
      calculateInventoryTurnover({totalSalesCogs: 1000, inventoryValueAtCost: 0})
    ).toBeNull();
    expect(
      calculateInventoryTurnover({totalSalesCogs: 21000, inventoryValueAtCost: 84000})
    ).toBe(0.25);
  });

  it('computes reorder point and suggested reorder quantities', () => {
    const rop = calculateReorderPoint({
      minStockThreshold: 4,
      avgDailyDemand: 2,
      leadTimeDays: 3,
      safetyStock: 2,
    });
    expect(rop).toBe(8);

    const qty = calculateSuggestedReorderQty({
      currentQty: 2,
      minStockThreshold: 4,
      reorderQty: 10,
      reorderPoint: rop,
    });
    expect(qty).toBe(10);

    const noReorder = calculateSuggestedReorderQty({
      currentQty: 15,
      minStockThreshold: 4,
      reorderQty: 10,
      reorderPoint: rop,
    });
    expect(noReorder).toBe(0);
  });

  it('classifies expiry dates across expired, 7d, 15d, 30d, and healthy windows', () => {
    const ref = new Date('2026-11-19T12:00:00');
    expect(evaluateExpiryStatus(null, ref).status).toBe('NONE');
    expect(evaluateExpiryStatus('2026-11-17', ref)).toEqual({
      status: 'EXPIRED',
      daysUntilExpiry: -2,
    });
    expect(evaluateExpiryStatus('2026-11-23', ref)).toEqual({
      status: 'EXPIRING_7',
      daysUntilExpiry: 4,
    });
    expect(evaluateExpiryStatus('2026-12-01', ref)).toEqual({
      status: 'EXPIRING_15',
      daysUntilExpiry: 12,
    });
    expect(evaluateExpiryStatus('2026-12-14', ref)).toEqual({
      status: 'EXPIRING_30',
      daysUntilExpiry: 25,
    });
    expect(evaluateExpiryStatus('2027-03-01', ref).status).toBe('HEALTHY');
  });

  it('formats WhatsApp PO message and generates valid wa.me URL', () => {
    const message = formatWhatsAppPurchaseOrder({
      store: {
        shopName: 'Sri Lakshmi Kirana',
        ownerName: 'Ramesh Gupta',
        phone: '+91 98201 45678',
        address: 'Vashi, Navi Mumbai',
        gstin: null,
      },
      wholesalerName: 'Mahalaxmi Grain Wholesale',
      items: [
        {
          productName: 'Aashirvaad Shudh Chakki Atta (5kg Pack)',
          sku: 'GRN-ATTA-5KG',
          qty: 25,
          unitLabel: 'kg',
          estimatedCost: 1200,
        },
      ],
      totalEstimatedCost: 1200,
    });

    expect(message).toContain('Sri Lakshmi Kirana');
    expect(message).toContain('Mahalaxmi Grain Wholesale');
    expect(message).toContain('25 kg');
    expect(message).toContain('Aashirvaad Shudh Chakki Atta');

    const url = buildWhatsAppUrl('+919820411230', message);
    expect(url.startsWith('https://wa.me/919820411230?text=')).toBe(true);
  });
});
