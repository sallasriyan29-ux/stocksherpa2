import type Database from 'better-sqlite3';
import request from 'supertest';
import {afterEach, beforeEach, describe, expect, it} from 'vitest';
import {createApp} from '../backend/app.ts';
import {createDatabaseConnection} from '../database/connection.ts';
import {runMigrations} from '../database/migrations.ts';
import {seedInitialDatabase} from '../database/seedData.ts';

describe('StockSherpa REST API & SQLite End-to-End', () => {
  let db: Database.Database;
  let app: ReturnType<typeof createApp>;

  beforeEach(() => {
    db = createDatabaseConnection(':memory:');
    runMigrations(db);
    seedInitialDatabase(db);
    app = createApp(db);
  });

  afterEach(() => {
    db.close();
  });

  it('seeds 45 items totaling exactly Rs 84,000 and reproduces the complete Atta acceptance scenario', async () => {
    // 1. Open StockSherpa with 45 store items & 2. Display total inventory value as Rs 84,000
    const dashRes = await request(app).get('/api/dashboard/summary');
    expect(dashRes.status).toBe(200);
    expect(dashRes.body.summary.totalProducts).toBe(45);
    expect(dashRes.body.summary.inventoryValueAtCost).toBe(84000);

    // 3. Search for "Atta" & 4. Display current quantity as 6 packets
    const searchRes = await request(app).get('/api/products?search=Atta');
    expect(searchRes.status).toBe(200);
    const atta = searchRes.body.products.find(
      (p: {sku: string}) => p.sku === 'GRN-ATTA-5KG'
    );
    expect(atta).toBeDefined();
    expect(atta.currentQty).toBe(6);
    expect(atta.unitLabel).toBe('packets');
    expect(atta.stockStatus).toBe('IN_STOCK');

    // 5. Quick-decrement 4 packets (4 x -1) -> 6. Remaining quantity = 2, 7. Red LOW STOCK badge
    for (let i = 0; i < 4; i++) {
      const adjRes = await request(app)
        .post('/api/stock/adjust')
        .send({
          productId: atta.id,
          delta: -1,
          transactionType: 'SALE',
          operationId: `atta-sale-${i}`,
        });
      expect(adjRes.status).toBe(200);
    }

    const updatedAttaRes = await request(app).get(`/api/products/${atta.id}`);
    expect(updatedAttaRes.body.product.currentQty).toBe(2);
    expect(updatedAttaRes.body.product.stockStatus).toBe('LOW_STOCK');

    // Low-stock alerts include Atta
    const alertsRes = await request(app).get('/api/alerts/low-stock');
    expect(
      alertsRes.body.items.some((p: {id: number}) => p.id === atta.id)
    ).toBe(true);

    // 8. Navigate to Reorder Assistant & 9. Automatically add 25kg of Atta to wholesaler order list
    const reorderRes = await request(app).get('/api/reorder');
    expect(reorderRes.status).toBe(200);
    const mahalaxmiGroup = reorderRes.body.groups.find((g: {wholesalerName: string}) =>
      g.wholesalerName.includes('Mahalaxmi')
    );
    expect(mahalaxmiGroup).toBeDefined();
    const attaOrderItem = mahalaxmiGroup.items.find(
      (i: {productId: number}) => i.productId === atta.id
    );
    expect(attaOrderItem).toBeDefined();
    expect(attaOrderItem.suggestedReorderQty).toBe(25);
    expect(attaOrderItem.reorderUnitLabel).toBe('kg');

    // 10. Generate WhatsApp Order & 11. Display formatted PO message
    const poRes = await request(app)
      .post('/api/reorder/generate')
      .send({
        wholesalerId: mahalaxmiGroup.wholesalerId,
        wholesalerName: mahalaxmiGroup.wholesalerName,
        wholesalerPhone: mahalaxmiGroup.wholesalerPhone,
        status: 'DRAFT',
        items: [{productId: atta.id, qtyOrdered: 25}],
      });
    expect(poRes.status).toBe(201);
    expect(poRes.body.order.messageText).toContain('25 kg');
    expect(poRes.body.order.messageText).toContain('Aashirvaad Shudh Chakki Atta');
    expect(poRes.body.whatsappUrl).toContain('https://wa.me/');
  });

  it('supports product CRUD and prevents duplicate SKU and barcode values', async () => {
    // Create product
    const createRes = await request(app).post('/api/products').send({
      name: 'Tata Sampann Chana Dal 1kg',
      sku: 'GRN-CHANA-1KG',
      barcode: '8909999000111',
      categoryId: 1,
      wholesalerId: 1,
      costPrice: 95,
      sellingPrice: 115,
      currentQty: 12,
      minStockThreshold: 5,
      reorderQty: 15,
      unitLabel: 'packets',
    });
    expect(createRes.status).toBe(201);
    const createdId = createRes.body.product.id;

    // Duplicate SKU prevention
    const dupSku = await request(app).post('/api/products').send({
      name: 'Duplicate SKU Item',
      sku: 'GRN-CHANA-1KG',
      barcode: '8909999000999',
      categoryId: 1,
      costPrice: 50,
      sellingPrice: 60,
      currentQty: 5,
      minStockThreshold: 2,
      reorderQty: 5,
    });
    expect(dupSku.status).toBe(409);
    expect(dupSku.body.code).toBe('DUPLICATE_SKU');

    // Duplicate Barcode prevention
    const dupBarcode = await request(app).post('/api/products').send({
      name: 'Duplicate Barcode Item',
      sku: 'GRN-UNIQUE-999',
      barcode: '8909999000111',
      categoryId: 1,
      costPrice: 50,
      sellingPrice: 60,
      currentQty: 5,
      minStockThreshold: 2,
      reorderQty: 5,
    });
    expect(dupBarcode.status).toBe(409);
    expect(dupBarcode.body.code).toBe('DUPLICATE_BARCODE');

    // Edit product
    const editRes = await request(app)
      .put(`/api/products/${createdId}`)
      .send({
        name: 'Tata Sampann Chana Dal 1kg (Premium)',
        sku: 'GRN-CHANA-1KG',
        barcode: '8909999000111',
        categoryId: 1,
        wholesalerId: 1,
        costPrice: 98,
        sellingPrice: 120,
        currentQty: 14,
        minStockThreshold: 5,
        reorderQty: 15,
        unitLabel: 'packets',
      });
    expect(editRes.status).toBe(200);
    expect(editRes.body.product.name).toContain('Premium');
    expect(editRes.body.product.currentQty).toBe(14);

    // Delete product
    const delRes = await request(app).delete(`/api/products/${createdId}`);
    expect(delRes.status).toBe(200);
    const getDeleted = await request(app).get(`/api/products/${createdId}`);
    expect(getDeleted.status).toBe(404);
  });

  it('enforces negative stock prevention, creates stock logs, and triggers/clears low-stock alerts', async () => {
    const prodRes = await request(app).get('/api/products?search=Atta');
    const atta = prodRes.body.products[0];

    // Prevent negative stock
    const negRes = await request(app)
      .post('/api/stock/adjust')
      .send({
        productId: atta.id,
        delta: -99,
        transactionType: 'SALE',
      });
    expect(negRes.status).toBe(400);
    expect(negRes.body.code).toBe('NEGATIVE_STOCK');

    // Trigger low stock (6 -> 2, min is 4)
    await request(app).post('/api/stock/adjust').send({
      productId: atta.id,
      delta: -4,
      transactionType: 'SALE',
    });
    let alerts = await request(app).get('/api/alerts/low-stock');
    expect(alerts.body.items.some((p: {id: number}) => p.id === atta.id)).toBe(
      true
    );

    // Replenish +10 (2 -> 12) removes low-stock alert automatically
    const restockRes = await request(app).post('/api/stock/adjust').send({
      productId: atta.id,
      delta: 10,
      transactionType: 'RESTOCK',
    });
    expect(restockRes.status).toBe(200);
    expect(restockRes.body.product.currentQty).toBe(12);
    expect(restockRes.body.product.stockStatus).toBe('IN_STOCK');

    alerts = await request(app).get('/api/alerts/low-stock');
    expect(alerts.body.items.some((p: {id: number}) => p.id === atta.id)).toBe(
      false
    );

    // Verify stock logs recorded both adjustments
    const logsRes = await request(app).get(`/api/stock/logs/${atta.id}`);
    expect(logsRes.body.logs.length).toBeGreaterThanOrEqual(3);
  });

  it('synchronizes offline operations idempotently and flags conflicting updates for review', async () => {
    const prodRes = await request(app).get('/api/products?search=Atta');
    const atta = prodRes.body.products[0]; // qty 6

    // 1. Valid offline sync
    const sync1 = await request(app)
      .post('/api/stock/sync')
      .send({
        operations: [
          {
            operationId: 'offline-op-1',
            productId: atta.id,
            productName: atta.name,
            sku: atta.sku,
            delta: -2,
            expectedPrevQty: 6,
            transactionType: 'SALE',
            createdAt: new Date().toISOString(),
          },
        ],
      });
    expect(sync1.status).toBe(200);
    expect(sync1.body.results[0].status).toBe('APPLIED');
    expect(sync1.body.results[0].updatedProduct.currentQty).toBe(4);

    // 2. Duplicate operationId submission is safely ignored
    const syncDup = await request(app)
      .post('/api/stock/sync')
      .send({
        operations: [
          {
            operationId: 'offline-op-1',
            productId: atta.id,
            productName: atta.name,
            sku: atta.sku,
            delta: -2,
            expectedPrevQty: 6,
            transactionType: 'SALE',
            createdAt: new Date().toISOString(),
          },
        ],
      });
    expect(syncDup.status).toBe(200);
    expect(syncDup.body.results[0].status).toBe('DUPLICATE_IGNORED');

    // 3. Stale expectedPrevQty triggers CONFLICT without silent overwrite
    const syncConflict = await request(app)
      .post('/api/stock/sync')
      .send({
        operations: [
          {
            operationId: 'offline-op-conflict',
            productId: atta.id,
            productName: atta.name,
            sku: atta.sku,
            delta: -1,
            expectedPrevQty: 6, // server is now 4!
            transactionType: 'SALE',
            createdAt: new Date().toISOString(),
          },
        ],
      });
    expect(syncConflict.status).toBe(200);
    expect(syncConflict.body.results[0].status).toBe('CONFLICT');
    expect(syncConflict.body.results[0].serverQty).toBe(4);

    // Verify server quantity stayed 4 (not silently overwritten)
    const afterConflict = await request(app).get(`/api/products/${atta.id}`);
    expect(afterConflict.body.product.currentQty).toBe(4);

    // 4. Manual conflict resolution via APPLY_DELTA
    const resolveRes = await request(app)
      .post('/api/stock/sync')
      .send({
        operations: [
          {
            operationId: 'offline-op-conflict',
            productId: atta.id,
            productName: atta.name,
            sku: atta.sku,
            delta: -1,
            expectedPrevQty: 6,
            transactionType: 'SALE',
            resolutionMode: 'APPLY_DELTA',
            createdAt: new Date().toISOString(),
          },
        ],
      });
    expect(resolveRes.body.results[0].status).toBe('APPLIED');
    expect(resolveRes.body.results[0].updatedProduct.currentQty).toBe(3);
  });

  it('imports extra catalog templates without duplicating existing SKUs', async () => {
    const tplRes = await request(app).get('/api/templates');
    expect(tplRes.status).toBe(200);
    expect(tplRes.body.templates.length).toBe(15);

    const impRes = await request(app).post('/api/templates/GRN-T01/import');
    expect(impRes.status).toBe(201);
    expect(impRes.body.product.sku).toBe('GRN-T01');
  });

  it('tracks expiring and expired products accurately from actual dates', async () => {
    const expRes = await request(app).get('/api/alerts/expiring?days=30');
    expect(expRes.status).toBe(200);
    expect(expRes.body.items.length).toBeGreaterThan(0);
    expect(
      expRes.body.items.some(
        (p: {expiryStatus: string}) => p.expiryStatus === 'EXPIRED'
      )
    ).toBe(true);
  });
});
