import {StockSherpaApp} from '../frontend/StockSherpaApp.tsx';

export default function App() {
  return <StockSherpaApp />;
}
