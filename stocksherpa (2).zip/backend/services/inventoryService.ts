import type Database from 'better-sqlite3';
import {
  buildExpiryIsoFromDays,
  EXTRA_15_TEMPLATES,
} from '../../database/seedData.ts';
import {enrichProduct} from '../../shared/businessLogic.ts';
import type {
  CatalogTemplate,
  OfflineSyncOperation,
  Product,
  ProductDTO,
  ProductInput,
  StockLog,
  SyncOperationResult,
  TransactionType,
} from '../../shared/types.ts';
import {HttpError} from '../validators.ts';

interface ProductRow {
  id: number;
  name: string;
  sku: string;
  barcode: string | null;
  category_id: number;
  category_name: string;
  wholesaler_id: number | null;
  wholesaler_name: string | null;
  wholesaler_phone: string | null;
  cost_price: number;
  selling_price: number;
  current_qty: number;
  min_stock_threshold: number;
  reorder_qty: number;
  unit_label: string;
  reorder_unit_label: string;
  reorder_unit_cost: number | null;
  avg_daily_demand: number;
  lead_time_days: number;
  safety_stock: number;
  expiry_date: string | null;
  is_demo: number;
  created_at: string;
  updated_at: string;
}

function mapRowToProduct(row: ProductRow): Product {
  return {
    id: row.id,
    name: row.name,
    sku: row.sku,
    barcode: row.barcode,
    categoryId: row.category_id,
    categoryName: row.category_name,
    wholesalerId: row.wholesaler_id,
    wholesalerName: row.wholesaler_name,
    wholesalerPhone: row.wholesaler_phone,
    costPrice: row.cost_price,
    sellingPrice: row.selling_price,
    currentQty: row.current_qty,
    minStockThreshold: row.min_stock_threshold,
    reorderQty: row.reorder_qty,
    unitLabel: row.unit_label,
    reorderUnitLabel: row.reorder_unit_label,
    reorderUnitCost: row.reorder_unit_cost,
    avgDailyDemand: row.avg_daily_demand,
    leadTimeDays: row.lead_time_days,
    safetyStock: row.safety_stock,
    expiryDate: row.expiry_date,
    isDemo: Boolean(row.is_demo),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

const PRODUCT_SELECT_SQL = `
  SELECT
    p.*,
    c.name AS category_name,
    w.name AS wholesaler_name,
    w.phone AS wholesaler_phone
  FROM products p
  JOIN categories c ON p.category_id = c.id
  LEFT JOIN wholesalers w ON p.wholesaler_id = w.id
`;

export function listProducts(
  db: Database.Database,
  filters?: {category?: string; search?: string; barcode?: string}
): ProductDTO[] {
  const conditions: string[] = [];
  const params: Array<string | number> = [];

  if (filters?.category && filters.category !== 'ALL') {
    conditions.push('LOWER(c.name) = LOWER(?)');
    params.push(filters.category);
  }

  if (filters?.barcode) {
    conditions.push('p.barcode = ?');
    params.push(filters.barcode);
  }

  if (filters?.search && filters.search.trim()) {
    const q = `%${filters.search.trim()}%`;
    conditions.push(
      "(p.name LIKE ? OR p.sku LIKE ? OR COALESCE(p.barcode, '') LIKE ? OR c.name LIKE ?)"
    );
    params.push(q, q, q, q);
  }

  const whereClause =
    conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  const rows = db
    .prepare(`${PRODUCT_SELECT_SQL} ${whereClause} ORDER BY p.name ASC`)
    .all(...params) as ProductRow[];

  return rows.map((r) => enrichProduct(mapRowToProduct(r)));
}

export function getProductById(
  db: Database.Database,
  id: number
): ProductDTO {
  const row = db
    .prepare(`${PRODUCT_SELECT_SQL} WHERE p.id = ?`)
    .get(id) as ProductRow | undefined;

  if (!row) {
    throw new HttpError(404, `Product #${id} was not found.`, 'NOT_FOUND');
  }
  return enrichProduct(mapRowToProduct(row));
}

function assertCategoryExists(db: Database.Database, categoryId: number): void {
  const cat = db
    .prepare('SELECT id FROM categories WHERE id = ?')
    .get(categoryId);
  if (!cat) {
    throw new HttpError(400, `Category #${categoryId} does not exist.`);
  }
}

function assertWholesalerExists(
  db: Database.Database,
  wholesalerId: number | null | undefined
): void {
  if (!wholesalerId) return;
  const wh = db
    .prepare('SELECT id FROM wholesalers WHERE id = ?')
    .get(wholesalerId);
  if (!wh) {
    throw new HttpError(400, `Wholesaler #${wholesalerId} does not exist.`);
  }
}

function assertUniqueSkuAndBarcode(
  db: Database.Database,
  sku: string,
  barcode: string | null | undefined,
  excludeProductId?: number
): void {
  const skuHit = excludeProductId
    ? (db
        .prepare('SELECT id FROM products WHERE LOWER(sku) = LOWER(?) AND id != ?')
        .get(sku, excludeProductId) as {id: number} | undefined)
    : (db
        .prepare('SELECT id FROM products WHERE LOWER(sku) = LOWER(?)')
        .get(sku) as {id: number} | undefined);

  if (skuHit) {
    throw new HttpError(
      409,
      `A product with SKU "${sku}" already exists.`,
      'DUPLICATE_SKU'
    );
  }

  if (barcode) {
    const barcodeHit = excludeProductId
      ? (db
          .prepare('SELECT id FROM products WHERE barcode = ? AND id != ?')
          .get(barcode, excludeProductId) as {id: number} | undefined)
      : (db
          .prepare('SELECT id FROM products WHERE barcode = ?')
          .get(barcode) as {id: number} | undefined);

    if (barcodeHit) {
      throw new HttpError(
        409,
        `A product with barcode "${barcode}" already exists.`,
        'DUPLICATE_BARCODE'
      );
    }
  }
}

export function createProduct(
  db: Database.Database,
  input: ProductInput,
  isDemo = false
): ProductDTO {
  assertCategoryExists(db, input.categoryId);
  assertWholesalerExists(db, input.wholesalerId);
  assertUniqueSkuAndBarcode(db, input.sku, input.barcode);

  const tx = db.transaction(() => {
    const info = db
      .prepare(
        `INSERT INTO products (
          name, sku, barcode, category_id, wholesaler_id,
          cost_price, selling_price, current_qty, min_stock_threshold,
          reorder_qty, unit_label, reorder_unit_label, reorder_unit_cost,
          avg_daily_demand, lead_time_days, safety_stock, expiry_date, is_demo
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        input.name,
        input.sku,
        input.barcode ?? null,
        input.categoryId,
        input.wholesalerId ?? null,
        input.costPrice,
        input.sellingPrice,
        input.currentQty,
        input.minStockThreshold,
        input.reorderQty,
        input.unitLabel ?? 'units',
        input.reorderUnitLabel ?? input.unitLabel ?? 'units',
        input.reorderUnitCost ?? null,
        input.avgDailyDemand ?? 1,
        input.leadTimeDays ?? 2,
        input.safetyStock ?? 2,
        input.expiryDate ?? null,
        isDemo ? 1 : 0
      );

    const newId = Number(info.lastInsertRowid);

    db.prepare(
      `INSERT INTO stock_logs (
        product_id, prev_qty, new_qty, qty_changed, transaction_type, notes
      ) VALUES (?, 0, ?, ?, 'INITIAL', ?)`
    ).run(newId, input.currentQty, input.currentQty, 'Product added to catalog');

    return newId;
  });

  const createdId = tx();
  return getProductById(db, createdId);
}

export function updateProduct(
  db: Database.Database,
  id: number,
  input: ProductInput
): ProductDTO {
  const existing = getProductById(db, id);
  assertCategoryExists(db, input.categoryId);
  assertWholesalerExists(db, input.wholesalerId);
  assertUniqueSkuAndBarcode(db, input.sku, input.barcode, id);

  const tx = db.transaction(() => {
    db.prepare(
      `UPDATE products SET
        name = ?,
        sku = ?,
        barcode = ?,
        category_id = ?,
        wholesaler_id = ?,
        cost_price = ?,
        selling_price = ?,
        current_qty = ?,
        min_stock_threshold = ?,
        reorder_qty = ?,
        unit_label = ?,
        reorder_unit_label = ?,
        reorder_unit_cost = ?,
        avg_daily_demand = ?,
        lead_time_days = ?,
        safety_stock = ?,
        expiry_date = ?,
        updated_at = datetime('now')
      WHERE id = ?`
    ).run(
      input.name,
      input.sku,
      input.barcode ?? null,
      input.categoryId,
      input.wholesalerId ?? null,
      input.costPrice,
      input.sellingPrice,
      input.currentQty,
      input.minStockThreshold,
      input.reorderQty,
      input.unitLabel ?? 'units',
      input.reorderUnitLabel ?? input.unitLabel ?? 'units',
      input.reorderUnitCost ?? null,
      input.avgDailyDemand ?? 1,
      input.leadTimeDays ?? 2,
      input.safetyStock ?? 2,
      input.expiryDate ?? null,
      id
    );

    if (input.currentQty !== existing.currentQty) {
      const delta = input.currentQty - existing.currentQty;
      db.prepare(
        `INSERT INTO stock_logs (
          product_id, prev_qty, new_qty, qty_changed, transaction_type, notes
        ) VALUES (?, ?, ?, ?, 'ADJUSTMENT', ?)`
      ).run(
        id,
        existing.currentQty,
        input.currentQty,
        delta,
        'Manual quantity update via product edit'
      );
    }
  });

  tx();
  return getProductById(db, id);
}

export function deleteProduct(db: Database.Database, id: number): void {
  const existing = getProductById(db, id);
  db.prepare('DELETE FROM products WHERE id = ?').run(existing.id);
}

export function adjustStock(
  db: Database.Database,
  params: {
    productId: number;
    delta: number;
    transactionType: TransactionType;
    operationId?: string | null;
    notes?: string | null;
    expectedPrevQty?: number;
  }
): {
  product: ProductDTO;
  log: StockLog | null;
  duplicateIgnored: boolean;
} {
  const tx = db.transaction(() => {
    if (params.operationId) {
      const existingOp = db
        .prepare('SELECT id FROM stock_logs WHERE operation_id = ?')
        .get(params.operationId) as {id: number} | undefined;
      if (existingOp) {
        return {
          product: getProductById(db, params.productId),
          log: null,
          duplicateIgnored: true,
        };
      }
    }

    const row = db
      .prepare('SELECT id, name, current_qty FROM products WHERE id = ?')
      .get(params.productId) as
      | {id: number; name: string; current_qty: number}
      | undefined;

    if (!row) {
      throw new HttpError(
        404,
        `Product #${params.productId} not found.`,
        'NOT_FOUND'
      );
    }

    if (
      params.expectedPrevQty !== undefined &&
      row.current_qty !== params.expectedPrevQty
    ) {
      throw new HttpError(
        409,
        `Stock changed on server for ${row.name} (expected ${params.expectedPrevQty}, actual ${row.current_qty}).`,
        'STOCK_CONFLICT'
      );
    }

    const newQty = row.current_qty + params.delta;
    if (newQty < 0) {
      throw new HttpError(
        400,
        `Cannot reduce ${row.name} below 0. Available quantity is ${row.current_qty}.`,
        'NEGATIVE_STOCK'
      );
    }

    db.prepare(
      `UPDATE products
       SET current_qty = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(newQty, row.id);

    const logInfo = db
      .prepare(
        `INSERT INTO stock_logs (
          product_id, prev_qty, new_qty, qty_changed, transaction_type, operation_id, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        row.id,
        row.current_qty,
        newQty,
        params.delta,
        params.transactionType,
        params.operationId ?? null,
        params.notes ?? null
      );

    const logRow = db
      .prepare(
        `SELECT l.*, p.name AS product_name, p.sku, p.unit_label
         FROM stock_logs l
         JOIN products p ON l.product_id = p.id
         WHERE l.id = ?`
      )
      .get(logInfo.lastInsertRowid) as StockLogRow;

    return {
      product: getProductById(db, row.id),
      log: mapStockLogRow(logRow),
      duplicateIgnored: false,
    };
  });

  return tx.immediate();
}

export function syncOfflineOperations(
  db: Database.Database,
  operations: OfflineSyncOperation[]
): SyncOperationResult[] {
  const results: SyncOperationResult[] = [];

  for (const op of operations) {
    try {
      // Check duplicate operationId first
      const dup = db
        .prepare('SELECT id FROM stock_logs WHERE operation_id = ?')
        .get(op.operationId) as {id: number} | undefined;
      if (dup) {
        results.push({
          operationId: op.operationId,
          productId: op.productId,
          status: 'DUPLICATE_IGNORED',
          message: 'Operation already synchronized.',
        });
        continue;
      }

      const productRow = db
        .prepare('SELECT id, name, current_qty FROM products WHERE id = ?')
        .get(op.productId) as
        | {id: number; name: string; current_qty: number}
        | undefined;

      if (!productRow) {
        results.push({
          operationId: op.operationId,
          productId: op.productId,
          status: 'ERROR',
          message: `Product #${op.productId} no longer exists.`,
        });
        continue;
      }

      const mode = op.resolutionMode ?? 'STRICT';

      if (mode === 'STRICT' && productRow.current_qty !== op.expectedPrevQty) {
        results.push({
          operationId: op.operationId,
          productId: op.productId,
          status: 'CONFLICT',
          message: `Server stock (${productRow.current_qty}) differs from offline baseline (${op.expectedPrevQty}).`,
          serverQty: productRow.current_qty,
          expectedPrevQty: op.expectedPrevQty,
          delta: op.delta,
        });
        continue;
      }

      if (mode === 'OVERWRITE_LOCAL') {
        const target = Math.max(0, op.localTargetQty ?? op.expectedPrevQty + op.delta);
        const computedDelta = target - productRow.current_qty;
        if (computedDelta === 0) {
          // Record operationId marker without changing quantity
          db.prepare(
            `INSERT INTO stock_logs (
              product_id, prev_qty, new_qty, qty_changed, transaction_type, operation_id, notes
            ) VALUES (?, ?, ?, 0, 'ADJUSTMENT', ?, ?)`
          ).run(
            productRow.id,
            productRow.current_qty,
            productRow.current_qty,
            op.operationId,
            op.notes ?? 'Offline conflict resolved (kept current quantity)'
          );
          results.push({
            operationId: op.operationId,
            productId: op.productId,
            status: 'APPLIED',
            message: 'Conflict resolved cleanly.',
            updatedProduct: getProductById(db, productRow.id),
          });
          continue;
        }
        const applied = adjustStock(db, {
          productId: op.productId,
          delta: computedDelta,
          transactionType: op.transactionType,
          operationId: op.operationId,
          notes:
            op.notes ??
            `Offline sync overwrite (resolved from ${productRow.current_qty} to ${target})`,
        });
        results.push({
          operationId: op.operationId,
          productId: op.productId,
          status: 'APPLIED',
          message: 'Offline target quantity applied.',
          updatedProduct: applied.product,
        });
        continue;
      }

      // STRICT (matching) or APPLY_DELTA
      const applied = adjustStock(db, {
        productId: op.productId,
        delta: op.delta,
        transactionType: op.transactionType,
        operationId: op.operationId,
        notes: op.notes ?? 'Synchronized from offline queue',
      });

      results.push({
        operationId: op.operationId,
        productId: op.productId,
        status: applied.duplicateIgnored ? 'DUPLICATE_IGNORED' : 'APPLIED',
        message: 'Synchronized successfully.',
        updatedProduct: applied.product,
      });
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Synchronization failed.';
      results.push({
        operationId: op.operationId,
        productId: op.productId,
        status: 'ERROR',
        message,
      });
    }
  }

  return results;
}

interface StockLogRow {
  id: number;
  product_id: number;
  product_name?: string;
  sku?: string;
  unit_label?: string;
  prev_qty: number;
  new_qty: number;
  qty_changed: number;
  transaction_type: TransactionType;
  operation_id: string | null;
  notes: string | null;
  created_at: string;
}

function mapStockLogRow(row: StockLogRow): StockLog {
  return {
    id: row.id,
    productId: row.product_id,
    productName: row.product_name,
    sku: row.sku,
    unitLabel: row.unit_label,
    prevQty: row.prev_qty,
    newQty: row.new_qty,
    qtyChanged: row.qty_changed,
    transactionType: row.transaction_type,
    operationId: row.operation_id,
    notes: row.notes,
    createdAt: row.created_at,
  };
}

export function listStockLogs(
  db: Database.Database,
  productId?: number,
  limit = 60
): StockLog[] {
  if (productId) {
    const rows = db
      .prepare(
        `SELECT l.*, p.name AS product_name, p.sku, p.unit_label
         FROM stock_logs l
         JOIN products p ON l.product_id = p.id
         WHERE l.product_id = ?
         ORDER BY l.id DESC
         LIMIT ?`
      )
      .all(productId, limit) as StockLogRow[];
    return rows.map(mapStockLogRow);
  }

  const rows = db
    .prepare(
      `SELECT l.*, p.name AS product_name, p.sku, p.unit_label
       FROM stock_logs l
       JOIN products p ON l.product_id = p.id
       ORDER BY l.id DESC
       LIMIT ?`
    )
    .all(limit) as StockLogRow[];
  return rows.map(mapStockLogRow);
}

export function listCatalogTemplatesWithStatus(
  db: Database.Database
): Array<CatalogTemplate & {alreadyInStore: boolean}> {
  const existingSkus = new Set(
    (
      db.prepare('SELECT UPPER(sku) AS sku FROM products').all() as Array<{
        sku: string;
      }>
    ).map((r) => r.sku)
  );

  return EXTRA_15_TEMPLATES.map((t) => ({
    ...t,
    alreadyInStore: existingSkus.has(t.sku.toUpperCase()),
  }));
}

export function importTemplateBySku(
  db: Database.Database,
  sku: string
): ProductDTO {
  const tpl = EXTRA_15_TEMPLATES.find(
    (t) => t.sku.toUpperCase() === sku.toUpperCase()
  );
  if (!tpl) {
    throw new HttpError(404, `Template SKU "${sku}" not found.`, 'NOT_FOUND');
  }

  const cat = db
    .prepare('SELECT id FROM categories WHERE LOWER(name) = LOWER(?)')
    .get(tpl.categoryName) as {id: number} | undefined;
  if (!cat) {
    throw new HttpError(400, `Category ${tpl.categoryName} missing.`);
  }

  const wh = db
    .prepare('SELECT id FROM wholesalers WHERE LOWER(name) = LOWER(?)')
    .get(tpl.wholesalerName) as {id: number} | undefined;

  return createProduct(
    db,
    {
      name: tpl.name,
      sku: tpl.sku,
      barcode: tpl.barcode,
      categoryId: cat.id,
      wholesalerId: wh?.id ?? null,
      costPrice: tpl.costPrice,
      sellingPrice: tpl.sellingPrice,
      currentQty: tpl.defaultQty,
      minStockThreshold: tpl.minStockThreshold,
      reorderQty: tpl.reorderQty,
      unitLabel: tpl.unitLabel,
      reorderUnitLabel: tpl.reorderUnitLabel,
      reorderUnitCost: tpl.reorderUnitCost,
      avgDailyDemand: tpl.avgDailyDemand,
      leadTimeDays: tpl.leadTimeDays,
      safetyStock: tpl.safetyStock,
      expiryDate: buildExpiryIsoFromDays(tpl.expiryDaysFromNow),
    },
    false
  );
}
