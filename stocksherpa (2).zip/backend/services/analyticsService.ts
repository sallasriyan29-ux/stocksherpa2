import type Database from 'better-sqlite3';
import {
  buildReorderGroups,
  buildWhatsAppUrl,
  calculateFinancialMetrics,
  calculateInventoryTurnover,
  formatWhatsAppPurchaseOrder,
  roundCurrency,
} from '../../shared/businessLogic.ts';
import type {
  DashboardSummary,
  ProductDTO,
  PurchaseOrderRecord,
  StoreProfile,
  WholesalerOrderGroup,
} from '../../shared/types.ts';
import {HttpError} from '../validators.ts';
import {listProducts, listStockLogs} from './inventoryService.ts';

export function getStoreProfile(db: Database.Database): StoreProfile {
  const row = db
    .prepare('SELECT * FROM store_profile WHERE id = 1')
    .get() as
    | {
        id: number;
        shop_name: string;
        owner_name: string;
        phone: string;
        address: string;
        gstin: string | null;
        updated_at: string;
      }
    | undefined;

  if (!row) {
    return {
      id: 1,
      shopName: 'Sri Lakshmi Kirana & General Store',
      ownerName: 'Ramesh Gupta',
      phone: '+91 98201 45678',
      address: 'Shop 4, Laxmi Market, Sector 17, Vashi, Navi Mumbai 400703',
      gstin: null,
      updatedAt: new Date().toISOString(),
    };
  }

  return {
    id: row.id,
    shopName: row.shop_name,
    ownerName: row.owner_name,
    phone: row.phone,
    address: row.address,
    gstin: row.gstin,
    updatedAt: row.updated_at,
  };
}

export function updateStoreProfile(
  db: Database.Database,
  input: {
    shopName: string;
    ownerName: string;
    phone: string;
    address: string;
    gstin: string | null;
  }
): StoreProfile {
  db.prepare(
    `INSERT INTO store_profile (id, shop_name, owner_name, phone, address, gstin, updated_at)
     VALUES (1, ?, ?, ?, ?, ?, datetime('now'))
     ON CONFLICT(id) DO UPDATE SET
       shop_name = excluded.shop_name,
       owner_name = excluded.owner_name,
       phone = excluded.phone,
       address = excluded.address,
       gstin = excluded.gstin,
       updated_at = datetime('now')`
  ).run(
    input.shopName,
    input.ownerName,
    input.phone,
    input.address,
    input.gstin
  );

  return getStoreProfile(db);
}

export function getDashboardSummary(db: Database.Database): DashboardSummary {
  const products = listProducts(db);
  const financials = calculateFinancialMetrics(products);

  // Calculate COGS strictly from recorded SALE stock logs
  const cogsRow = db
    .prepare(
      `SELECT COALESCE(SUM(ABS(l.qty_changed) * p.cost_price), 0) AS total_cogs
       FROM stock_logs l
       JOIN products p ON l.product_id = p.id
       WHERE l.transaction_type = 'SALE' AND l.qty_changed < 0`
    )
    .get() as {total_cogs: number};

  const totalSalesCogs = roundCurrency(cogsRow?.total_cogs ?? 0);
  const inventoryTurnoverRatio = calculateInventoryTurnover({
    totalSalesCogs,
    inventoryValueAtCost: financials.inventoryValueAtCost,
  });

  const lowStockCount = products.filter(
    (p) => p.stockStatus === 'LOW_STOCK'
  ).length;
  const outOfStockCount = products.filter(
    (p) => p.stockStatus === 'OUT_OF_STOCK'
  ).length;
  const expiringCount = products.filter(
    (p) =>
      p.expiryStatus === 'EXPIRING_7' ||
      p.expiryStatus === 'EXPIRING_15' ||
      p.expiryStatus === 'EXPIRING_30'
  ).length;
  const expiredCount = products.filter(
    (p) => p.expiryStatus === 'EXPIRED'
  ).length;

  const recentActivities = listStockLogs(db, undefined, 12);

  return {
    totalProducts: products.length,
    totalInventoryQty: financials.totalInventoryQty,
    inventoryValueAtCost: financials.inventoryValueAtCost,
    expectedRetailTurnover: financials.expectedRetailTurnover,
    expectedGrossProfit: financials.expectedGrossProfit,
    grossProfitMarginPct: financials.grossProfitMarginPct,
    inventoryTurnoverRatio,
    totalSalesCogs,
    lowStockCount,
    outOfStockCount,
    expiringCount,
    expiredCount,
    recentActivities,
  };
}

export function getLowStockAlerts(db: Database.Database): ProductDTO[] {
  const products = listProducts(db);
  return products
    .filter(
      (p) => p.stockStatus === 'LOW_STOCK' || p.stockStatus === 'OUT_OF_STOCK'
    )
    .sort((a, b) => a.currentQty - b.currentQty);
}

export function getExpiringAlerts(
  db: Database.Database,
  withinDays = 30
): ProductDTO[] {
  const products = listProducts(db);
  return products
    .filter((p) => {
      if (p.daysUntilExpiry === null) return false;
      return p.daysUntilExpiry <= withinDays;
    })
    .sort((a, b) => (a.daysUntilExpiry ?? 9999) - (b.daysUntilExpiry ?? 9999));
}

export function getReorderGroups(
  db: Database.Database
): WholesalerOrderGroup[] {
  const products = listProducts(db);
  return buildReorderGroups(products);
}

export function generateAndSavePurchaseOrder(
  db: Database.Database,
  payload: {
    wholesalerId: number | null;
    wholesalerName: string;
    wholesalerPhone: string;
    status?: 'DRAFT' | 'DISPATCHED';
    items: Array<{
      productId: number;
      qtyOrdered: number;
    }>;
  }
): {
  order: PurchaseOrderRecord;
  whatsappUrl: string;
} {
  if (!payload.items || payload.items.length === 0) {
    throw new HttpError(400, 'Purchase order must include at least one item.');
  }

  const store = getStoreProfile(db);
  const resolvedItems: Array<{
    productId: number;
    productName: string;
    sku: string;
    qtyOrdered: number;
    unitLabel: string;
    estimatedCost: number;
  }> = [];

  for (const item of payload.items) {
    const qty = Number(item.qtyOrdered);
    if (!Number.isInteger(qty) || qty <= 0) {
      throw new HttpError(
        400,
        'Order quantity must be a positive whole number.'
      );
    }
    const row = db
      .prepare(
        `SELECT id, name, sku, cost_price, reorder_unit_label, reorder_unit_cost
         FROM products WHERE id = ?`
      )
      .get(item.productId) as
      | {
          id: number;
          name: string;
          sku: string;
          cost_price: number;
          reorder_unit_label: string;
          reorder_unit_cost: number | null;
        }
      | undefined;

    if (!row) {
      throw new HttpError(404, `Product #${item.productId} not found.`);
    }

    const unitCost = row.reorder_unit_cost ?? row.cost_price;
    const estimatedCost = roundCurrency(qty * unitCost);

    resolvedItems.push({
      productId: row.id,
      productName: row.name,
      sku: row.sku,
      qtyOrdered: qty,
      unitLabel: row.reorder_unit_label,
      estimatedCost,
    });
  }

  const totalEstimatedCost = roundCurrency(
    resolvedItems.reduce((sum, i) => sum + i.estimatedCost, 0)
  );

  const messageText = formatWhatsAppPurchaseOrder({
    store,
    wholesalerName: payload.wholesalerName || 'Supplier',
    items: resolvedItems.map((i) => ({
      productName: i.productName,
      sku: i.sku,
      qty: i.qtyOrdered,
      unitLabel: i.unitLabel,
      estimatedCost: i.estimatedCost,
    })),
    totalEstimatedCost,
  });

  const status = payload.status === 'DISPATCHED' ? 'DISPATCHED' : 'DRAFT';

  const orderId = db.transaction(() => {
    const poInfo = db
      .prepare(
        `INSERT INTO purchase_orders (
          wholesaler_id, wholesaler_name, wholesaler_phone,
          message_text, total_estimated_cost, status
        ) VALUES (?, ?, ?, ?, ?, ?)`
      )
      .run(
        payload.wholesalerId ?? null,
        payload.wholesalerName,
        payload.wholesalerPhone ?? '',
        messageText,
        totalEstimatedCost,
        status
      );

    const id = Number(poInfo.lastInsertRowid);
    const insertItem = db.prepare(
      `INSERT INTO purchase_order_items (
        purchase_order_id, product_id, product_name, sku,
        qty_ordered, unit_label, estimated_cost
      ) VALUES (?, ?, ?, ?, ?, ?, ?)`
    );

    for (const item of resolvedItems) {
      insertItem.run(
        id,
        item.productId,
        item.productName,
        item.sku,
        item.qtyOrdered,
        item.unitLabel,
        item.estimatedCost
      );
    }

    return id;
  })();

  const poRow = db
    .prepare('SELECT * FROM purchase_orders WHERE id = ?')
    .get(orderId) as {
    id: number;
    wholesaler_id: number | null;
    wholesaler_name: string;
    wholesaler_phone: string;
    message_text: string;
    total_estimated_cost: number;
    status: 'DRAFT' | 'DISPATCHED';
    created_at: string;
  };

  return {
    order: {
      id: poRow.id,
      wholesalerId: poRow.wholesaler_id,
      wholesalerName: poRow.wholesaler_name,
      wholesalerPhone: poRow.wholesaler_phone,
      messageText: poRow.message_text,
      totalEstimatedCost: poRow.total_estimated_cost,
      status: poRow.status,
      createdAt: poRow.created_at,
      items: resolvedItems,
    },
    whatsappUrl: buildWhatsAppUrl(poRow.wholesaler_phone, poRow.message_text),
  };
}

export function listPurchaseOrders(
  db: Database.Database
): PurchaseOrderRecord[] {
  const poRows = db
    .prepare('SELECT * FROM purchase_orders ORDER BY id DESC LIMIT 25')
    .all() as Array<{
    id: number;
    wholesaler_id: number | null;
    wholesaler_name: string;
    wholesaler_phone: string;
    message_text: string;
    total_estimated_cost: number;
    status: 'DRAFT' | 'DISPATCHED';
    created_at: string;
  }>;

  const itemStmt = db.prepare(
    'SELECT * FROM purchase_order_items WHERE purchase_order_id = ?'
  );

  return poRows.map((po) => {
    const items = itemStmt.all(po.id) as Array<{
      product_id: number;
      product_name: string;
      sku: string;
      qty_ordered: number;
      unit_label: string;
      estimated_cost: number;
    }>;

    return {
      id: po.id,
      wholesalerId: po.wholesaler_id,
      wholesalerName: po.wholesaler_name,
      wholesalerPhone: po.wholesaler_phone,
      messageText: po.message_text,
      totalEstimatedCost: po.total_estimated_cost,
      status: po.status,
      createdAt: po.created_at,
      items: items.map((i) => ({
        productId: i.product_id,
        productName: i.product_name,
        sku: i.sku,
        qtyOrdered: i.qty_ordered,
        unitLabel: i.unit_label,
        estimatedCost: i.estimated_cost,
      })),
    };
  });
}

export function markPurchaseOrderDispatched(
  db: Database.Database,
  orderId: number
): PurchaseOrderRecord {
  const info = db
    .prepare("UPDATE purchase_orders SET status = 'DISPATCHED' WHERE id = ?")
    .run(orderId);
  if (info.changes === 0) {
    throw new HttpError(404, `Purchase order #${orderId} not found.`);
  }
  const orders = listPurchaseOrders(db);
  const found = orders.find((o) => o.id === orderId);
  if (!found) {
    throw new HttpError(404, `Purchase order #${orderId} not found.`);
  }
  return found;
}
