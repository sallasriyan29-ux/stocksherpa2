import type {
  OfflineSyncOperation,
  ProductInput,
  TransactionType,
} from '../shared/types.ts';

export class HttpError extends Error {
  statusCode: number;
  code: string;

  constructor(statusCode: number, message: string, code = 'BAD_REQUEST') {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
  }
}

const VALID_TX_TYPES = new Set<TransactionType>([
  'SALE',
  'RESTOCK',
  'ADJUSTMENT',
  'INITIAL',
  'RETURN',
  'SPOILAGE',
]);

export function sanitizeString(val: unknown): string {
  if (typeof val !== 'string') return '';
  return val.trim().replace(/\s+/g, ' ');
}

export function parsePositiveInt(val: unknown, fieldName: string): number {
  const num = Number(val);
  if (!Number.isInteger(num) || num <= 0) {
    throw new HttpError(400, `${fieldName} must be a positive integer.`);
  }
  return num;
}

export function validateProductInput(
  body: Record<string, unknown>
): ProductInput {
  const name = sanitizeString(body.name);
  if (name.length < 2 || name.length > 140) {
    throw new HttpError(
      400,
      'Product name must be between 2 and 140 characters.'
    );
  }

  const sku = sanitizeString(body.sku).toUpperCase();
  if (!/^[A-Z0-9_-]{2,40}$/.test(sku)) {
    throw new HttpError(
      400,
      'SKU must be 2–40 characters using letters, numbers, hyphens, or underscores.'
    );
  }

  const rawBarcode =
    body.barcode === null || body.barcode === undefined
      ? ''
      : sanitizeString(String(body.barcode));
  const barcode = rawBarcode.length > 0 ? rawBarcode : null;
  if (barcode && !/^[A-Za-z0-9-]{4,32}$/.test(barcode)) {
    throw new HttpError(
      400,
      'Barcode must be 4–32 alphanumeric characters.'
    );
  }

  const categoryId = parsePositiveInt(body.categoryId, 'Category');

  let wholesalerId: number | null = null;
  if (
    body.wholesalerId !== null &&
    body.wholesalerId !== undefined &&
    body.wholesalerId !== ''
  ) {
    wholesalerId = parsePositiveInt(body.wholesalerId, 'Wholesaler');
  }

  const costPrice = Number(body.costPrice);
  const sellingPrice = Number(body.sellingPrice);
  if (!Number.isFinite(costPrice) || costPrice < 0) {
    throw new HttpError(400, 'Cost price must be a non-negative number.');
  }
  if (!Number.isFinite(sellingPrice) || sellingPrice < 0) {
    throw new HttpError(400, 'Selling price must be a non-negative number.');
  }

  const currentQty = Number(body.currentQty);
  if (!Number.isInteger(currentQty) || currentQty < 0) {
    throw new HttpError(400, 'Current quantity must be a whole number >= 0.');
  }

  const minStockThreshold = Number(body.minStockThreshold);
  if (!Number.isInteger(minStockThreshold) || minStockThreshold < 0) {
    throw new HttpError(
      400,
      'Minimum stock threshold must be a whole number >= 0.'
    );
  }

  const reorderQty = Number(body.reorderQty);
  if (!Number.isInteger(reorderQty) || reorderQty < 1) {
    throw new HttpError(400, 'Reorder quantity must be a whole number >= 1.');
  }

  const unitLabel = sanitizeString(body.unitLabel) || 'units';
  const reorderUnitLabel =
    sanitizeString(body.reorderUnitLabel) || unitLabel;

  let reorderUnitCost: number | null = null;
  if (
    body.reorderUnitCost !== null &&
    body.reorderUnitCost !== undefined &&
    body.reorderUnitCost !== ''
  ) {
    const parsed = Number(body.reorderUnitCost);
    if (!Number.isFinite(parsed) || parsed < 0) {
      throw new HttpError(
        400,
        'Reorder unit cost must be a non-negative number.'
      );
    }
    reorderUnitCost = parsed;
  }

  const avgDailyDemand =
    body.avgDailyDemand !== undefined ? Number(body.avgDailyDemand) : 1;
  if (!Number.isFinite(avgDailyDemand) || avgDailyDemand < 0) {
    throw new HttpError(400, 'Average daily demand must be >= 0.');
  }

  const leadTimeDays =
    body.leadTimeDays !== undefined ? Number(body.leadTimeDays) : 2;
  if (!Number.isInteger(leadTimeDays) || leadTimeDays < 0) {
    throw new HttpError(400, 'Lead time days must be an integer >= 0.');
  }

  const safetyStock =
    body.safetyStock !== undefined ? Number(body.safetyStock) : 2;
  if (!Number.isInteger(safetyStock) || safetyStock < 0) {
    throw new HttpError(400, 'Safety stock must be an integer >= 0.');
  }

  let expiryDate: string | null = null;
  if (
    body.expiryDate !== null &&
    body.expiryDate !== undefined &&
    String(body.expiryDate).trim() !== ''
  ) {
    const dateStr = String(body.expiryDate).trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
      throw new HttpError(400, 'Expiry date must use YYYY-MM-DD format.');
    }
    const parsedDate = new Date(`${dateStr}T00:00:00`);
    if (Number.isNaN(parsedDate.getTime())) {
      throw new HttpError(400, 'Expiry date is invalid.');
    }
    expiryDate = dateStr;
  }

  return {
    name,
    sku,
    barcode,
    categoryId,
    wholesalerId,
    costPrice,
    sellingPrice,
    currentQty,
    minStockThreshold,
    reorderQty,
    unitLabel,
    reorderUnitLabel,
    reorderUnitCost,
    avgDailyDemand,
    leadTimeDays,
    safetyStock,
    expiryDate,
  };
}

export function validateStockAdjustment(body: Record<string, unknown>): {
  productId: number;
  delta: number;
  transactionType: TransactionType;
  operationId: string | null;
  notes: string | null;
  expectedPrevQty?: number;
} {
  const productId = parsePositiveInt(body.productId, 'Product ID');
  const delta = Number(body.delta);
  if (!Number.isInteger(delta) || delta === 0) {
    throw new HttpError(400, 'Stock delta must be a non-zero whole integer.');
  }

  const rawType = sanitizeString(body.transactionType).toUpperCase();
  const defaultType: TransactionType = delta < 0 ? 'SALE' : 'RESTOCK';
  const transactionType = rawType
    ? (rawType as TransactionType)
    : defaultType;
  if (!VALID_TX_TYPES.has(transactionType)) {
    throw new HttpError(400, 'Invalid stock transaction type.');
  }

  const operationId = body.operationId
    ? sanitizeString(String(body.operationId))
    : null;
  const notes = body.notes ? sanitizeString(String(body.notes)) : null;

  let expectedPrevQty: number | undefined;
  if (
    body.expectedPrevQty !== undefined &&
    body.expectedPrevQty !== null
  ) {
    const parsed = Number(body.expectedPrevQty);
    if (!Number.isInteger(parsed) || parsed < 0) {
      throw new HttpError(400, 'expectedPrevQty must be a non-negative integer.');
    }
    expectedPrevQty = parsed;
  }

  return {
    productId,
    delta,
    transactionType,
    operationId,
    notes,
    expectedPrevQty,
  };
}

export function validateSyncOperations(
  body: Record<string, unknown>
): OfflineSyncOperation[] {
  if (!Array.isArray(body.operations)) {
    throw new HttpError(400, 'operations must be an array.');
  }
  return body.operations.map((raw, idx) => {
    if (!raw || typeof raw !== 'object') {
      throw new HttpError(400, `Operation at index ${idx} is invalid.`);
    }
    const op = raw as Record<string, unknown>;
    const operationId = sanitizeString(op.operationId);
    if (!operationId) {
      throw new HttpError(400, `Operation at index ${idx} missing operationId.`);
    }
    const productId = parsePositiveInt(op.productId, 'productId');
    const delta = Number(op.delta);
    if (!Number.isInteger(delta)) {
      throw new HttpError(400, `Operation ${operationId} delta must be an integer.`);
    }
    const expectedPrevQty = Number(op.expectedPrevQty);
    if (!Number.isInteger(expectedPrevQty) || expectedPrevQty < 0) {
      throw new HttpError(
        400,
        `Operation ${operationId} expectedPrevQty must be >= 0.`
      );
    }
    const txType = (sanitizeString(op.transactionType).toUpperCase() ||
      (delta < 0 ? 'SALE' : 'RESTOCK')) as TransactionType;
    if (!VALID_TX_TYPES.has(txType)) {
      throw new HttpError(400, `Invalid transaction type on ${operationId}`);
    }

    const resolutionMode = op.resolutionMode
      ? (String(op.resolutionMode) as OfflineSyncOperation['resolutionMode'])
      : 'STRICT';

    return {
      operationId,
      productId,
      productName: sanitizeString(op.productName) || `Product #${productId}`,
      sku: sanitizeString(op.sku) || '',
      delta,
      expectedPrevQty,
      transactionType: txType,
      notes: op.notes ? sanitizeString(String(op.notes)) : undefined,
      createdAt: sanitizeString(op.createdAt) || new Date().toISOString(),
      resolutionMode,
      localTargetQty:
        op.localTargetQty !== undefined ? Number(op.localTargetQty) : undefined,
    };
  });
}

export function validateWholesalerInput(body: Record<string, unknown>): {
  name: string;
  phone: string;
  contactPerson: string | null;
  notes: string | null;
} {
  const name = sanitizeString(body.name);
  if (name.length < 2 || name.length > 120) {
    throw new HttpError(400, 'Wholesaler name must be 2–120 characters.');
  }
  const phone = sanitizeString(body.phone);
  if (phone.replace(/[^\d]/g, '').length < 10) {
    throw new HttpError(
      400,
      'Wholesaler phone must contain at least 10 digits.'
    );
  }
  const contactPerson = sanitizeString(body.contactPerson) || null;
  const notes = sanitizeString(body.notes) || null;
  return {name, phone, contactPerson, notes};
}

export function validateStoreProfileInput(body: Record<string, unknown>): {
  shopName: string;
  ownerName: string;
  phone: string;
  address: string;
  gstin: string | null;
} {
  const shopName = sanitizeString(body.shopName);
  const ownerName = sanitizeString(body.ownerName);
  const phone = sanitizeString(body.phone);
  const address = sanitizeString(body.address);
  const gstin = sanitizeString(body.gstin) || null;

  if (shopName.length < 2) {
    throw new HttpError(400, 'Shop name is required.');
  }
  if (ownerName.length < 2) {
    throw new HttpError(400, 'Owner name is required.');
  }
  if (phone.replace(/[^\d]/g, '').length < 10) {
    throw new HttpError(400, 'Valid shop phone number is required.');
  }
  if (address.length < 4) {
    throw new HttpError(400, 'Shop delivery address is required.');
  }

  return {shopName, ownerName, phone, address, gstin};
}
