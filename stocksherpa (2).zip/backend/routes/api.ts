import type Database from 'better-sqlite3';
import {Router, type NextFunction, type Request, type Response} from 'express';
import {
  generateAndSavePurchaseOrder,
  getDashboardSummary,
  getExpiringAlerts,
  getLowStockAlerts,
  getReorderGroups,
  getStoreProfile,
  listPurchaseOrders,
  markPurchaseOrderDispatched,
  updateStoreProfile,
} from '../services/analyticsService.ts';
import {
  adjustStock,
  createProduct,
  deleteProduct,
  getProductById,
  importTemplateBySku,
  listCatalogTemplatesWithStatus,
  listProducts,
  listStockLogs,
  syncOfflineOperations,
  updateProduct,
} from '../services/inventoryService.ts';
import {
  HttpError,
  parsePositiveInt,
  validateProductInput,
  validateStockAdjustment,
  validateStoreProfileInput,
  validateSyncOperations,
  validateWholesalerInput,
} from '../validators.ts';

export function createApiRouter(db: Database.Database): Router {
  const router = Router();

  router.get('/health', (_req: Request, res: Response) => {
    res.json({status: 'ok', service: 'stocksherpa-api'});
  });

  // === PRODUCTS ===
  router.get('/products', (req: Request, res: Response) => {
    const category =
      typeof req.query.category === 'string' ? req.query.category : undefined;
    const search =
      typeof req.query.search === 'string' ? req.query.search : undefined;
    const barcode =
      typeof req.query.barcode === 'string' ? req.query.barcode : undefined;

    const products = listProducts(db, {category, search, barcode});
    res.json({products, total: products.length});
  });

  router.get('/products/:id', (req: Request, res: Response) => {
    const id = parsePositiveInt(req.params.id, 'Product ID');
    const product = getProductById(db, id);
    res.json({product});
  });

  router.post('/products', (req: Request, res: Response) => {
    const input = validateProductInput(req.body ?? {});
    const product = createProduct(db, input, false);
    res.status(201).json({product});
  });

  router.put('/products/:id', (req: Request, res: Response) => {
    const id = parsePositiveInt(req.params.id, 'Product ID');
    const input = validateProductInput(req.body ?? {});
    const product = updateProduct(db, id, input);
    res.json({product});
  });

  router.delete('/products/:id', (req: Request, res: Response) => {
    const id = parsePositiveInt(req.params.id, 'Product ID');
    deleteProduct(db, id);
    res.json({deleted: true, id});
  });

  // === STOCK & SYNC ===
  router.post('/stock/adjust', (req: Request, res: Response) => {
    const parsed = validateStockAdjustment(req.body ?? {});
    const result = adjustStock(db, parsed);
    res.json(result);
  });

  router.post('/stock/sync', (req: Request, res: Response) => {
    const operations = validateSyncOperations(req.body ?? {});
    const results = syncOfflineOperations(db, operations);
    res.json({results});
  });

  router.get('/stock/logs', (req: Request, res: Response) => {
    const limit = req.query.limit
      ? Math.min(200, Math.max(1, Number(req.query.limit) || 60))
      : 60;
    const logs = listStockLogs(db, undefined, limit);
    res.json({logs});
  });

  router.get('/stock/logs/:productId', (req: Request, res: Response) => {
    const productId = parsePositiveInt(req.params.productId, 'Product ID');
    const logs = listStockLogs(db, productId, 100);
    res.json({logs});
  });

  // === DASHBOARD & ALERTS ===
  router.get('/dashboard/summary', (_req: Request, res: Response) => {
    const summary = getDashboardSummary(db);
    res.json({summary});
  });

  router.get('/alerts/low-stock', (_req: Request, res: Response) => {
    const items = getLowStockAlerts(db);
    res.json({items, total: items.length});
  });

  router.get('/alerts/expiring', (req: Request, res: Response) => {
    const days =
      req.query.days !== undefined ? Number(req.query.days) : 30;
    const withinDays = Number.isFinite(days) ? days : 30;
    const items = getExpiringAlerts(db, withinDays);
    res.json({items, total: items.length});
  });

  // === REORDER & PURCHASE ORDERS ===
  router.get('/reorder', (_req: Request, res: Response) => {
    const groups = getReorderGroups(db);
    const totalItems = groups.reduce((acc, g) => acc + g.items.length, 0);
    const totalEstimatedCost = groups.reduce(
      (acc, g) => acc + g.totalEstimatedCost,
      0
    );
    res.json({groups, totalItems, totalEstimatedCost});
  });

  router.post('/reorder/generate', (req: Request, res: Response) => {
    const body = req.body ?? {};
    const result = generateAndSavePurchaseOrder(db, {
      wholesalerId:
        body.wholesalerId !== null && body.wholesalerId !== undefined
          ? Number(body.wholesalerId)
          : null,
      wholesalerName: String(body.wholesalerName || 'Supplier'),
      wholesalerPhone: String(body.wholesalerPhone || ''),
      status: body.status === 'DISPATCHED' ? 'DISPATCHED' : 'DRAFT',
      items: Array.isArray(body.items) ? body.items : [],
    });
    res.status(201).json(result);
  });

  router.get('/reorder/orders', (_req: Request, res: Response) => {
    const orders = listPurchaseOrders(db);
    res.json({orders});
  });

  router.patch('/reorder/orders/:id/dispatch', (req: Request, res: Response) => {
    const id = parsePositiveInt(req.params.id, 'Purchase Order ID');
    const order = markPurchaseOrderDispatched(db, id);
    res.json({order});
  });

  // === CATEGORIES ===
  router.get('/categories', (_req: Request, res: Response) => {
    const categories = db
      .prepare(
        `SELECT c.id, c.name, c.description, COUNT(p.id) AS productCount
         FROM categories c
         LEFT JOIN products p ON p.category_id = c.id
         GROUP BY c.id
         ORDER BY c.id ASC`
      )
      .all();
    res.json({categories});
  });

  // === WHOLESALERS ===
  router.get('/wholesalers', (_req: Request, res: Response) => {
    const rows = db
      .prepare(
        `SELECT id, name, phone, contact_person AS contactPerson, notes,
                created_at AS createdAt, updated_at AS updatedAt
         FROM wholesalers
         ORDER BY name ASC`
      )
      .all();
    res.json({wholesalers: rows});
  });

  router.post('/wholesalers', (req: Request, res: Response) => {
    const input = validateWholesalerInput(req.body ?? {});
    const dup = db
      .prepare('SELECT id FROM wholesalers WHERE LOWER(name) = LOWER(?)')
      .get(input.name);
    if (dup) {
      throw new HttpError(
        409,
        `Wholesaler "${input.name}" already exists.`,
        'DUPLICATE_WHOLESALER'
      );
    }

    const info = db
      .prepare(
        `INSERT INTO wholesalers (name, phone, contact_person, notes)
         VALUES (?, ?, ?, ?)`
      )
      .run(input.name, input.phone, input.contactPerson, input.notes);

    const wholesaler = db
      .prepare(
        `SELECT id, name, phone, contact_person AS contactPerson, notes,
                created_at AS createdAt, updated_at AS updatedAt
         FROM wholesalers WHERE id = ?`
      )
      .get(info.lastInsertRowid);
    res.status(201).json({wholesaler});
  });

  router.put('/wholesalers/:id', (req: Request, res: Response) => {
    const id = parsePositiveInt(req.params.id, 'Wholesaler ID');
    const input = validateWholesalerInput(req.body ?? {});

    const existing = db
      .prepare('SELECT id FROM wholesalers WHERE id = ?')
      .get(id);
    if (!existing) {
      throw new HttpError(404, `Wholesaler #${id} not found.`, 'NOT_FOUND');
    }

    const dup = db
      .prepare(
        'SELECT id FROM wholesalers WHERE LOWER(name) = LOWER(?) AND id != ?'
      )
      .get(input.name, id);
    if (dup) {
      throw new HttpError(
        409,
        `Another wholesaler named "${input.name}" already exists.`
      );
    }

    db.prepare(
      `UPDATE wholesalers
       SET name = ?, phone = ?, contact_person = ?, notes = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(input.name, input.phone, input.contactPerson, input.notes, id);

    const wholesaler = db
      .prepare(
        `SELECT id, name, phone, contact_person AS contactPerson, notes,
                created_at AS createdAt, updated_at AS updatedAt
         FROM wholesalers WHERE id = ?`
      )
      .get(id);
    res.json({wholesaler});
  });

  // === CATALOG TEMPLATES (15 EXTRA KIRANA ITEMS) ===
  router.get('/templates', (_req: Request, res: Response) => {
    const templates = listCatalogTemplatesWithStatus(db);
    res.json({templates});
  });

  router.post('/templates/:sku/import', (req: Request, res: Response) => {
    const product = importTemplateBySku(db, String(req.params.sku));
    res.status(201).json({product});
  });

  // === STORE PROFILE ===
  router.get('/store-profile', (_req: Request, res: Response) => {
    const profile = getStoreProfile(db);
    res.json({profile});
  });

  router.put('/store-profile', (req: Request, res: Response) => {
    const input = validateStoreProfileInput(req.body ?? {});
    const profile = updateStoreProfile(db, input);
    res.json({profile});
  });

  // Centralized error handler for API routes
  router.use(
    (err: unknown, _req: Request, res: Response, _next: NextFunction) => {
      if (err instanceof HttpError) {
        res.status(err.statusCode).json({
          error: err.message,
          code: err.code,
        });
        return;
      }
      console.error('[StockSherpa API Error]', err);
      res.status(500).json({
        error: 'An unexpected server error occurred.',
        code: 'INTERNAL_ERROR',
      });
    }
  );

  return router;
}
