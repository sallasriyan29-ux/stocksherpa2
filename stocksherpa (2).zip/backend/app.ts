import type Database from 'better-sqlite3';
import express, {type Express} from 'express';
import {createApiRouter} from './routes/api.ts';

export function createApp(db: Database.Database): Express {
  const app = express();
  app.use(express.json({limit: '1mb'}));
  app.use('/api', createApiRouter(db));
  return app;
}
