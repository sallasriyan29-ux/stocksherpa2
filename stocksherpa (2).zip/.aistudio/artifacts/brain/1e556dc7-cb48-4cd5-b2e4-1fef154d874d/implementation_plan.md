# StockSherpa — KiranaKeeper Inventory & Smart Reorder Assistant

StockSherpa is a mobile-first Progressive Web App and desktop operations workspace built for neighborhood Indian grocery stores (kirana shops) to replace handwritten ledgers with real-time stock tracking, automated alerts, expiry monitoring, barcode scanning, offline-resilient operations, and WhatsApp wholesaler purchase ordering.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The decisions below reflect your Phase 1 answers and establish the binding product defaults before implementation begins.

- **Confirmed Decision 1 — Initial Seed & Catalog Templates**: The database seeds with **45 active store products totaling exactly ₹84,000 in cost inventory value** (including *Atta* at 6 packets ready for the live acceptance scenario), plus **15 additional kirana catalog templates** available in a one-click Template Library so all 60 realistic Indian grocery items are immediately accessible without distorting the ₹84,000 starting valuation.
- **Confirmed Decision 2 — Visual Theme**: **Clean Merchant Daylight** using crisp off-white canvases (`#F8FAFC`), pure white structured surfaces (`#FFFFFF`), warm slate typography (`#0F172A` / `#475569`), and high-intent emerald accents (`#059669`) reserved strictly for primary actions and healthy stock status.
- **Confirmed Decision 3 — Offline Sync Conflict Policy**: Offline stock adjustments carry unique operation IDs and expected baseline quantities. When connectivity returns, any item whose server quantity diverged while offline is **flagged for manual review inside a dedicated Sync Queue drawer** rather than silently overwritten.
- **Confirmed Decision 4 — Store Profile & Language**: English interface paired with an **editable Store Profile** (Shop Name, Owner Name, Phone, Address, GSTIN optional) whose details automatically populate generated WhatsApp Purchase Orders.

---

## 1. Overview & Core Concept

- **What It Does**: Provides kirana shopkeepers with a unified inventory command center across desktop and mobile: instant +1 / -1 / +10 stock adjustments backed by an immutable stock ledger, fuzzy & barcode search, automatic low-stock and out-of-stock alerts, perishable expiry tracking (7/15/30-day & expired), intelligent wholesaler reorder grouping, formatted WhatsApp PO dispatch, and offline-first PWA sync.
- **Target Audience / Persona**: Independent Indian kirana store owners and counter staff operating in fast-paced retail environments with intermittent mobile connectivity, managing both high-velocity packaged goods and perishable dairy staples.
- **Key Value**: Eliminates silent stockouts and perishable spoilage while turning messy wholesaler restocking into a 30-second, mathematically grounded workflow.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Daily Counter Overview (Dashboard)**: Displays 8 database-computed financial & operational KPIs (Total Products, Total Units, Inventory Value at Cost in ₹, Expected Retail Turnover, Expected Gross Profit & Margin %, Low-Stock Count, Out-of-Stock Count, Expiring Soon Count), a dynamic Low-Stock Alert Banner when thresholds are breached, and the Recent Stock Activity ledger.
2. **Instant Stock Counter & Discovery (Inventory)**:
   - *Desktop*: High-density sortable table (`36px–44px` compact rows) with debounced Fuse.js fuzzy search (Name, SKU, Barcode), Category tabs (*All*, *Grains*, *Dairy*, *Snacks*, *Personal Care*), Stock Status filters, and 1-tap `-1`, `+1`, `+10` action controls.
   - *Mobile (`<640px`)*: Responsive single-column cards with `>=44px` touch targets, large quantity readout, and immediate `-1` / `+1` / `+10` buttons for one-handed counter use without horizontal scrolling.
3. **Product Lifecycle & Ledger Audit**: Create/edit modal with strict validation (cost price, selling price, non-negative quantities, unique SKU & Barcode, reorder threshold, reorder quantity, optional expiry date, category, wholesaler). Viewing a product reveals its full Stock Ledger history and margin analytics. Deleting requires explicit confirmation.
4. **Barcode Scanning**: Camera-powered EAN barcode scanner using the HTML5 Camera API and QuaggaJS with graceful permission/unsupported-browser handling and an immediate manual barcode entry fallback. Matching codes open the item for quick adjustment; unknown codes pre-fill a new product form.
5. **Perishable Expiry Tracker**: Dedicated view filtering inventory by *Expired*, *Within 7 Days*, *Within 15 Days*, and *Within 30 Days*, displaying remaining stock quantity and value at risk without auto-deleting expired stock.
6. **Smart Reorder Assistant & WhatsApp PO**: Automatically identifies items at or below their reorder point / minimum threshold, computes suggested reorder quantities using configurable lead-time and safety-stock rules, groups line items by Wholesaler, lets the shopkeeper adjust quantities or remove items, and generates a formatted WhatsApp message (`wa.me` link + copy + JSON/CSV/TXT export) using the saved Store Profile and Supplier phone number—requiring manual dispatch confirmation.
7. **Offline Mode & Sync Queue**: Captures stock adjustments in `localStorage` when offline, updates the UI optimistically, displays a clear connectivity & pending-count banner, and automatically syncs when online—surfacing any server quantity mismatches in the Sync Queue for side-by-side resolution.

### Visual Identity & Theme

- **Aesthetic Direction**: *Clean Merchant Daylight* — pragmatic, daylight-legible utility inspired by modern accounting ledgers and crisp B2B operations workspaces.
- **Color Palette (60-30-10 Budget)**:
  - *60% Dominant Neutral Canvas*: `#F8FAFC` (crisp warm-cool slate-white background).
  - *30% Structural Surfaces*: `#FFFFFF` cards & table panels with hairline `1px solid #E2E8F0` borders (single-elevation depth, no nested cards-within-cards, no thick left accent stripes).
  - *10% Accent & Semantic Signals*: `#059669` (Merchant Emerald) for primary CTAs and active states; `#D97706` (Amber) paired with explicit text (`LOW STOCK`, `EXPIRING SOON`); `#DC2626` (Crimson) paired with explicit text (`OUT OF STOCK`, `EXPIRED`). Never convey status by color alone.
- **Typography & Tabular Discipline**:
  - *Display / Headings*: `Plus Jakarta Sans` (SemiBold 600 / Bold 700, `text-wrap: balance` to prevent orphan words).
  - *Body & Navigation*: `DM Sans` (Regular 400 / Medium 500, crisp legibility at `13px–15px`).
  - *Numbers, SKUs, Prices & Ledgers*: `JetBrains Mono` with `font-variant-numeric: tabular-nums` so every ₹ figure and stock counter aligns vertically without jitter.
- **Layout, Top Bar & Zero-Pill Discipline**:
  - *Desktop*: Left workspace sidebar (`248px`) + clean 3-zone top bar (Brand wordmark, concise contextual navigation/breadcrumb, 1 primary CTA such as `+ Add Product` plus in-app PWA Install action when eligible) + full-width `1440px`-ready viewport.
  - *Mobile (`<640px`)*: Compact `52px` sticky header + bottom thumb-zone tab bar (`Dashboard`, `Inventory`, `Scan`, `Reorder`, `More` drawer) respecting the `<=15%` combined sticky viewport height cap.
  - *Zero-Pill Metadata*: Categories, SKUs, dates, and supplier names render as clean unboxed text separated by `·`, reserving colored badges strictly for semantic stock/expiry status labels paired with explicit text.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Server-Side SQLite (`better-sqlite3` or `sqlite3` / Node SQLite) with Express API**:
  - *Chosen Approach*: Persistent relational SQLite database stored on disk with explicit SQL schema migrations, foreign keys (`PRAGMA foreign_keys = ON`), indexes on SKU/barcode/category/expiry, and `BEGIN IMMEDIATE` atomic transactions.
  - *Why*: Guarantees ACID stock integrity, prevents negative stock under concurrent adjustments, ensures persistence across server restarts, and keeps all financial valuations authoritative on the backend.
  - *Alternatives Considered*: Browser-only `localStorage` or IndexedDB—rejected because the prompt mandates a reliable Node.js + Express + SQLite backend with real REST persistence.
- **Decision 2 — Single-Port Full-Stack Serving on Port 3000**:
  - *Chosen Approach*: Express serves `/api/*` REST endpoints and integrates Vite middleware in development (and serves the built `dist/` bundle in production) on port `3000`.
  - *Why*: Eliminates CORS friction, keeps PWA service-worker scope unified under `/`, and satisfies the runtime requirement that the app runs cleanly on port `3000`.
- **Decision 3 — Optimistic UI + Idempotent Offline Operation Queue with Conflict Flagging**:
  - *Chosen Approach*: Each offline adjustment generates a UUID `operationId`, records `expectedPrevQty`, `delta`, `timestamp`, and `productId`, and persists in `localStorage`. On reconnect, the batch sync endpoint validates `operationId` uniqueness (preventing duplicates) and compares `expectedPrevQty` against current DB quantity. Mismatches return a `CONFLICT` status that appears in the Sync Queue drawer for explicit user resolution (`Apply Delta Anyway`, `Overwrite with Local`, or `Discard Local Change`).
  - *Why*: Protects inventory accuracy when multiple devices or sessions modify stock while offline, fulfilling your Phase 1 conflict-review requirement.
- **Decision 4 — PWA via `vite-plugin-pwa` + Custom PNG/SVG Icons + Offline API Caching**:
  - *Chosen Approach*: Configure `vite-plugin-pwa` with `devOptions.enabled: true`, full `manifest.webmanifest` (`id`, `short_name` <= 12 chars, `standalone`, `192x192`, `512x512`, maskable icon with safe-zone padding, and `180x180` Apple touch PNG), Workbox asset precaching + `NetworkFirst` runtime caching for read APIs, and an in-app `PWAInstallButton`.
  - *Why*: Satisfies cross-browser installability (Desktop Chromium, Android, iOS Safari guidance) and keeps the inventory catalog usable when internet drops.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        STOCKSHERPA PWA CLIENT (React + TS)                 │
│                                                                            │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────────┐  ┌───────────────┐  │
│  │  Dashboard   │  │  Inventory   │  │ Smart Reorder │  │ Expiry & Scan │  │
│  │  KPIs & Feed │  │ Fuse.js/CRUD │  │ & WhatsApp PO │  │ QuaggaJS Cam  │  │
│  └──────┬───────┘  └──────┬───────┘  └───────┬───────┘  └───────┬───────┘  │
│         └─────────────────┴──────────────────┴──────────────────┘          │
│                                    │                                       │
│                   ┌────────────────▼────────────────┐                      │
│                   │  State, Optimistic UI & Offline │                      │
│                   │  Sync Queue (localStorage)      │                      │
│                   └────────────────┬────────────────┘                      │
│                                    │ Service Worker (Precache + NetFirst)  │
└────────────────────────────────────┼───────────────────────────────────────┘
                                     │ REST JSON (/api/*) on Port 3000
┌────────────────────────────────────▼───────────────────────────────────────┐
│                     NODE.JS + EXPRESS BACKEND (TypeScript)                 │
│                                                                            │
│  ┌─────────────────┐  ┌──────────────────┐  ┌───────────────────────────┐  │
│  │ Input Validation│  │ Business Engine  │  │ Sync & Idempotency Guard  │  │
│  │ & Sanitization  │  │ (Valuation, ROP, │  │ (operationId dedup &      │  │
│  │                 │  │  Expiry, Alerts) │  │  expectedPrevQty check)   │  │
│  └────────┬────────┘  └────────┬─────────┘  └─────────────┬─────────────┘  │
│           └────────────────────┴──────────────────────────┘                │
│                                    │                                       │
│                   ┌────────────────▼────────────────┐                      │
│                   │     SQLite Persistence Layer    │                      │
│                   │ (Migrations, Transactions, FK)  │                      │
│                   └─────────────────────────────────┘                      │
└────────────────────────────────────────────────────────────────────────────┘
```

### Database Schema & Relationships

```
┌──────────────────┐       ┌──────────────────────────┐       ┌──────────────────┐
│    Categories    │       │         Products         │       │   Wholesalers    │
├──────────────────┤       ├──────────────────────────┤       ├──────────────────┤
│ id (PK)          │◄──1:N─│ category_id (FK)         │─N:1──►│ id (PK)          │
│ name (UNIQUE)    │       │ wholesaler_id (FK)       │       │ name             │
│ description      │       │ id (PK), name            │       │ phone            │
└──────────────────┘       │ sku (UNIQUE), barcode(UQ)│       │ contact_person   │
                           │ cost_price, selling_price│       │ notes            │
                           │ current_qty, min_thresh  │       └──────────────────┘
                           │ reorder_qty, lead_time_d │
                           │ unit_label, expiry_date  │
                           │ is_demo, created/updated │
                           └────────────┬─────────────┘
                                        │ 1:N
                           ┌────────────▼─────────────┐       ┌──────────────────┐
                           │        StockLogs         │       │  StoreProfile    │
                           ├──────────────────────────┤       ├──────────────────┤
                           │ id (PK)                  │       │ id (PK = 1)      │
                           │ product_id (FK)          │       │ shop_name        │
                           │ prev_qty, new_qty, delta │       │ owner_name       │
                           │ transaction_type         │       │ phone, address   │
                           │ operation_id (UNIQUE)    │       │ gstin            │
                           │ notes, created_at        │       └──────────────────┘
                           └──────────────────────────┘
```

### Interactive Component & State Mapping

- **Dashboard View**: Fetches `/api/dashboard/summary`, `/api/alerts/low-stock`, `/api/alerts/expiring`, and `/api/stock/logs` -> renders real-time valuation, gross profit, margin %, low-stock alert banner, and activity stream. Reactively refreshes on every stock adjustment or product CRUD mutation.
- **Inventory Workspace (Desktop Table & Mobile Cards)**: Uses Fuse.js (`name`, `sku`, `barcode`, `categoryName`) with `200ms` debounced search, category & status filters, and column/key sorting -> clicking `-1`, `+1`, `+10` triggers optimistic state update, queues offline op if `navigator.onLine === false`, or posts `/api/stock/adjust` with UUID `operationId` + `expectedPrevQty`, rolling back with a clear toast error if validation fails (e.g., negative stock attempt).
- **Product Modal & Detail Drawer**: Validates prices (`selling_price >= 0`, `cost_price >= 0`), non-negative stock/thresholds, unique SKU/barcode errors from server `409 Conflict`, and loads `/api/stock/logs/:productId` for full audit history. Also includes a **Catalog Templates** drawer containing the 15 extra kirana templates for one-click addition.
- **Barcode Scanner Modal**: Requests `navigator.mediaDevices.getUserMedia` camera permission -> initializes QuaggaJS EAN-13/EAN-8/UPC scanner -> on detection, looks up product by barcode (opening quick-adjust or pre-filling Add Product if unmatched). Displays clear error/unsupported state and always provides a functional manual barcode input fallback.
- **Smart Reorder Assistant & WhatsApp Dispatch**: Queries `/api/reorder` -> applies Reorder Point & Suggested Quantity heuristic (`max(reorder_qty, target_stock - current_qty)`) -> groups items by wholesaler -> supports inline quantity editing, item removal, store-profile header customization, copy to clipboard, JSON/TXT export, `wa.me` WhatsApp launch with URL-encoded message, and explicit manual "Mark Dispatched" confirmation (which logs a pending/dispatched PO record via `/api/reorder/generate` without falsely claiming wholesaler acceptance).
- **Sync Queue Drawer & Connectivity Banner**: Monitors `online`/`offline` events and pending `localStorage` queue -> auto-attempts `/api/stock/sync` when online -> flags any item with `CONFLICT` status for side-by-side manual resolution.

### Core Business Algorithms & Acceptance Scenario Calibration

- **Authoritative Calculations** (implemented in shared TypeScript business module and enforced server-side, covered by automated tests):
  - *Inventory Valuation*: `Σ (current_qty × cost_price)`
  - *Expected Retail Turnover*: `Σ (current_qty × selling_price)`
  - *Expected Gross Profit & Margin*: `Expected Retail Turnover − Inventory Valuation`; `Margin = Turnover > 0 ? (Gross Profit / Turnover) × 100 : 0`
  - *Inventory Turnover*: Computed strictly from actual logged `OUT` / `SALE` COGS transactions over average inventory value (returns `0` / `"No sales recorded yet"` when zero sales exist—never fabricated).
  - *Reorder Point & Suggested Order*: `ROP = max(min_stock_threshold, ceil(avg_daily_demand × lead_time_days) + safety_stock)`; qualifies whenever `current_qty <= ROP` or `current_qty < min_stock_threshold` or `current_qty === 0`.
  - *Low-Stock Status*: `current_qty === 0` → `OUT OF STOCK`; `current_qty < min_stock_threshold` → `LOW STOCK`; else `IN STOCK`.
  - *Expiry Status*: Compares `expiry_date` against current date into `EXPIRED` (`< 0 days`), `EXPIRING_7` (`0–7 days`), `EXPIRING_15` (`8–15 days`), `EXPIRING_30` (`16–30 days`), or `HEALTHY`.
- **Demonstration & Acceptance Calibration (Section 13)**:
  - The 45 initial products are carefully calibrated so `Σ (current_qty × cost_price) === ₹84,000.00` out of the box.
  - *Atta* (e.g., *Aashirvaad Shudh Chakki Atta 5kg* or *Whole Wheat Atta Packet*) starts at **6 packets**, with `min_stock_threshold = 4`, `reorder_qty = 25` (`25kg` / 5×5kg or configured unit `kg`/packets so reorder assistant adds `25kg` of Atta). Decrementing 4 packets drops quantity to **2**, immediately flips its badge to red **LOW STOCK**, drops inventory value accordingly, and queues **25kg of Atta** in the Smart Reorder Assistant ready for WhatsApp PO generation.
