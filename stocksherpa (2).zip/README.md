# StockSherpa (KiranaKeeper)

**Smart Inventory Management & Supplier Reorder Assistant for Indian Kirana Stores**

StockSherpa is a mobile-first Progressive Web App (PWA) and desktop operations dashboard built with React, TypeScript, Express, and SQLite. It helps neighborhood grocery stores track real-time stock quantities, prevent stockouts and perishable spoilage, scan EAN barcodes, stay operational offline, and dispatch consolidated WhatsApp purchase orders to wholesalers.

---

## Core Capabilities

- **Live Financial Dashboard**: Real-time SQLite calculation of Inventory Value at Cost (₹), Expected Retail Turnover, Expected Gross Profit & Margin %, Inventory Turnover (from recorded sales COGS), Low-Stock/Out-of-Stock counts, Expiring counts, and Recent Stock Activities.
- **Product Catalog & Immutable Stock Ledger**: Full CRUD with duplicate SKU/barcode protection, non-negative stock validation, and automatic `stock_logs` creation on every inventory change.
- **One-Tap Stock Adjustments (`-1`, `+1`, `+10`)**: Optimistic UI updates with automatic server rollback on error and offline queueing when connectivity drops.
- **Automated Low-Stock & Out-of-Stock Alerts**: Immediate status recalculation (`IN STOCK`, `LOW STOCK`, `OUT OF STOCK`) and dashboard alert banners.
- **Smart Reorder Assistant & WhatsApp PO Dispatch**: Consolidates items below minimum threshold or reorder point by wholesaler, supports inline quantity editing and item removal, formats WhatsApp PO messages with editable Store Profile details, exports `.txt` POs, and requires manual dispatch confirmation.
- **Fuzzy Search & Filtering**: Client-side debounced **Fuse.js** search across product name, SKU, barcode, and category, plus category tabs, stock status filters, and sorting.
- **Perishable Expiry Tracker**: Monitors expired items and 7 / 15 / 30-day approaching expiry windows without silently deleting expired stock.
- **Barcode Scanner**: Camera-powered EAN/UPC scanning via HTML5 Camera API & **QuaggaJS**, with instant manual barcode entry fallback.
- **Offline PWA & Conflict-Aware Sync**: Web App Manifest, Service Worker (`vite-plugin-pwa`), install prompt, `localStorage` offline queue with unique `operationId` deduplication, and a Sync Queue drawer flagging server conflicts for manual review.
- **45-Item ₹84,000 Demo Baseline + 15 Extra Templates**: Seeds 45 realistic Indian kirana items totaling ₹84,000 (including Atta at 6 packets for the acceptance workflow) plus 15 one-click catalog templates (60 items total).

---

## Project Structure

- `shared/` — Shared TypeScript interfaces and reusable business logic (`types.ts`, `businessLogic.ts`)
- `database/` — SQLite connection manager, versioned migrations, seed dataset, and CLI scripts (`init.ts`, `migrate.ts`)
- `backend/` — Express app factory, validators, inventory & analytics services, and REST API routes
- `frontend/` — Modular React components, API client, offline sync engine, and custom PWA/online hooks
- `src/` — Vite entry point and Tailwind CSS v4 styles
- `public/` — PWA SVG and PNG icon assets
- `tests/` — Vitest unit & Supertest end-to-end API tests
- `documentation/` — REST API and SQLite schema documentation

---

## Setup & Commands

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Initialize & migrate the SQLite database** (optional; also runs automatically on server startup):
   ```bash
   npm run db:migrate
   npm run db:init
   ```

3. **Run in development mode** (Express API + Vite middleware on port `3000`):
   ```bash
   npm run dev
   ```

4. **Run automated tests**:
   ```bash
   npm test
   ```

5. **Typecheck & build for production**:
   ```bash
   npm run lint
   npm run build
   npm start
   ```
