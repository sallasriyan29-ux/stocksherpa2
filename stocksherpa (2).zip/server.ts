import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import path from 'path';
import {createApp} from './backend/app.ts';
import {getDatabase} from './database/connection.ts';
import {runMigrations} from './database/migrations.ts';
import {seedInitialDatabase} from './database/seedData.ts';

async function startServer() {
  const port = Number(process.env.PORT || 3000);
  const db = getDatabase();
  runMigrations(db);
  seedInitialDatabase(db);

  const app = createApp(db);

  if (process.env.NODE_ENV !== 'production') {
    const {createServer: createViteServer} = await import('vite');
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexHtml = path.join(distDir, 'index.html');
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(404).send('Build output not found. Run npm run build first.');
      }
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`[StockSherpa] Server listening on http://localhost:${port}`);
  });
}

startServer().catch((err) => {
  console.error('[StockSherpa] Fatal startup error:', err);
  process.exit(1);
});
