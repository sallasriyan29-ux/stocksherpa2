# StockSherpa REST API Documentation

Base URL: `/api`

All endpoints return JSON. Validation errors return `400`, missing resources return `404`, and duplicate SKU/barcode/conflict errors return `409`.

---

## Health

### `GET /api/health`
Returns server status `{ "status": "ok", "service": "stocksherpa-api" }`.

---

## Products

### `GET /api/products`
Query parameters (optional):
- `category` — Filter by category name (`Grains`, `Dairy`, `Snacks`, `Personal Care`)
- `search` — Substring filter across `name`, `sku`, `barcode`, `category`
- `barcode` — Exact barcode match

Response `200`: `{ "products": ProductDTO[], "total": number }`

### `GET /api/products/:id`
Response `200`: `{ "product": ProductDTO }`

### `POST /api/products`
Creates a product and inserts an `INITIAL` stock ledger record atomically.
- Required body fields: `name`, `sku`, `categoryId`, `costPrice`, `sellingPrice`, `currentQty`, `minStockThreshold`, `reorderQty`
- Optional fields: `barcode`, `wholesalerId`, `unitLabel`, `reorderUnitLabel`, `reorderUnitCost`, `avgDailyDemand`, `leadTimeDays`, `safetyStock`, `expiryDate` (`YYYY-MM-DD`)

Response `201`: `{ "product": ProductDTO }`  
Errors: `400` validation failure, `409` duplicate SKU or barcode.

### `PUT /api/products/:id`
Updates product fields. If `currentQty` changes, automatically records an `ADJUSTMENT` entry in `stock_logs`.
Response `200`: `{ "product": ProductDTO }`

### `DELETE /api/products/:id`
Deletes a product and cascades its `stock_logs`.
Response `200`: `{ "deleted": true, "id": number }`

---

## Stock & Offline Synchronization

### `POST /api/stock/adjust`
Atomically updates inventory inside a `BEGIN IMMEDIATE` SQLite transaction and creates a `stock_logs` record.
Body:
```json
{
  "productId": 1,
  "delta": -1,
  "transactionType": "SALE",
  "operationId": "uuid-optional",
  "notes": "Quick sale (-1)"
}
```
Errors: `400` (`NEGATIVE_STOCK` if `currentQty + delta < 0`), `409` (`STOCK_CONFLICT` if `expectedPrevQty` mismatches).

### `POST /api/stock/sync`
Processes queued offline `OfflineSyncOperation[]` batches idempotently using `operationId`.
- Returns `APPLIED`, `DUPLICATE_IGNORED`, `CONFLICT` (when `serverQty !== expectedPrevQty` in `STRICT` mode), or `ERROR`.
- Supports conflict resolution modes `APPLY_DELTA` and `OVERWRITE_LOCAL`.

### `GET /api/stock/logs` & `GET /api/stock/logs/:productId`
Returns chronological stock ledger entries.

---

## Dashboard & Alerts

### `GET /api/dashboard/summary`
Computes live financial and operational metrics from SQLite:
- `totalProducts`, `totalInventoryQty`, `inventoryValueAtCost`, `expectedRetailTurnover`, `expectedGrossProfit`, `grossProfitMarginPct`, `inventoryTurnoverRatio`, `totalSalesCogs`, `lowStockCount`, `outOfStockCount`, `expiringCount`, `expiredCount`, `recentActivities`.

### `GET /api/alerts/low-stock`
Returns all products with `LOW_STOCK` or `OUT_OF_STOCK` status.

### `GET /api/alerts/expiring?days=30`
Returns expired products and products expiring within `days` days.

---

## Reordering & Purchase Orders

### `GET /api/reorder`
Returns items qualifying for replenishment grouped by wholesaler (`WholesalerOrderGroup[]`).

### `POST /api/reorder/generate`
Generates a formatted WhatsApp Purchase Order message using the Store Profile and persists the PO in `purchase_orders` + `purchase_order_items`.

### `GET /api/reorder/orders` & `PATCH /api/reorder/orders/:id/dispatch`
Lists saved purchase orders and marks an order as manually `DISPATCHED`.

---

## Categories, Wholesalers, Templates & Store Profile

- `GET /api/categories`
- `GET /api/wholesalers`, `POST /api/wholesalers`, `PUT /api/wholesalers/:id`
- `GET /api/templates`, `POST /api/templates/:sku/import`
- `GET /api/store-profile`, `PUT /api/store-profile`
