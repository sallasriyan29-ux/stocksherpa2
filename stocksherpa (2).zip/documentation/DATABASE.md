# StockSherpa SQLite Database Architecture

StockSherpa uses relational SQLite persistence (`better-sqlite3`) with `PRAGMA foreign_keys = ON` and `PRAGMA journal_mode = WAL`.

## Tables & Relationships

1. **`categories`**
   - `id` (PK), `name` (UNIQUE), `description`
   - Seeds 4 kirana categories: `Grains`, `Dairy`, `Snacks`, `Personal Care`.

2. **`wholesalers`**
   - `id` (PK), `name` (UNIQUE), `phone`, `contact_person`, `notes`, `created_at`, `updated_at`
   - Stores supplier WhatsApp numbers and contact details.

3. **`products`**
   - `id` (PK), `name`, `sku` (UNIQUE), `barcode` (UNIQUE)
   - `category_id` (FK -> `categories.id`, `ON DELETE RESTRICT`)
   - `wholesaler_id` (FK -> `wholesalers.id`, `ON DELETE SET NULL`)
   - `cost_price` (`>= 0`), `selling_price` (`>= 0`)
   - `current_qty` (`>= 0`), `min_stock_threshold` (`>= 0`), `reorder_qty` (`>= 1`)
   - `unit_label`, `reorder_unit_label`, `reorder_unit_cost`
   - `avg_daily_demand`, `lead_time_days`, `safety_stock`, `expiry_date`, `is_demo`
   - Indexes: `idx_products_sku`, `idx_products_barcode`, `idx_products_category`, `idx_products_wholesaler`, `idx_products_expiry`

4. **`stock_logs`**
   - `id` (PK), `product_id` (FK -> `products.id`, `ON DELETE CASCADE`)
   - `prev_qty`, `new_qty`, `qty_changed`, `transaction_type` (`SALE`, `RESTOCK`, `ADJUSTMENT`, `INITIAL`, `RETURN`, `SPOILAGE`)
   - `operation_id` (UNIQUE partial index for idempotent offline sync deduplication)
   - `notes`, `created_at`
   - Index: `idx_stock_logs_product_date`

5. **`store_profile`**
   - Singleton (`id = 1`) storing `shop_name`, `owner_name`, `phone`, `address`, `gstin`.

6. **`purchase_orders` & `purchase_order_items`**
   - Persists generated WhatsApp Purchase Orders (`DRAFT` / `DISPATCHED`) and line-item quantities/costs.

## Migrations & Initialization

- Run `npm run db:migrate` to apply schema migrations (`database/migrate.ts`).
- Run `npm run db:init` to run migrations and seed the 45-item ₹84,000 demonstration inventory (`database/init.ts`).
- The application server (`server.ts`) also runs migrations and ensures initial seed state idempotently on startup.
