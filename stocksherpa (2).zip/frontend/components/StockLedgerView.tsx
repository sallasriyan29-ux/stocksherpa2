import {ArrowDownRight, ArrowUpRight, Search} from 'lucide-react';
import React, {useMemo, useState} from 'react';
import type {StockLog} from '../../shared/types.ts';

interface StockLedgerViewProps {
  logs: StockLog[];
  onRefresh: () => void;
}

export const StockLedgerView: React.FC<StockLedgerViewProps> = ({
  logs,
  onRefresh,
}) => {
  const [query, setQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');

  const filtered = useMemo(() => {
    return logs.filter((l) => {
      if (typeFilter !== 'ALL' && l.transactionType !== typeFilter) {
        return false;
      }
      if (!query.trim()) return true;
      const q = query.trim().toLowerCase();
      return (
        (l.productName || '').toLowerCase().includes(q) ||
        (l.sku || '').toLowerCase().includes(q) ||
        (l.notes || '').toLowerCase().includes(q)
      );
    });
  }, [logs, query, typeFilter]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Stock Ledger</h2>
          <p className="text-xs text-slate-500">
            Immutable audit log of every stock addition, sale, adjustment, and sync operation
          </p>
        </div>
        <button
          type="button"
          onClick={onRefresh}
          className="self-start rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
        >
          Refresh Ledger
        </button>
      </div>

      <div className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter ledger by product, SKU, or notes..."
            className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm focus:border-emerald-600 focus:bg-white focus:outline-none"
          />
        </div>
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          aria-label="Filter transaction type"
          className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 focus:outline-none cursor-pointer"
        >
          <option value="ALL">All Types</option>
          <option value="SALE">Sales (-)</option>
          <option value="RESTOCK">Restocks (+)</option>
          <option value="ADJUSTMENT">Adjustments</option>
          <option value="INITIAL">Initial Seed / Created</option>
        </select>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No matching ledger entries found.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="px-4 py-3">Date & Time</th>
                  <th className="px-4 py-3">Product</th>
                  <th className="px-3 py-3">Type</th>
                  <th className="px-3 py-3 text-right">Delta</th>
                  <th className="px-3 py-3 text-right">Prev → New</th>
                  <th className="px-4 py-3">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/60">
                    <td className="px-4 py-2.5 font-mono text-xs text-slate-500 whitespace-nowrap tabular-nums">
                      {new Date(log.createdAt).toLocaleString('en-IN')}
                    </td>
                    <td className="px-4 py-2.5">
                      <p className="font-semibold text-slate-900">
                        {log.productName}
                      </p>
                      <p className="font-mono text-[11px] text-slate-500">
                        {log.sku}
                      </p>
                    </td>
                    <td className="px-3 py-2.5 text-xs font-semibold text-slate-700">
                      {log.transactionType}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums">
                      <span
                        className={`inline-flex items-center gap-0.5 font-bold ${
                          log.qtyChanged < 0
                            ? 'text-red-600'
                            : log.qtyChanged > 0
                              ? 'text-emerald-700'
                              : 'text-slate-600'
                        }`}
                      >
                        {log.qtyChanged < 0 ? (
                          <ArrowDownRight className="h-3.5 w-3.5" />
                        ) : log.qtyChanged > 0 ? (
                          <ArrowUpRight className="h-3.5 w-3.5" />
                        ) : null}
                        {log.qtyChanged > 0
                          ? `+${log.qtyChanged}`
                          : log.qtyChanged}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-xs text-slate-600 tabular-nums">
                      {log.prevQty} →{' '}
                      <strong className="text-slate-900">{log.newQty}</strong>
                    </td>
                    <td className="px-4 py-2.5 text-xs text-slate-500">
                      {log.notes || '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
