import React from 'react';
import type {ExpiryStatus, StockStatus} from '../../shared/types.ts';

export const StockStatusBadge: React.FC<{status: StockStatus}> = ({status}) => {
  if (status === 'OUT_OF_STOCK') {
    return (
      <span className="inline-flex items-center rounded-md bg-red-600 px-2 py-0.5 text-[11px] font-semibold tracking-wide text-white whitespace-nowrap shrink-0">
        OUT OF STOCK
      </span>
    );
  }
  if (status === 'LOW_STOCK') {
    return (
      <span className="inline-flex items-center rounded-md border border-red-300 bg-red-50 px-2 py-0.5 text-[11px] font-semibold tracking-wide text-red-700 whitespace-nowrap shrink-0">
        LOW STOCK
      </span>
    );
  }
  return (
    <span className="inline-flex items-center rounded-md border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold tracking-wide text-emerald-700 whitespace-nowrap shrink-0">
      IN STOCK
    </span>
  );
};

export const ExpiryStatusBadge: React.FC<{
  status: ExpiryStatus;
  daysUntilExpiry: number | null;
}> = ({status, daysUntilExpiry}) => {
  if (status === 'NONE' || daysUntilExpiry === null) {
    return null;
  }

  if (status === 'EXPIRED') {
    const overdueDays = Math.abs(daysUntilExpiry);
    return (
      <span className="inline-flex items-center rounded-md bg-red-600 px-2 py-0.5 text-[11px] font-semibold text-white whitespace-nowrap shrink-0">
        EXPIRED {overdueDays === 0 ? 'today' : `${overdueDays}d ago`}
      </span>
    );
  }

  if (status === 'EXPIRING_7') {
    return (
      <span className="inline-flex items-center rounded-md border border-red-300 bg-red-50 px-2 py-0.5 text-[11px] font-semibold text-red-700 whitespace-nowrap shrink-0">
        Expires in {daysUntilExpiry}d
      </span>
    );
  }

  if (status === 'EXPIRING_15' || status === 'EXPIRING_30') {
    return (
      <span className="inline-flex items-center rounded-md border border-amber-300 bg-amber-50 px-2 py-0.5 text-[11px] font-semibold text-amber-800 whitespace-nowrap shrink-0">
        Expires in {daysUntilExpiry}d
      </span>
    );
  }

  return (
    <span className="text-xs text-slate-500 tabular-nums whitespace-nowrap">
      {daysUntilExpiry}d left
    </span>
  );
};
