import {
  AlertTriangle,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Clock,
  IndianRupee,
  Package,
  ShoppingCart,
  TrendingUp,
} from 'lucide-react';
import React from 'react';
import {formatINR} from '../../shared/businessLogic.ts';
import type {DashboardSummary, ProductDTO} from '../../shared/types.ts';
import {ExpiryStatusBadge, StockStatusBadge} from './StatusBadges.tsx';

interface DashboardViewProps {
  summary: DashboardSummary | null;
  lowStockItems: ProductDTO[];
  expiringItems: ProductDTO[];
  isLoading: boolean;
  onNavigate: (
    tab: 'dashboard' | 'inventory' | 'reorder' | 'expiry' | 'ledger' | 'settings'
  ) => void;
  onQuickFilterLowStock: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  summary,
  lowStockItems,
  expiringItems,
  isLoading,
  onNavigate,
  onQuickFilterLowStock,
}) => {
  if (isLoading && !summary) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({length: 8}).map((_, idx) => (
            <div
              key={idx}
              className="h-28 animate-pulse rounded-xl border border-slate-200 bg-white p-5"
            />
          ))}
        </div>
      </div>
    );
  }

  if (!summary) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-8 text-center">
        <p className="text-sm text-slate-600">
          Unable to load dashboard summary. Check connection or refresh.
        </p>
      </div>
    );
  }

  const attentionCount = summary.lowStockCount + summary.outOfStockCount;

  return (
    <div className="space-y-6">
      {/* Low-Stock Alert Banner */}
      {attentionCount > 0 && (
        <div className="flex flex-col gap-3 rounded-xl border border-red-200 bg-red-50 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-red-600" />
            <div>
              <h2 className="text-sm font-bold text-red-900">
                Stock Replenishment Required ({attentionCount} items)
              </h2>
              <p className="mt-0.5 text-xs text-red-800">
                {summary.outOfStockCount} out of stock and{' '}
                {summary.lowStockCount} below minimum threshold. Review your
                consolidated wholesaler purchase orders.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onQuickFilterLowStock}
              className="rounded-lg border border-red-300 bg-white px-3 py-2 text-xs font-semibold text-red-700 hover:bg-red-100 transition-colors cursor-pointer whitespace-nowrap"
            >
              View Low Stock
            </button>
            <button
              type="button"
              onClick={() => onNavigate('reorder')}
              className="inline-flex items-center gap-1.5 rounded-lg bg-red-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-red-700 transition-colors cursor-pointer whitespace-nowrap"
            >
              <ShoppingCart className="h-3.5 w-3.5" />
              <span>Open Reorder Assistant</span>
            </button>
          </div>
        </div>
      )}

      {/* Primary Financial & Inventory KPI Grid */}
      <section aria-label="Store KPIs">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Inventory Value (Cost)</span>
              <IndianRupee className="h-4 w-4 text-emerald-600" />
            </div>
            <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {formatINR(summary.inventoryValueAtCost)}
            </p>
            <p className="mt-1 text-xs text-slate-500 tabular-nums">
              Across {summary.totalProducts} products · {summary.totalInventoryQty} units
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Expected Retail Turnover</span>
              <TrendingUp className="h-4 w-4 text-emerald-600" />
            </div>
            <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {formatINR(summary.expectedRetailTurnover)}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Potential revenue from current stock
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Expected Gross Profit</span>
              <ArrowUpRight className="h-4 w-4 text-emerald-600" />
            </div>
            <p className="mt-2 font-mono text-2xl font-bold text-emerald-700 tabular-nums">
              {formatINR(summary.expectedGrossProfit)}
            </p>
            <p className="mt-1 text-xs text-slate-600 tabular-nums">
              Gross Margin: <strong className="font-mono">{summary.grossProfitMarginPct}%</strong>
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Inventory Turnover (Sales)</span>
              <Package className="h-4 w-4 text-slate-500" />
            </div>
            <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {summary.inventoryTurnoverRatio !== null
                ? `${summary.inventoryTurnoverRatio}x`
                : '0.00x'}
            </p>
            <p className="mt-1 text-xs text-slate-500 tabular-nums">
              {summary.totalSalesCogs > 0
                ? `Recorded Sales COGS: ${formatINR(summary.totalSalesCogs)}`
                : 'No sales recorded yet'}
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Total Products</span>
            </div>
            <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {summary.totalProducts}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Active SKUs in catalog
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Total Inventory Quantity</span>
            </div>
            <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {summary.totalInventoryQty}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Combined units on shelves
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Low-Stock & Out-of-Stock</span>
            </div>
            <div className="mt-2 flex items-baseline gap-3">
              <span className="font-mono text-2xl font-bold text-red-600 tabular-nums">
                {summary.lowStockCount}
              </span>
              <span className="text-xs text-slate-500">low</span>
              <span className="text-slate-300">·</span>
              <span className="font-mono text-xl font-bold text-red-700 tabular-nums">
                {summary.outOfStockCount}
              </span>
              <span className="text-xs text-slate-500">out</span>
            </div>
            <p className="mt-1 text-xs text-slate-500">
              Below minimum threshold
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Expiring & Expired Items</span>
              <Clock className="h-4 w-4 text-amber-600" />
            </div>
            <div className="mt-2 flex items-baseline gap-3">
              <span className="font-mono text-2xl font-bold text-amber-700 tabular-nums">
                {summary.expiringCount}
              </span>
              <span className="text-xs text-slate-500">within 30d</span>
              <span className="text-slate-300">·</span>
              <span className="font-mono text-xl font-bold text-red-600 tabular-nums">
                {summary.expiredCount}
              </span>
              <span className="text-xs text-slate-500">expired</span>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('expiry')}
              className="mt-1 text-xs font-semibold text-emerald-700 hover:underline cursor-pointer"
            >
              Inspect expiry tracker
            </button>
          </div>
        </div>
      </section>

      {/* Two-Column Actionable Panels: Low Stock Queue + Expiring Soon */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Low Stock Section */}
        <section className="rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Low-Stock Watchlist
              </h2>
              <p className="text-xs text-slate-500">
                Products at zero or below configured minimum threshold
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('reorder')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer whitespace-nowrap"
            >
              <span>Reorder All</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
          {lowStockItems.length === 0 ? (
            <div className="p-6 text-center text-sm text-slate-500">
              All products are currently stocked above minimum thresholds.
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {lowStockItems.slice(0, 6).map((item) => (
                <li
                  key={item.id}
                  className="flex items-center justify-between gap-4 px-5 py-3.5"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-slate-900">
                      {item.name}
                    </p>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {item.categoryName} · {item.sku} · Min {item.minStockThreshold}{' '}
                      {item.unitLabel}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                      {item.currentQty} {item.unitLabel}
                    </span>
                    <StockStatusBadge status={item.stockStatus} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Expiring Watchlist */}
        <section className="rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Perishable Expiry Watchlist
              </h2>
              <p className="text-xs text-slate-500">
                Expired or expiring within the next 30 days
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('expiry')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer whitespace-nowrap"
            >
              <span>Full Tracker</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
          {expiringItems.length === 0 ? (
            <div className="p-6 text-center text-sm text-slate-500">
              No products expiring within 30 days.
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {expiringItems.slice(0, 6).map((item) => (
                <li
                  key={item.id}
                  className="flex items-center justify-between gap-4 px-5 py-3.5"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-slate-900">
                      {item.name}
                    </p>
                    <p className="mt-0.5 text-xs text-slate-500 tabular-nums">
                      {item.currentQty} {item.unitLabel} in shelf · Expiry{' '}
                      {item.expiryDate}
                    </p>
                  </div>
                  <ExpiryStatusBadge
                    status={item.expiryStatus}
                    daysUntilExpiry={item.daysUntilExpiry}
                  />
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* Recent Stock Activities */}
      <section className="rounded-xl border border-slate-200 bg-white">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Recent Stock Activities
            </h2>
            <p className="text-xs text-slate-500">
              Audit ledger of every stock increment, sale, and catalog update
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('ledger')}
            className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer whitespace-nowrap"
          >
            <span>Full Ledger</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
        {summary.recentActivities.length === 0 ? (
          <div className="p-6 text-center text-sm text-slate-500">
            No stock activities recorded yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                  <th className="px-5 py-2.5">Product</th>
                  <th className="px-4 py-2.5">Type</th>
                  <th className="px-4 py-2.5 text-right">Change</th>
                  <th className="px-4 py-2.5 text-right">Stock</th>
                  <th className="px-5 py-2.5">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {summary.recentActivities.slice(0, 8).map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/60">
                    <td className="px-5 py-2.5">
                      <p className="font-medium text-slate-900">
                        {log.productName}
                      </p>
                      <p className="text-xs text-slate-500 font-mono">
                        {log.sku}
                      </p>
                    </td>
                    <td className="px-4 py-2.5 text-xs font-medium text-slate-600">
                      {log.transactionType}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums">
                      <span
                        className={`inline-flex items-center gap-0.5 font-semibold ${
                          log.qtyChanged < 0
                            ? 'text-red-600'
                            : log.qtyChanged > 0
                              ? 'text-emerald-700'
                              : 'text-slate-600'
                        }`}
                      >
                        {log.qtyChanged < 0 ? (
                          <ArrowDownRight className="h-3.5 w-3.5" />
                        ) : log.qtyChanged > 0 ? (
                          <ArrowUpRight className="h-3.5 w-3.5" />
                        ) : null}
                        {log.qtyChanged > 0
                          ? `+${log.qtyChanged}`
                          : log.qtyChanged}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-xs text-slate-600 tabular-nums">
                      {log.prevQty} → <strong className="text-slate-900">{log.newQty}</strong>
                    </td>
                    <td className="px-5 py-2.5 text-xs text-slate-500 max-w-xs truncate">
                      {log.notes || '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <p className="text-xs text-slate-500">
        Initial 45-item store inventory (₹84,000 cost basis) is provided as a demonstration baseline. Any products you add, edit, delete, or adjust are persisted directly in SQLite.
      </p>
    </div>
  );
};
