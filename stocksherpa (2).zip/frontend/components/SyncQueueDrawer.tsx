import {AlertTriangle, RefreshCw, Trash2, X} from 'lucide-react';
import React from 'react';
import type {OfflineSyncOperation} from '../../shared/types.ts';
import type {SyncConflictItem} from '../services/offlineSync.ts';

interface SyncQueueDrawerProps {
  isOpen: boolean;
  isOnline: boolean;
  isSyncing: boolean;
  pendingOps: OfflineSyncOperation[];
  conflicts: SyncConflictItem[];
  lastSyncAt: string | null;
  onClose: () => void;
  onSyncNow: () => void;
  onResolveConflict: (
    operationId: string,
    strategy: 'APPLY_DELTA' | 'OVERWRITE_LOCAL' | 'DISCARD'
  ) => void;
  onDiscardPending: (operationId: string) => void;
}

export const SyncQueueDrawer: React.FC<SyncQueueDrawerProps> = ({
  isOpen,
  isOnline,
  isSyncing,
  pendingOps,
  conflicts,
  lastSyncAt,
  onClose,
  onSyncNow,
  onResolveConflict,
  onDiscardPending,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-900/40"
      role="dialog"
      aria-modal="true"
      aria-label="Offline Sync Queue"
    >
      <div className="flex h-full w-full max-w-lg flex-col border-l border-slate-200 bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Offline Sync Queue
            </h2>
            <p className="text-xs text-slate-500">
              {isOnline ? 'Connected to server' : 'Offline — changes queued locally'}
              {lastSyncAt
                ? ` · Last sync ${new Date(lastSyncAt).toLocaleTimeString('en-IN')}`
                : ''}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 cursor-pointer"
            aria-label="Close sync queue"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Flagged Conflicts Section */}
          {conflicts.length > 0 && (
            <section className="space-y-3">
              <div className="flex items-center gap-2 text-red-700">
                <AlertTriangle className="h-4 w-4" />
                <h3 className="text-sm font-bold">
                  Sync Conflicts Requiring Review ({conflicts.length})
                </h3>
              </div>
              <p className="text-xs text-slate-600">
                Server inventory changed while offline. Choose how to resolve each conflicting item—nothing is silently overwritten.
              </p>

              <div className="space-y-3">
                {conflicts.map((c) => {
                  const localTarget = Math.max(
                    0,
                    c.operation.expectedPrevQty + c.operation.delta
                  );
                  return (
                    <div
                      key={c.operation.operationId}
                      className="rounded-xl border border-red-200 bg-red-50/50 p-4 space-y-3"
                    >
                      <div>
                        <p className="text-sm font-bold text-slate-900">
                          {c.operation.productName}
                        </p>
                        <p className="text-xs text-red-700">{c.message}</p>
                      </div>

                      <div className="grid grid-cols-3 gap-2 rounded-lg border border-slate-200 bg-white p-2.5 text-center font-mono text-xs tabular-nums">
                        <div>
                          <p className="text-[10px] text-slate-500">Offline Baseline</p>
                          <p className="font-bold text-slate-800">
                            {c.operation.expectedPrevQty}
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-500">Offline Change</p>
                          <p className="font-bold text-slate-900">
                            {c.operation.delta > 0
                              ? `+${c.operation.delta}`
                              : c.operation.delta}
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-500">Current Server</p>
                          <p className="font-bold text-emerald-700">
                            {c.serverQty}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        <button
                          type="button"
                          disabled={!isOnline || c.serverQty + c.operation.delta < 0}
                          onClick={() =>
                            onResolveConflict(
                              c.operation.operationId,
                              'APPLY_DELTA'
                            )
                          }
                          className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-40 cursor-pointer"
                        >
                          Apply Delta (→ {c.serverQty + c.operation.delta})
                        </button>
                        <button
                          type="button"
                          disabled={!isOnline}
                          onClick={() =>
                            onResolveConflict(
                              c.operation.operationId,
                              'OVERWRITE_LOCAL'
                            )
                          }
                          className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                        >
                          Use Local Target ({localTarget})
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onResolveConflict(c.operation.operationId, 'DISCARD')
                          }
                          className="rounded-lg border border-red-200 bg-white px-3 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-50 cursor-pointer"
                        >
                          Keep Server ({c.serverQty})
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          )}

          {/* Pending Operations */}
          <section className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900">
              Pending Transactions ({pendingOps.length})
            </h3>
            {pendingOps.length === 0 ? (
              <p className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs text-slate-500">
                No pending offline stock adjustments waiting to upload.
              </p>
            ) : (
              <ul className="divide-y divide-slate-100 rounded-xl border border-slate-200">
                {pendingOps.map((op) => (
                  <li
                    key={op.operationId}
                    className="flex items-center justify-between gap-3 px-4 py-3 text-xs"
                  >
                    <div>
                      <p className="font-semibold text-slate-900">
                        {op.productName}
                      </p>
                      <p className="font-mono text-slate-500">
                        {op.delta > 0 ? `+${op.delta}` : op.delta} · Baseline{' '}
                        {op.expectedPrevQty} · {op.transactionType}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onDiscardPending(op.operationId)}
                      aria-label="Discard queued operation"
                      className="rounded p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600 cursor-pointer"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        <div className="border-t border-slate-200 px-6 py-4">
          <button
            type="button"
            disabled={!isOnline || isSyncing || pendingOps.length === 0}
            onClick={onSyncNow}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 py-2.5 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-40 cursor-pointer"
          >
            <RefreshCw
              className={`h-4 w-4 ${isSyncing ? 'animate-spin' : ''}`}
            />
            <span>
              {isSyncing ? 'Synchronizing...' : 'Synchronize Pending Operations'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
