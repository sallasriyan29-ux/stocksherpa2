import Fuse from 'fuse.js';
import {
  ArrowUpDown,
  Edit3,
  Eye,
  Filter,
  Layers,
  Minus,
  Plus,
  ScanBarcode,
  Search,
  X,
} from 'lucide-react';
import React, {useEffect, useMemo, useState} from 'react';
import {formatINR} from '../../shared/businessLogic.ts';
import type {Category, ProductDTO} from '../../shared/types.ts';
import {ExpiryStatusBadge, StockStatusBadge} from './StatusBadges.tsx';

export type SortKey =
  | 'name_asc'
  | 'qty_asc'
  | 'qty_desc'
  | 'value_desc'
  | 'expiry_asc';

interface InventoryViewProps {
  products: ProductDTO[];
  categories: Category[];
  initialStatusFilter?: 'ALL' | 'LOW_STOCK' | 'OUT_OF_STOCK' | 'IN_STOCK';
  onAdjustStock: (product: ProductDTO, delta: number) => void;
  onViewProduct: (product: ProductDTO) => void;
  onEditProduct: (product: ProductDTO) => void;
  onAddProduct: () => void;
  onOpenScanner: () => void;
  onOpenTemplates: () => void;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  products,
  categories,
  initialStatusFilter = 'ALL',
  onAdjustStock,
  onViewProduct,
  onEditProduct,
  onAddProduct,
  onOpenScanner,
  onOpenTemplates,
}) => {
  const [searchInput, setSearchInput] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<
    'ALL' | 'LOW_STOCK' | 'OUT_OF_STOCK' | 'IN_STOCK'
  >(initialStatusFilter);
  const [sortBy, setSortBy] = useState<SortKey>('name_asc');

  useEffect(() => {
    setStatusFilter(initialStatusFilter);
  }, [initialStatusFilter]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setDebouncedSearch(searchInput.trim());
    }, 180);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  const fuse = useMemo(() => {
    return new Fuse(products, {
      keys: [
        {name: 'name', weight: 0.55},
        {name: 'sku', weight: 0.25},
        {name: 'barcode', weight: 0.15},
        {name: 'categoryName', weight: 0.05},
      ],
      threshold: 0.35,
      ignoreLocation: true,
    });
  }, [products]);

  const filteredProducts = useMemo(() => {
    let list = debouncedSearch
      ? fuse.search(debouncedSearch).map((res) => res.item)
      : [...products];

    if (selectedCategory !== 'ALL') {
      list = list.filter(
        (p) => p.categoryName.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    if (statusFilter !== 'ALL') {
      if (statusFilter === 'LOW_STOCK') {
        list = list.filter(
          (p) =>
            p.stockStatus === 'LOW_STOCK' || p.stockStatus === 'OUT_OF_STOCK'
        );
      } else {
        list = list.filter((p) => p.stockStatus === statusFilter);
      }
    }

    list.sort((a, b) => {
      switch (sortBy) {
        case 'qty_asc':
          return a.currentQty - b.currentQty;
        case 'qty_desc':
          return b.currentQty - a.currentQty;
        case 'value_desc':
          return b.inventoryValue - a.inventoryValue;
        case 'expiry_asc': {
          const da = a.daysUntilExpiry ?? 99999;
          const db = b.daysUntilExpiry ?? 99999;
          return da - db;
        }
        case 'name_asc':
        default:
          return a.name.localeCompare(b.name);
      }
    });

    return list;
  }, [products, fuse, debouncedSearch, selectedCategory, statusFilter, sortBy]);

  const hasActiveFilters =
    searchInput.trim() !== '' ||
    selectedCategory !== 'ALL' ||
    statusFilter !== 'ALL';

  const clearFilters = () => {
    setSearchInput('');
    setDebouncedSearch('');
    setSelectedCategory('ALL');
    setStatusFilter('ALL');
  };

  return (
    <div className="space-y-4">
      {/* Search, Scan, Sort & Template Toolbar */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search by product name, SKU, barcode, or category (e.g. Atta)..."
              aria-label="Search inventory"
              className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2.5 pl-9 pr-9 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:bg-white focus:outline-none"
            />
            {searchInput && (
              <button
                type="button"
                onClick={() => setSearchInput('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
                aria-label="Clear search"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onOpenScanner}
              className="inline-flex min-h-[42px] items-center gap-2 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
            >
              <ScanBarcode className="h-4 w-4 text-emerald-600" />
              <span>Scan Barcode</span>
            </button>
            <button
              type="button"
              onClick={onOpenTemplates}
              className="inline-flex min-h-[42px] items-center gap-2 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
            >
              <Layers className="h-4 w-4 text-slate-600" />
              <span>15 Extra Templates</span>
            </button>
          </div>
        </div>

        {/* Category Segmented Filter + Status & Sort */}
        <div className="flex flex-col gap-3 pt-1 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1">
            {['ALL', ...categories.map((c) => c.name)].map((catName) => {
              const active = selectedCategory === catName;
              return (
                <button
                  key={catName}
                  type="button"
                  onClick={() => setSelectedCategory(catName)}
                  className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                    active
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {catName === 'ALL' ? 'All Categories' : catName}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5">
              <Filter className="h-3.5 w-3.5 text-slate-500" />
              <select
                value={statusFilter}
                onChange={(e) =>
                  setStatusFilter(
                    e.target.value as
                      | 'ALL'
                      | 'LOW_STOCK'
                      | 'OUT_OF_STOCK'
                      | 'IN_STOCK'
                  )
                }
                aria-label="Filter by stock status"
                className="bg-transparent text-xs font-medium text-slate-700 focus:outline-none cursor-pointer"
              >
                <option value="ALL">All Stock Levels</option>
                <option value="LOW_STOCK">Low & Out of Stock</option>
                <option value="OUT_OF_STOCK">Out of Stock Only</option>
                <option value="IN_STOCK">Healthy Stock</option>
              </select>
            </div>

            <div className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5">
              <ArrowUpDown className="h-3.5 w-3.5 text-slate-500" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortKey)}
                aria-label="Sort inventory"
                className="bg-transparent text-xs font-medium text-slate-700 focus:outline-none cursor-pointer"
              >
                <option value="name_asc">Name (A–Z)</option>
                <option value="qty_asc">Stock: Low to High</option>
                <option value="qty_desc">Stock: High to Low</option>
                <option value="value_desc">Inventory Value</option>
                <option value="expiry_asc">Expiry: Soonest First</option>
              </select>
            </div>

            {hasActiveFilters && (
              <button
                type="button"
                onClick={clearFilters}
                className="text-xs font-semibold text-emerald-700 hover:underline px-2 py-1.5 cursor-pointer whitespace-nowrap"
              >
                Clear Filters
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between px-1 text-xs text-slate-500">
        <span className="tabular-nums">
          Showing <strong className="text-slate-800">{filteredProducts.length}</strong> of{' '}
          {products.length} products
        </span>
      </div>

      {/* Empty State */}
      {filteredProducts.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
          <p className="text-base font-semibold text-slate-900">
            No matching products found
          </p>
          <p className="mt-1 text-sm text-slate-500">
            Try adjusting your search query or clearing category and stock filters.
          </p>
          <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
            {hasActiveFilters && (
              <button
                type="button"
                onClick={clearFilters}
                className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Clear Filters
              </button>
            )}
            <button
              type="button"
              onClick={onAddProduct}
              className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 cursor-pointer"
            >
              Add New Product
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Mobile Card Layout (< 640px) — Zero horizontal scroll, >=44px touch controls */}
          <div className="space-y-3 sm:hidden">
            {filteredProducts.map((product) => (
              <article
                key={product.id}
                className="rounded-2xl border border-slate-200 bg-white p-4"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <button
                      type="button"
                      onClick={() => onViewProduct(product)}
                      className="text-left text-sm font-bold text-slate-900 hover:text-emerald-700 cursor-pointer"
                    >
                      {product.name}
                    </button>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {product.categoryName} · {product.sku}
                    </p>
                  </div>
                  <StockStatusBadge status={product.stockStatus} />
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3">
                  <div>
                    <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                      {product.currentQty}{' '}
                      <span className="text-xs font-normal text-slate-500">
                        {product.unitLabel}
                      </span>
                    </p>
                    <p className="text-xs text-slate-500 font-mono tabular-nums">
                      Cost {formatINR(product.costPrice)} · MRP {formatINR(product.sellingPrice)}
                    </p>
                  </div>
                  <ExpiryStatusBadge
                    status={product.expiryStatus}
                    daysUntilExpiry={product.daysUntilExpiry}
                  />
                </div>

                {/* One-Handed Quick Stock Adjustment Buttons */}
                <div className="mt-3 grid grid-cols-4 gap-2">
                  <button
                    type="button"
                    disabled={product.currentQty <= 0}
                    onClick={() => onAdjustStock(product, -1)}
                    aria-label={`Sell 1 ${product.name}`}
                    className="flex min-h-[44px] items-center justify-center gap-1 rounded-xl border border-slate-200 bg-slate-50 text-sm font-bold text-slate-800 hover:bg-red-50 hover:text-red-700 disabled:opacity-40 disabled:cursor-not-allowed active:scale-95 transition cursor-pointer"
                  >
                    <Minus className="h-3.5 w-3.5" />
                    <span>1</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onAdjustStock(product, 1)}
                    aria-label={`Add 1 ${product.name}`}
                    className="flex min-h-[44px] items-center justify-center gap-1 rounded-xl border border-emerald-200 bg-emerald-50 text-sm font-bold text-emerald-800 hover:bg-emerald-100 active:scale-95 transition cursor-pointer"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>1</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onAdjustStock(product, 10)}
                    aria-label={`Restock 10 ${product.name}`}
                    className="flex min-h-[44px] items-center justify-center gap-1 rounded-xl bg-emerald-600 text-sm font-bold text-white hover:bg-emerald-700 active:scale-95 transition cursor-pointer"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>10</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onEditProduct(product)}
                    aria-label={`Edit ${product.name}`}
                    className="flex min-h-[44px] items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 cursor-pointer"
                  >
                    <Edit3 className="h-4 w-4" />
                  </button>
                </div>
              </article>
            ))}
          </div>

          {/* Desktop High-Density Table (>= 640px) */}
          <div className="hidden sm:block rounded-xl border border-slate-200 bg-white overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="px-4 py-3">Product & Supplier</th>
                    <th className="px-3 py-3">SKU / Barcode</th>
                    <th className="px-3 py-3 text-right">Cost / Sell</th>
                    <th className="px-3 py-3 text-right">Stock</th>
                    <th className="px-3 py-3">Status & Expiry</th>
                    <th className="px-4 py-3 text-right">Quick Adjust</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredProducts.map((product) => (
                    <tr
                      key={product.id}
                      className="hover:bg-slate-50/80 transition-colors"
                    >
                      <td className="px-4 py-3">
                        <button
                          type="button"
                          onClick={() => onViewProduct(product)}
                          className="text-left font-semibold text-slate-900 hover:text-emerald-700 cursor-pointer"
                        >
                          {product.name}
                        </button>
                        <p className="mt-0.5 text-xs text-slate-500">
                          {product.categoryName} ·{' '}
                          {product.wholesalerName || 'Unassigned Supplier'}
                        </p>
                      </td>
                      <td className="px-3 py-3 font-mono text-xs text-slate-600 tabular-nums">
                        <div className="font-semibold text-slate-800">
                          {product.sku}
                        </div>
                        <div className="text-slate-400">
                          {product.barcode || 'No barcode'}
                        </div>
                      </td>
                      <td className="px-3 py-3 text-right font-mono text-xs tabular-nums">
                        <div className="text-slate-900 font-semibold">
                          {formatINR(product.sellingPrice)}
                        </div>
                        <div className="text-slate-500">
                          Cost {formatINR(product.costPrice)}
                        </div>
                      </td>
                      <td className="px-3 py-3 text-right font-mono tabular-nums">
                        <div className="text-sm font-bold text-slate-900">
                          {product.currentQty}{' '}
                          <span className="text-xs font-normal text-slate-500">
                            {product.unitLabel}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          Min {product.minStockThreshold}
                        </div>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex flex-col items-start gap-1">
                          <StockStatusBadge status={product.stockStatus} />
                          <ExpiryStatusBadge
                            status={product.expiryStatus}
                            daysUntilExpiry={product.daysUntilExpiry}
                          />
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            disabled={product.currentQty <= 0}
                            onClick={() => onAdjustStock(product, -1)}
                            title="Decrement 1 (Sale)"
                            className="inline-flex h-8 min-w-[38px] items-center justify-center rounded-md border border-slate-200 bg-white px-2 font-mono text-xs font-semibold text-slate-700 hover:border-red-300 hover:bg-red-50 hover:text-red-700 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                          >
                            -1
                          </button>
                          <button
                            type="button"
                            onClick={() => onAdjustStock(product, 1)}
                            title="Increment 1"
                            className="inline-flex h-8 min-w-[38px] items-center justify-center rounded-md border border-emerald-200 bg-emerald-50 px-2 font-mono text-xs font-semibold text-emerald-800 hover:bg-emerald-100 cursor-pointer"
                          >
                            +1
                          </button>
                          <button
                            type="button"
                            onClick={() => onAdjustStock(product, 10)}
                            title="Restock +10"
                            className="inline-flex h-8 min-w-[42px] items-center justify-center rounded-md bg-emerald-600 px-2 font-mono text-xs font-semibold text-white hover:bg-emerald-700 cursor-pointer"
                          >
                            +10
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => onViewProduct(product)}
                            aria-label={`View ${product.name}`}
                            className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900 cursor-pointer"
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onEditProduct(product)}
                            aria-label={`Edit ${product.name}`}
                            className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900 cursor-pointer"
                          >
                            <Edit3 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
