import {Edit3, Plus, Save, Store, Truck} from 'lucide-react';
import React, {useEffect, useState} from 'react';
import type {StoreProfile, Wholesaler} from '../../shared/types.ts';
import {api} from '../services/api.ts';

interface SettingsAndWholesalersViewProps {
  storeProfile: StoreProfile | null;
  wholesalers: Wholesaler[];
  onProfileUpdated: (profile: StoreProfile) => void;
  onWholesalersUpdated: () => void;
}

export const SettingsAndWholesalersView: React.FC<
  SettingsAndWholesalersViewProps
> = ({
  storeProfile,
  wholesalers,
  onProfileUpdated,
  onWholesalersUpdated,
}) => {
  const [shopName, setShopName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [gstin, setGstin] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileFeedback, setProfileFeedback] = useState<string | null>(null);

  const [editingWhId, setEditingWhId] = useState<number | null>(null);
  const [whName, setWhName] = useState('');
  const [whPhone, setWhPhone] = useState('');
  const [whContact, setWhContact] = useState('');
  const [whNotes, setWhNotes] = useState('');
  const [whError, setWhError] = useState<string | null>(null);
  const [savingWh, setSavingWh] = useState(false);

  useEffect(() => {
    if (storeProfile) {
      setShopName(storeProfile.shopName);
      setOwnerName(storeProfile.ownerName);
      setPhone(storeProfile.phone);
      setAddress(storeProfile.address);
      setGstin(storeProfile.gstin || '');
    }
  }, [storeProfile]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    setProfileFeedback(null);
    try {
      const updated = await api.updateStoreProfile({
        shopName: shopName.trim(),
        ownerName: ownerName.trim(),
        phone: phone.trim(),
        address: address.trim(),
        gstin: gstin.trim() || null,
      });
      onProfileUpdated(updated);
      setProfileFeedback('Store profile saved. WhatsApp POs will use these details.');
    } catch (err) {
      setProfileFeedback(
        err instanceof Error ? err.message : 'Unable to save store profile.'
      );
    } finally {
      setSavingProfile(false);
    }
  };

  const resetWhForm = () => {
    setEditingWhId(null);
    setWhName('');
    setWhPhone('');
    setWhContact('');
    setWhNotes('');
    setWhError(null);
  };

  const startEditWh = (w: Wholesaler) => {
    setEditingWhId(w.id);
    setWhName(w.name);
    setWhPhone(w.phone);
    setWhContact(w.contactPerson || '');
    setWhNotes(w.notes || '');
    setWhError(null);
  };

  const handleSaveWh = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingWh(true);
    setWhError(null);
    try {
      if (editingWhId) {
        await api.updateWholesaler(editingWhId, {
          name: whName.trim(),
          phone: whPhone.trim(),
          contactPerson: whContact.trim(),
          notes: whNotes.trim(),
        });
      } else {
        await api.createWholesaler({
          name: whName.trim(),
          phone: whPhone.trim(),
          contactPerson: whContact.trim(),
          notes: whNotes.trim(),
        });
      }
      resetWhForm();
      onWholesalersUpdated();
    } catch (err) {
      setWhError(
        err instanceof Error ? err.message : 'Unable to save wholesaler.'
      );
    } finally {
      setSavingWh(false);
    }
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      {/* Editable Store Profile */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
          <Store className="h-5 w-5 text-emerald-600" />
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Kirana Store Profile
            </h2>
            <p className="text-xs text-slate-500">
              Automatically included in generated WhatsApp Purchase Orders
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveProfile} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700">
              Shop Name *
            </label>
            <input
              type="text"
              required
              value={shopName}
              onChange={(e) => setShopName(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Owner Name *
              </label>
              <input
                type="text"
                required
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Phone Number *
              </label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700">
              Delivery Address *
            </label>
            <textarea
              rows={2}
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700">
              GSTIN (optional)
            </label>
            <input
              type="text"
              value={gstin}
              onChange={(e) => setGstin(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm uppercase focus:border-emerald-600 focus:outline-none"
            />
          </div>

          {profileFeedback && (
            <p className="text-xs font-medium text-emerald-700">
              {profileFeedback}
            </p>
          )}

          <button
            type="submit"
            disabled={savingProfile}
            className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50 cursor-pointer"
          >
            <Save className="h-3.5 w-3.5" />
            <span>{savingProfile ? 'Saving...' : 'Save Store Profile'}</span>
          </button>
        </form>
      </section>

      {/* Wholesalers & Suppliers Management */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
          <Truck className="h-5 w-5 text-emerald-600" />
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Wholesalers & Suppliers
            </h2>
            <p className="text-xs text-slate-500">
              Manage supplier WhatsApp phone numbers and contacts
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveWh} className="space-y-3 rounded-xl border border-slate-200 bg-slate-50 p-4">
          <p className="text-xs font-bold text-slate-800">
            {editingWhId ? 'Edit Wholesaler' : 'Add New Wholesaler'}
          </p>
          {whError && (
            <p className="text-xs font-medium text-red-700">{whError}</p>
          )}
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            <input
              type="text"
              required
              value={whName}
              onChange={(e) => setWhName(e.target.value)}
              placeholder="Supplier business name"
              className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none"
            />
            <input
              type="text"
              required
              value={whPhone}
              onChange={(e) => setWhPhone(e.target.value)}
              placeholder="WhatsApp phone (+91...)"
              className="rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-xs focus:border-emerald-600 focus:outline-none"
            />
            <input
              type="text"
              value={whContact}
              onChange={(e) => setWhContact(e.target.value)}
              placeholder="Contact person"
              className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none"
            />
            <input
              type="text"
              value={whNotes}
              onChange={(e) => setWhNotes(e.target.value)}
              placeholder="Delivery notes"
              className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none"
            />
          </div>
          <div className="flex items-center gap-2">
            <button
              type="submit"
              disabled={savingWh}
              className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>
                {savingWh
                  ? 'Saving...'
                  : editingWhId
                    ? 'Update Supplier'
                    : 'Add Supplier'}
              </span>
            </button>
            {editingWhId && (
              <button
                type="button"
                onClick={resetWhForm}
                className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancel
              </button>
            )}
          </div>
        </form>

        <ul className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
          {wholesalers.map((w) => (
            <li
              key={w.id}
              className="flex items-start justify-between gap-3 py-3 text-xs"
            >
              <div>
                <p className="font-semibold text-slate-900">{w.name}</p>
                <p className="mt-0.5 font-mono text-slate-600">
                  {w.phone}
                  {w.contactPerson ? ` · ${w.contactPerson}` : ''}
                </p>
                {w.notes && <p className="mt-0.5 text-slate-500">{w.notes}</p>}
              </div>
              <button
                type="button"
                onClick={() => startEditWh(w)}
                aria-label={`Edit ${w.name}`}
                className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900 cursor-pointer shrink-0"
              >
                <Edit3 className="h-3.5 w-3.5" />
              </button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
};
