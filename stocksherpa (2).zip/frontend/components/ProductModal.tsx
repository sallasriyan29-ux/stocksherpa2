import {X} from 'lucide-react';
import React, {useEffect, useState} from 'react';
import type {
  Category,
  ProductDTO,
  ProductInput,
  Wholesaler,
} from '../../shared/types.ts';

interface ProductModalProps {
  isOpen: boolean;
  editingProduct: ProductDTO | null;
  prefillBarcode?: string;
  categories: Category[];
  wholesalers: Wholesaler[];
  onClose: () => void;
  onSubmit: (input: ProductInput, editingId?: number) => Promise<void>;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  isOpen,
  editingProduct,
  prefillBarcode,
  categories,
  wholesalers,
  onClose,
  onSubmit,
}) => {
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [barcode, setBarcode] = useState('');
  const [categoryId, setCategoryId] = useState<number>(1);
  const [wholesalerId, setWholesalerId] = useState<string>('');
  const [costPrice, setCostPrice] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [currentQty, setCurrentQty] = useState('0');
  const [minStockThreshold, setMinStockThreshold] = useState('5');
  const [reorderQty, setReorderQty] = useState('10');
  const [unitLabel, setUnitLabel] = useState('packets');
  const [reorderUnitLabel, setReorderUnitLabel] = useState('packets');
  const [reorderUnitCost, setReorderUnitCost] = useState('');
  const [avgDailyDemand, setAvgDailyDemand] = useState('1');
  const [leadTimeDays, setLeadTimeDays] = useState('2');
  const [safetyStock, setSafetyStock] = useState('2');
  const [expiryDate, setExpiryDate] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setError(null);
    if (editingProduct) {
      setName(editingProduct.name);
      setSku(editingProduct.sku);
      setBarcode(editingProduct.barcode || '');
      setCategoryId(editingProduct.categoryId);
      setWholesalerId(
        editingProduct.wholesalerId ? String(editingProduct.wholesalerId) : ''
      );
      setCostPrice(String(editingProduct.costPrice));
      setSellingPrice(String(editingProduct.sellingPrice));
      setCurrentQty(String(editingProduct.currentQty));
      setMinStockThreshold(String(editingProduct.minStockThreshold));
      setReorderQty(String(editingProduct.reorderQty));
      setUnitLabel(editingProduct.unitLabel);
      setReorderUnitLabel(editingProduct.reorderUnitLabel);
      setReorderUnitCost(
        editingProduct.reorderUnitCost !== null
          ? String(editingProduct.reorderUnitCost)
          : ''
      );
      setAvgDailyDemand(String(editingProduct.avgDailyDemand));
      setLeadTimeDays(String(editingProduct.leadTimeDays));
      setSafetyStock(String(editingProduct.safetyStock));
      setExpiryDate(editingProduct.expiryDate || '');
    } else {
      setName('');
      setSku('');
      setBarcode(prefillBarcode || '');
      setCategoryId(categories[0]?.id ?? 1);
      setWholesalerId(wholesalers[0]?.id ? String(wholesalers[0].id) : '');
      setCostPrice('');
      setSellingPrice('');
      setCurrentQty('0');
      setMinStockThreshold('5');
      setReorderQty('10');
      setUnitLabel('packets');
      setReorderUnitLabel('packets');
      setReorderUnitCost('');
      setAvgDailyDemand('1');
      setLeadTimeDays('2');
      setSafetyStock('2');
      setExpiryDate('');
    }
  }, [isOpen, editingProduct, prefillBarcode, categories, wholesalers]);

  if (!isOpen) return null;

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const parsedCost = Number(costPrice);
    const parsedSell = Number(sellingPrice);
    const parsedQty = Number(currentQty);
    const parsedMin = Number(minStockThreshold);
    const parsedReorder = Number(reorderQty);

    if (name.trim().length < 2) {
      setError('Product name must be at least 2 characters.');
      return;
    }
    if (!/^[A-Za-z0-9_-]{2,40}$/.test(sku.trim())) {
      setError('SKU must be 2–40 alphanumeric characters, hyphens, or underscores.');
      return;
    }
    if (!Number.isFinite(parsedCost) || parsedCost < 0) {
      setError('Cost price must be a non-negative number.');
      return;
    }
    if (!Number.isFinite(parsedSell) || parsedSell < 0) {
      setError('Selling price must be a non-negative number.');
      return;
    }
    if (!Number.isInteger(parsedQty) || parsedQty < 0) {
      setError('Current quantity must be a whole number >= 0.');
      return;
    }
    if (!Number.isInteger(parsedMin) || parsedMin < 0) {
      setError('Minimum threshold must be a whole number >= 0.');
      return;
    }
    if (!Number.isInteger(parsedReorder) || parsedReorder < 1) {
      setError('Reorder quantity must be at least 1.');
      return;
    }

    setSubmitting(true);
    try {
      await onSubmit(
        {
          name: name.trim(),
          sku: sku.trim().toUpperCase(),
          barcode: barcode.trim() || null,
          categoryId: Number(categoryId),
          wholesalerId: wholesalerId ? Number(wholesalerId) : null,
          costPrice: parsedCost,
          sellingPrice: parsedSell,
          currentQty: parsedQty,
          minStockThreshold: parsedMin,
          reorderQty: parsedReorder,
          unitLabel: unitLabel.trim() || 'units',
          reorderUnitLabel:
            reorderUnitLabel.trim() || unitLabel.trim() || 'units',
          reorderUnitCost:
            reorderUnitCost.trim() !== '' ? Number(reorderUnitCost) : null,
          avgDailyDemand: Number(avgDailyDemand) || 0,
          leadTimeDays: Number(leadTimeDays) || 0,
          safetyStock: Number(safetyStock) || 0,
          expiryDate: expiryDate.trim() || null,
        },
        editingProduct?.id
      );
      onClose();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Unable to save product.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="product-modal-title"
    >
      <div className="w-full max-w-2xl rounded-2xl border border-slate-200 bg-white shadow-xl my-8">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <h2
            id="product-modal-title"
            className="text-lg font-bold text-slate-900"
          >
            {editingProduct ? 'Edit Product' : 'Add New Product'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 cursor-pointer"
            aria-label="Close modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleFormSubmit} className="p-6 space-y-5">
          {error && (
            <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-700">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700">
                Product Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Aashirvaad Shudh Chakki Atta (5kg Pack)"
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                SKU *
              </label>
              <input
                type="text"
                required
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                placeholder="e.g. GRN-020"
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm uppercase focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Barcode (EAN / UPC)
              </label>
              <input
                type="text"
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                placeholder="e.g. 8901725121112"
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Category *
              </label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Wholesaler / Supplier
              </label>
              <select
                value={wholesalerId}
                onChange={(e) => setWholesalerId(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none"
              >
                <option value="">Unassigned Supplier</option>
                {wholesalers.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Cost Price (₹) *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={costPrice}
                onChange={(e) => setCostPrice(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Selling Price (₹) *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={sellingPrice}
                onChange={(e) => setSellingPrice(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Current Quantity *
              </label>
              <input
                type="number"
                step="1"
                min="0"
                required
                value={currentQty}
                onChange={(e) => setCurrentQty(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Stock Unit Label
              </label>
              <input
                type="text"
                value={unitLabel}
                onChange={(e) => setUnitLabel(e.target.value)}
                placeholder="packets, bottles, kg..."
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Min Stock Threshold *
              </label>
              <input
                type="number"
                step="1"
                min="0"
                required
                value={minStockThreshold}
                onChange={(e) => setMinStockThreshold(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Reorder Quantity *
              </label>
              <input
                type="number"
                step="1"
                min="1"
                required
                value={reorderQty}
                onChange={(e) => setReorderQty(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Reorder Unit Label
              </label>
              <input
                type="text"
                value={reorderUnitLabel}
                onChange={(e) => setReorderUnitLabel(e.target.value)}
                placeholder="packets, kg, boxes..."
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Expiry Date (optional)
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-emerald-600 focus:outline-none"
              />
            </div>
          </div>

          {/* Reorder Heuristic Parameters */}
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
            <p className="text-xs font-semibold text-slate-700">
              Reorder Point Heuristic Settings
            </p>
            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-600">
                  Avg Daily Sales
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  value={avgDailyDemand}
                  onChange={(e) => setAvgDailyDemand(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-600">
                  Lead Time (Days)
                </label>
                <input
                  type="number"
                  step="1"
                  min="0"
                  value={leadTimeDays}
                  onChange={(e) => setLeadTimeDays(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-600">
                  Safety Stock
                </label>
                <input
                  type="number"
                  step="1"
                  min="0"
                  value={safetyStock}
                  onChange={(e) => setSafetyStock(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-slate-200 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-lg bg-emerald-600 px-5 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50 cursor-pointer"
            >
              {submitting
                ? 'Saving...'
                : editingProduct
                  ? 'Save Changes'
                  : 'Create Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
