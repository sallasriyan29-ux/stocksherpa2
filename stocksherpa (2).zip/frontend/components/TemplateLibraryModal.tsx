import {Check, Plus, X} from 'lucide-react';
import React, {useEffect, useState} from 'react';
import {formatINR} from '../../shared/businessLogic.ts';
import type {CatalogTemplate} from '../../shared/types.ts';
import {api} from '../services/api.ts';

interface TemplateLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImported: () => void;
}

export const TemplateLibraryModal: React.FC<TemplateLibraryModalProps> = ({
  isOpen,
  onClose,
  onImported,
}) => {
  const [templates, setTemplates] = useState<
    Array<CatalogTemplate & {alreadyInStore: boolean}>
  >([]);
  const [loading, setLoading] = useState(false);
  const [importingSku, setImportingSku] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setLoading(true);
    setError(null);
    api
      .getTemplates()
      .then(setTemplates)
      .catch((err) =>
        setError(
          err instanceof Error ? err.message : 'Could not load templates.'
        )
      )
      .finally(() => setLoading(false));
  }, [isOpen]);

  if (!isOpen) return null;

  const handleImport = async (sku: string) => {
    setImportingSku(sku);
    setError(null);
    try {
      await api.importTemplate(sku);
      setTemplates((prev) =>
        prev.map((t) => (t.sku === sku ? {...t, alreadyInStore: true} : t))
      );
      onImported();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Failed to import template.'
      );
    } finally {
      setImportingSku(null);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Kirana Catalog Templates"
    >
      <div className="flex max-h-[85vh] w-full max-w-3xl flex-col rounded-2xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              15 Extra Kirana Catalog Templates
            </h2>
            <p className="text-xs text-slate-500">
              Expand beyond the 45-item ₹84,000 baseline to the full 60-product Indian kirana catalog
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 cursor-pointer"
            aria-label="Close templates"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {error && (
            <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-2.5 text-xs text-red-700">
              {error}
            </div>
          )}

          {loading ? (
            <p className="text-sm text-slate-500">Loading templates...</p>
          ) : (
            <div className="divide-y divide-slate-100 rounded-xl border border-slate-200">
              {templates.map((tpl) => (
                <div
                  key={tpl.sku}
                  className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div>
                    <p className="text-sm font-semibold text-slate-900">
                      {tpl.name}
                    </p>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {tpl.categoryName} · {tpl.sku} · Cost{' '}
                      {formatINR(tpl.costPrice)} · MRP{' '}
                      {formatINR(tpl.sellingPrice)} · Default {tpl.defaultQty}{' '}
                      {tpl.unitLabel}
                    </p>
                  </div>
                  {tpl.alreadyInStore ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 shrink-0">
                      <Check className="h-4 w-4" />
                      Added to Store
                    </span>
                  ) : (
                    <button
                      type="button"
                      disabled={importingSku === tpl.sku}
                      onClick={() => handleImport(tpl.sku)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50 cursor-pointer shrink-0"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>
                        {importingSku === tpl.sku ? 'Adding...' : 'Add to Store'}
                      </span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
