import Quagga from '@ericblade/quagga2';
import {Camera, Plus, Search, X} from 'lucide-react';
import React, {useEffect, useRef, useState} from 'react';
import type {ProductDTO} from '../../shared/types.ts';
import {StockStatusBadge} from './StatusBadges.tsx';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  products: ProductDTO[];
  onClose: () => void;
  onSelectProduct: (product: ProductDTO) => void;
  onAddProductWithBarcode: (barcode: string) => void;
  onAdjustStock: (product: ProductDTO, delta: number) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  products,
  onClose,
  onSelectProduct,
  onAddProductWithBarcode,
  onAdjustStock,
}) => {
  const scannerContainerRef = useRef<HTMLDivElement | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [manualCode, setManualCode] = useState('');
  const [scannedCode, setScannedCode] = useState<string | null>(null);
  const quaggaStartedRef = useRef(false);

  const stopScanner = () => {
    if (quaggaStartedRef.current) {
      try {
        Quagga.offDetected();
        Quagga.stop();
      } catch {
        // Ignore cleanup errors
      }
      quaggaStartedRef.current = false;
    }
    setCameraActive(false);
  };

  useEffect(() => {
    if (!isOpen) {
      stopScanner();
      setScannedCode(null);
      setManualCode('');
      setCameraError(null);
    }
    return () => {
      stopScanner();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const startCameraScanner = async () => {
    setCameraError(null);
    if (
      typeof navigator === 'undefined' ||
      !navigator.mediaDevices ||
      !navigator.mediaDevices.getUserMedia
    ) {
      setCameraError(
        'Camera API is not supported in this browser or context. Use manual barcode entry below.'
      );
      return;
    }

    try {
      // Request explicit permission first to surface clear error messages
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {facingMode: 'environment'},
      });
      stream.getTracks().forEach((t) => t.stop());
    } catch (err) {
      setCameraError(
        err instanceof Error && err.name === 'NotAllowedError'
          ? 'Camera permission denied. Allow camera access or enter the EAN barcode manually below.'
          : 'Unable to access device camera. Use manual barcode entry below.'
      );
      return;
    }

    if (!scannerContainerRef.current) return;
    setCameraActive(true);

    Quagga.init(
      {
        inputStream: {
          type: 'LiveStream',
          target: scannerContainerRef.current,
          constraints: {
            facingMode: 'environment',
            width: {ideal: 640},
            height: {ideal: 400},
          },
        },
        decoder: {
          readers: [
            'ean_reader',
            'ean_8_reader',
            'upc_reader',
            'code_128_reader',
          ],
        },
        locate: true,
      },
      (err) => {
        if (err) {
          setCameraActive(false);
          setCameraError(
            'Could not initialize QuaggaJS camera stream. Please enter the barcode manually.'
          );
          return;
        }
        quaggaStartedRef.current = true;
        Quagga.start();
      }
    );

    Quagga.onDetected((result) => {
      const code = result?.codeResult?.code;
      if (code) {
        setScannedCode(code);
        setManualCode(code);
        stopScanner();
      }
    });
  };

  const handleManualLookup = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = manualCode.trim();
    if (!cleaned) return;
    setScannedCode(cleaned);
  };

  const matchedProduct = scannedCode
    ? products.find(
        (p) =>
          p.barcode === scannedCode ||
          p.sku.toLowerCase() === scannedCode.toLowerCase()
      )
    : undefined;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Barcode Scanner"
    >
      <div className="w-full max-w-lg rounded-2xl border border-slate-200 bg-white shadow-xl overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              EAN Barcode Scanner
            </h2>
            <p className="text-xs text-slate-500">
              Scan a product barcode via camera or type it manually
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 cursor-pointer"
            aria-label="Close scanner"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Camera Stream Area */}
          <div className="rounded-xl border border-slate-200 bg-slate-950 overflow-hidden">
            <div
              ref={scannerContainerRef}
              className={`relative w-full ${cameraActive ? 'h-56' : 'h-0'}`}
            />
            {!cameraActive && (
              <div className="flex flex-col items-center justify-center p-6 text-center text-white">
                <Camera className="h-8 w-8 text-emerald-400" />
                <p className="mt-2 text-xs text-slate-300">
                  Uses HTML5 Camera API & QuaggaJS to scan EAN-13 / EAN-8 / UPC codes
                </p>
                <button
                  type="button"
                  onClick={startCameraScanner}
                  className="mt-3 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 cursor-pointer"
                >
                  Enable Camera Scanner
                </button>
              </div>
            )}
          </div>

          {cameraActive && (
            <button
              type="button"
              onClick={stopScanner}
              className="w-full rounded-lg border border-slate-200 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Stop Camera
            </button>
          )}

          {cameraError && (
            <div className="rounded-lg border border-amber-200 bg-amber-50 px-3.5 py-2.5 text-xs text-amber-900">
              {cameraError}
            </div>
          )}

          {/* Manual Barcode Fallback */}
          <form onSubmit={handleManualLookup} className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700">
              Manual Barcode or SKU Lookup
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="e.g. 8901725121112 (Atta) or 8901058000290"
                className="flex-1 rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-emerald-600 focus:outline-none"
              />
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
              >
                <Search className="h-3.5 w-3.5" />
                <span>Lookup</span>
              </button>
            </div>
          </form>

          {/* Lookup Result */}
          {scannedCode && (
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
              {matchedProduct ? (
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-sm font-bold text-slate-900">
                        {matchedProduct.name}
                      </p>
                      <p className="text-xs text-slate-500 font-mono">
                        {matchedProduct.sku} · EAN {matchedProduct.barcode}
                      </p>
                    </div>
                    <StockStatusBadge status={matchedProduct.stockStatus} />
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <span className="font-mono text-base font-bold text-slate-900 tabular-nums">
                      {matchedProduct.currentQty} {matchedProduct.unitLabel}
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        disabled={matchedProduct.currentQty <= 0}
                        onClick={() => onAdjustStock(matchedProduct, -1)}
                        className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 font-mono text-xs font-bold text-slate-800 hover:bg-red-50 disabled:opacity-40 cursor-pointer"
                      >
                        -1
                      </button>
                      <button
                        type="button"
                        onClick={() => onAdjustStock(matchedProduct, 1)}
                        className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-1.5 font-mono text-xs font-bold text-emerald-800 cursor-pointer"
                      >
                        +1
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onSelectProduct(matchedProduct);
                        }}
                        className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white cursor-pointer"
                      >
                        Details
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-sm font-semibold text-slate-900">
                      No product matches barcode &ldquo;{scannedCode}&rdquo;
                    </p>
                    <p className="text-xs text-slate-500">
                      Add this item directly to your catalog with the barcode pre-filled.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onAddProductWithBarcode(scannedCode);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 cursor-pointer shrink-0"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>Add Product</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
