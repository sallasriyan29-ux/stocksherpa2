import {AlertCircle, Clock} from 'lucide-react';
import React, {useMemo, useState} from 'react';
import {formatINR} from '../../shared/businessLogic.ts';
import type {ProductDTO} from '../../shared/types.ts';
import {ExpiryStatusBadge} from './StatusBadges.tsx';

type ExpiryFilter = 'ALL_ALERT' | 'EXPIRED' | '7' | '15' | '30' | 'ALL_DATED';

interface ExpiryViewProps {
  products: ProductDTO[];
  onViewProduct: (product: ProductDTO) => void;
}

export const ExpiryView: React.FC<ExpiryViewProps> = ({
  products,
  onViewProduct,
}) => {
  const [filter, setFilter] = useState<ExpiryFilter>('ALL_ALERT');

  const datedProducts = useMemo(
    () =>
      products
        .filter((p) => p.expiryDate !== null && p.daysUntilExpiry !== null)
        .sort(
          (a, b) =>
            (a.daysUntilExpiry ?? 9999) - (b.daysUntilExpiry ?? 9999)
        ),
    [products]
  );

  const filtered = useMemo(() => {
    return datedProducts.filter((p) => {
      const days = p.daysUntilExpiry ?? 9999;
      switch (filter) {
        case 'EXPIRED':
          return days < 0;
        case '7':
          return days >= 0 && days <= 7;
        case '15':
          return days >= 0 && days <= 15;
        case '30':
          return days >= 0 && days <= 30;
        case 'ALL_ALERT':
          return days <= 30;
        case 'ALL_DATED':
        default:
          return true;
      }
    });
  }, [datedProducts, filter]);

  const counts = useMemo(() => {
    let expired = 0;
    let d7 = 0;
    let d15 = 0;
    let d30 = 0;
    for (const p of datedProducts) {
      const d = p.daysUntilExpiry ?? 9999;
      if (d < 0) expired += 1;
      else if (d <= 7) d7 += 1;
      else if (d <= 15) d15 += 1;
      else if (d <= 30) d30 += 1;
    }
    return {expired, d7, d15, d30};
  }, [datedProducts]);

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-bold text-slate-900">
          Perishable Expiry Tracker
        </h2>
        <p className="text-xs text-slate-500">
          Monitors shelf dates across 7-day, 15-day, 30-day, and expired windows. Expired stock is flagged and never silently removed.
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-xl border border-red-200 bg-red-50/70 p-4">
          <p className="text-xs font-semibold text-red-800">Already Expired</p>
          <p className="mt-1 font-mono text-2xl font-bold text-red-700 tabular-nums">
            {counts.expired}
          </p>
        </div>
        <div className="rounded-xl border border-red-200 bg-white p-4">
          <p className="text-xs font-semibold text-slate-600">Within 7 Days</p>
          <p className="mt-1 font-mono text-2xl font-bold text-red-600 tabular-nums">
            {counts.d7}
          </p>
        </div>
        <div className="rounded-xl border border-amber-200 bg-white p-4">
          <p className="text-xs font-semibold text-slate-600">8–15 Days</p>
          <p className="mt-1 font-mono text-2xl font-bold text-amber-700 tabular-nums">
            {counts.d15}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs font-semibold text-slate-600">16–30 Days</p>
          <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {counts.d30}
          </p>
        </div>
      </div>

      {/* Period Filter Tabs */}
      <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1 w-fit">
        {[
          {id: 'ALL_ALERT', label: 'All Alerts (<=30d & Expired)'},
          {id: 'EXPIRED', label: 'Expired'},
          {id: '7', label: 'Next 7 Days'},
          {id: '15', label: 'Next 15 Days'},
          {id: '30', label: 'Next 30 Days'},
          {id: 'ALL_DATED', label: 'All Dated Items'},
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilter(tab.id as ExpiryFilter)}
            className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
              filter === tab.id
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
          <Clock className="mx-auto h-8 w-8 text-slate-300" />
          <p className="mt-2 text-sm font-semibold text-slate-900">
            No products in this expiry window
          </p>
        </div>
      ) : (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="divide-y divide-slate-100">
            {filtered.map((item) => (
              <div
                key={item.id}
                className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    {item.expiryStatus === 'EXPIRED' && (
                      <AlertCircle className="h-4 w-4 shrink-0 text-red-600" />
                    )}
                    <button
                      type="button"
                      onClick={() => onViewProduct(item)}
                      className="text-left text-sm font-semibold text-slate-900 hover:text-emerald-700 cursor-pointer"
                    >
                      {item.name}
                    </button>
                  </div>
                  <p className="mt-0.5 text-xs text-slate-500 font-mono tabular-nums">
                    {item.categoryName} · {item.sku} · Expiry Date:{' '}
                    <strong className="text-slate-700">{item.expiryDate}</strong>
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-4 shrink-0">
                  <div className="text-right font-mono tabular-nums">
                    <p className="text-sm font-bold text-slate-900">
                      {item.currentQty} {item.unitLabel}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Cost at risk: {formatINR(item.inventoryValue)}
                    </p>
                  </div>
                  <ExpiryStatusBadge
                    status={item.expiryStatus}
                    daysUntilExpiry={item.daysUntilExpiry}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
