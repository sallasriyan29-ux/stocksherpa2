import {Edit3, Trash2, X} from 'lucide-react';
import React, {useEffect, useState} from 'react';
import {formatINR} from '../../shared/businessLogic.ts';
import type {ProductDTO, StockLog} from '../../shared/types.ts';
import {api} from '../services/api.ts';
import {ExpiryStatusBadge, StockStatusBadge} from './StatusBadges.tsx';

interface ProductDetailDrawerProps {
  product: ProductDTO | null;
  onClose: () => void;
  onEdit: (product: ProductDTO) => void;
  onDelete: (id: number) => Promise<void>;
  onAdjustStock: (product: ProductDTO, delta: number) => void;
}

export const ProductDetailDrawer: React.FC<ProductDetailDrawerProps> = ({
  product,
  onClose,
  onEdit,
  onDelete,
  onAdjustStock,
}) => {
  const [logs, setLogs] = useState<StockLog[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (!product) return;
    setConfirmDelete(false);
    setLoadingLogs(true);
    api
      .getStockLogs(product.id)
      .then((res) => setLogs(res))
      .catch(() => setLogs([]))
      .finally(() => setLoadingLogs(false));
  }, [product]);

  if (!product) return null;

  const profitPerUnit = product.sellingPrice - product.costPrice;
  const marginPct =
    product.sellingPrice > 0
      ? Math.round((profitPerUnit / product.sellingPrice) * 1000) / 10
      : 0;

  const handleConfirmDelete = async () => {
    setDeleting(true);
    try {
      await onDelete(product.id);
      onClose();
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-900/40"
      role="dialog"
      aria-modal="true"
      aria-label={`Details for ${product.name}`}
    >
      <div className="flex h-full w-full max-w-lg flex-col border-l border-slate-200 bg-white shadow-2xl">
        <div className="flex items-start justify-between border-b border-slate-200 px-6 py-4">
          <div className="min-w-0 pr-3">
            <h2 className="text-lg font-bold text-slate-900">{product.name}</h2>
            <p className="mt-0.5 text-xs text-slate-500">
              {product.categoryName} · {product.sku}
              {product.barcode ? ` · EAN ${product.barcode}` : ''}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 cursor-pointer"
            aria-label="Close drawer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Status & Quick Adjust */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4">
            <div>
              <div className="flex items-center gap-2">
                <StockStatusBadge status={product.stockStatus} />
                <ExpiryStatusBadge
                  status={product.expiryStatus}
                  daysUntilExpiry={product.daysUntilExpiry}
                />
              </div>
              <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
                {product.currentQty}{' '}
                <span className="text-sm font-normal text-slate-500">
                  {product.unitLabel}
                </span>
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={product.currentQty <= 0}
                onClick={() => onAdjustStock(product, -1)}
                className="min-h-[40px] rounded-lg border border-slate-200 bg-white px-3 font-mono text-xs font-bold text-slate-800 hover:bg-red-50 hover:text-red-700 disabled:opacity-40 cursor-pointer"
              >
                -1
              </button>
              <button
                type="button"
                onClick={() => onAdjustStock(product, 1)}
                className="min-h-[40px] rounded-lg border border-emerald-200 bg-emerald-50 px-3 font-mono text-xs font-bold text-emerald-800 hover:bg-emerald-100 cursor-pointer"
              >
                +1
              </button>
              <button
                type="button"
                onClick={() => onAdjustStock(product, 10)}
                className="min-h-[40px] rounded-lg bg-emerald-600 px-3 font-mono text-xs font-bold text-white hover:bg-emerald-700 cursor-pointer"
              >
                +10
              </button>
            </div>
          </div>

          {/* Pricing & Reorder Specs */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="rounded-xl border border-slate-200 p-3.5">
              <p className="text-xs text-slate-500">Cost Price</p>
              <p className="mt-1 font-mono font-bold text-slate-900 tabular-nums">
                {formatINR(product.costPrice)}
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 p-3.5">
              <p className="text-xs text-slate-500">Selling Price</p>
              <p className="mt-1 font-mono font-bold text-slate-900 tabular-nums">
                {formatINR(product.sellingPrice)} ({marginPct}% margin)
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 p-3.5">
              <p className="text-xs text-slate-500">Min Threshold / ROP</p>
              <p className="mt-1 font-mono font-bold text-slate-900 tabular-nums">
                {product.minStockThreshold} / {product.reorderPoint}{' '}
                {product.unitLabel}
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 p-3.5">
              <p className="text-xs text-slate-500">Configured Reorder</p>
              <p className="mt-1 font-mono font-bold text-slate-900 tabular-nums">
                {product.reorderQty} {product.reorderUnitLabel}
              </p>
            </div>
          </div>

          <div className="space-y-1 text-xs text-slate-600 border-t border-slate-100 pt-4">
            <p>
              <strong>Supplier:</strong>{' '}
              {product.wholesalerName || 'Unassigned Supplier'}{' '}
              {product.wholesalerPhone ? `(${product.wholesalerPhone})` : ''}
            </p>
            <p>
              <strong>Inventory Cost Value:</strong>{' '}
              <span className="font-mono">{formatINR(product.inventoryValue)}</span>
            </p>
            <p>
              <strong>Expiry Date:</strong>{' '}
              <span className="font-mono">{product.expiryDate || 'Not applicable'}</span>
            </p>
            <p>
              <strong>Origin:</strong>{' '}
              {product.isDemo ? 'Initial Demonstration Catalog' : 'Store-Managed Record'}
            </p>
          </div>

          {/* Stock Ledger History */}
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Product Stock Ledger
            </h3>
            {loadingLogs ? (
              <p className="mt-2 text-xs text-slate-500">Loading ledger...</p>
            ) : logs.length === 0 ? (
              <p className="mt-2 text-xs text-slate-500">
                No ledger entries recorded.
              </p>
            ) : (
              <ul className="mt-2 divide-y divide-slate-100 rounded-xl border border-slate-200">
                {logs.map((log) => (
                  <li
                    key={log.id}
                    className="flex items-center justify-between px-3.5 py-2.5 text-xs"
                  >
                    <div>
                      <span className="font-semibold text-slate-800">
                        {log.transactionType}
                      </span>
                      <p className="text-slate-500">
                        {log.notes || 'Stock adjustment'}
                      </p>
                    </div>
                    <div className="text-right font-mono tabular-nums">
                      <span
                        className={
                          log.qtyChanged < 0
                            ? 'font-bold text-red-600'
                            : 'font-bold text-emerald-700'
                        }
                      >
                        {log.qtyChanged > 0
                          ? `+${log.qtyChanged}`
                          : log.qtyChanged}
                      </span>
                      <p className="text-[11px] text-slate-500">
                        {log.prevQty} → {log.newQty}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <div className="border-t border-slate-200 px-6 py-4">
          {confirmDelete ? (
            <div className="flex items-center justify-between gap-3 rounded-lg border border-red-200 bg-red-50 p-3">
              <span className="text-xs font-semibold text-red-800">
                Delete {product.name} permanently?
              </span>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  className="rounded-md bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 border border-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={deleting}
                  onClick={handleConfirmDelete}
                  className="rounded-md bg-red-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-red-700 cursor-pointer"
                >
                  {deleting ? 'Deleting...' : 'Confirm Delete'}
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={() => setConfirmDelete(true)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 px-3 py-2 text-xs font-semibold text-red-700 hover:bg-red-50 cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Delete Product</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onEdit(product);
                }}
                className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 cursor-pointer"
              >
                <Edit3 className="h-3.5 w-3.5" />
                <span>Edit Product</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
