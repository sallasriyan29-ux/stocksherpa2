import {
  Check,
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  MessageSquare,
  Trash2,
} from 'lucide-react';
import React, {useEffect, useState} from 'react';
import {
  buildWhatsAppUrl,
  formatINR,
  formatWhatsAppPurchaseOrder,
  roundCurrency,
} from '../../shared/businessLogic.ts';
import type {
  PurchaseOrderRecord,
  StoreProfile,
  WholesalerOrderGroup,
} from '../../shared/types.ts';
import {api} from '../services/api.ts';

interface ReorderViewProps {
  groups: WholesalerOrderGroup[];
  storeProfile: StoreProfile | null;
  onRefresh: () => void;
}

interface EditableGroupState {
  wholesalerId: number | null;
  wholesalerName: string;
  wholesalerPhone: string;
  items: Array<{
    productId: number;
    productName: string;
    sku: string;
    currentQty: number;
    unitLabel: string;
    minStockThreshold: number;
    reorderPoint: number;
    qtyOrdered: number;
    reorderUnitLabel: string;
    unitCost: number;
    estimatedCost: number;
  }>;
}

export const ReorderView: React.FC<ReorderViewProps> = ({
  groups,
  storeProfile,
  onRefresh,
}) => {
  const [editableGroups, setEditableGroups] = useState<EditableGroupState[]>(
    []
  );
  const [activePO, setActivePO] = useState<{
    order: PurchaseOrderRecord;
    whatsappUrl: string;
    groupKey: string;
  } | null>(null);
  const [recentOrders, setRecentOrders] = useState<PurchaseOrderRecord[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [generatingKey, setGeneratingKey] = useState<string | null>(null);

  useEffect(() => {
    setEditableGroups(
      groups.map((g) => ({
        wholesalerId: g.wholesalerId,
        wholesalerName: g.wholesalerName,
        wholesalerPhone: g.wholesalerPhone,
        items: g.items.map((i) => ({
          productId: i.productId,
          productName: i.productName,
          sku: i.sku,
          currentQty: i.currentQty,
          unitLabel: i.unitLabel,
          minStockThreshold: i.minStockThreshold,
          reorderPoint: i.reorderPoint,
          qtyOrdered: i.suggestedReorderQty,
          reorderUnitLabel: i.reorderUnitLabel,
          unitCost: i.unitCost,
          estimatedCost: i.estimatedCost,
        })),
      }))
    );
  }, [groups]);

  useEffect(() => {
    api
      .getPurchaseOrders()
      .then(setRecentOrders)
      .catch(() => {});
  }, []);

  const updateItemQty = (
    groupIdx: number,
    productId: number,
    newQty: number
  ) => {
    const safeQty = Math.max(1, Math.floor(newQty || 1));
    setEditableGroups((prev) =>
      prev.map((g, idx) =>
        idx !== groupIdx
          ? g
          : {
              ...g,
              items: g.items.map((item) =>
                item.productId === productId
                  ? {
                      ...item,
                      qtyOrdered: safeQty,
                      estimatedCost: roundCurrency(safeQty * item.unitCost),
                    }
                  : item
              ),
            }
      )
    );
  };

  const removeItem = (groupIdx: number, productId: number) => {
    setEditableGroups((prev) =>
      prev
        .map((g, idx) =>
          idx !== groupIdx
            ? g
            : {
                ...g,
                items: g.items.filter((item) => item.productId !== productId),
              }
        )
        .filter((g) => g.items.length > 0)
    );
  };

  const buildPreviewText = (group: EditableGroupState) => {
    const total = roundCurrency(
      group.items.reduce((s, i) => s + i.estimatedCost, 0)
    );
    const store = storeProfile ?? {
      shopName: 'Sri Lakshmi Kirana & General Store',
      ownerName: 'Ramesh Gupta',
      phone: '+91 98201 45678',
      address: 'Navi Mumbai',
      gstin: null,
    };
    return formatWhatsAppPurchaseOrder({
      store,
      wholesalerName: group.wholesalerName,
      items: group.items.map((i) => ({
        productName: i.productName,
        sku: i.sku,
        qty: i.qtyOrdered,
        unitLabel: i.reorderUnitLabel,
        estimatedCost: i.estimatedCost,
      })),
      totalEstimatedCost: total,
    });
  };

  const handleGenerateWhatsAppOrder = async (
    group: EditableGroupState,
    groupKey: string
  ) => {
    setError(null);
    setGeneratingKey(groupKey);
    try {
      const res = await api.generatePurchaseOrder({
        wholesalerId: group.wholesalerId,
        wholesalerName: group.wholesalerName,
        wholesalerPhone: group.wholesalerPhone,
        status: 'DRAFT',
        items: group.items.map((i) => ({
          productId: i.productId,
          qtyOrdered: i.qtyOrdered,
        })),
      });
      setActivePO({...res, groupKey});
      const updatedHistory = await api.getPurchaseOrders();
      setRecentOrders(updatedHistory);
    } catch (err) {
      // Fallback preview if offline
      const text = buildPreviewText(group);
      const total = roundCurrency(
        group.items.reduce((s, i) => s + i.estimatedCost, 0)
      );
      setActivePO({
        groupKey,
        whatsappUrl: buildWhatsAppUrl(group.wholesalerPhone, text),
        order: {
          id: 0,
          wholesalerId: group.wholesalerId,
          wholesalerName: group.wholesalerName,
          wholesalerPhone: group.wholesalerPhone,
          messageText: text,
          totalEstimatedCost: total,
          status: 'DRAFT',
          createdAt: new Date().toISOString(),
          items: group.items.map((i) => ({
            productId: i.productId,
            productName: i.productName,
            sku: i.sku,
            qtyOrdered: i.qtyOrdered,
            unitLabel: i.reorderUnitLabel,
            estimatedCost: i.estimatedCost,
          })),
        },
      });
      if (navigator.onLine) {
        setError(
          err instanceof Error ? err.message : 'Unable to save purchase order.'
        );
      }
    } finally {
      setGeneratingKey(null);
    }
  };

  const handleCopyMessage = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      window.setTimeout(() => setCopiedId(null), 2000);
    } catch {
      setError('Clipboard access unavailable. Copy directly from the preview box.');
    }
  };

  const handleExportTxt = (group: EditableGroupState) => {
    const text = buildPreviewText(group);
    const blob = new Blob([text], {type: 'text/plain;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PO-${group.wholesalerName.replace(/[^a-z0-9]/gi, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleConfirmDispatched = async (orderId: number) => {
    if (orderId <= 0) return;
    try {
      const updated = await api.markOrderDispatched(orderId);
      setActivePO((prev) =>
        prev && prev.order.id === orderId ? {...prev, order: updated} : prev
      );
      setRecentOrders((prev) =>
        prev.map((o) => (o.id === orderId ? updated : o))
      );
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Failed to confirm dispatch.'
      );
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900">
            Smart Reorder Assistant
          </h2>
          <p className="text-xs text-slate-500">
            Automatically consolidated by wholesaler for items below threshold or reorder point
          </p>
        </div>
        <button
          type="button"
          onClick={onRefresh}
          className="self-start rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
        >
          Recalculate Suggestions
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-700">
          {error}
        </div>
      )}

      {editableGroups.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
          <p className="text-base font-semibold text-slate-900">
            No items currently require reordering
          </p>
          <p className="mt-1 text-sm text-slate-500">
            All store products are stocked safely above their reorder points.
          </p>
        </div>
      ) : (
        <div className="space-y-5">
          {editableGroups.map((group, groupIdx) => {
            const groupKey = `${group.wholesalerId ?? 'none'}::${group.wholesalerName}`;
            const groupTotal = roundCurrency(
              group.items.reduce((s, i) => s + i.estimatedCost, 0)
            );
            const previewOpen = activePO?.groupKey === groupKey;

            return (
              <section
                key={groupKey}
                className="rounded-xl border border-slate-200 bg-white overflow-hidden"
              >
                <div className="flex flex-col gap-3 border-b border-slate-200 bg-slate-50/70 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h3 className="text-base font-bold text-slate-900">
                      {group.wholesalerName}
                    </h3>
                    <p className="text-xs text-slate-500 font-mono">
                      {group.wholesalerPhone || 'No supplier phone configured'} ·{' '}
                      {group.items.length} line item(s) · Est.{' '}
                      <strong className="text-slate-900">
                        {formatINR(groupTotal)}
                      </strong>
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleExportTxt(group)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>Export PO</span>
                    </button>
                    <button
                      type="button"
                      disabled={generatingKey === groupKey}
                      onClick={() =>
                        handleGenerateWhatsAppOrder(group, groupKey)
                      }
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50 cursor-pointer"
                    >
                      <MessageSquare className="h-3.5 w-3.5" />
                      <span>
                        {generatingKey === groupKey
                          ? 'Generating...'
                          : 'Generate WhatsApp Order'}
                      </span>
                    </button>
                  </div>
                </div>

                <div className="divide-y divide-slate-100">
                  {group.items.map((item) => (
                    <div
                      key={item.productId}
                      className="flex flex-col gap-3 px-5 py-3.5 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900">
                          {item.productName}
                        </p>
                        <p className="mt-0.5 text-xs text-slate-500 font-mono tabular-nums">
                          {item.sku} · On hand: {item.currentQty} {item.unitLabel} (Min{' '}
                          {item.minStockThreshold})
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 shrink-0">
                        <div className="flex items-center gap-2">
                          <label
                            htmlFor={`qty-${item.productId}`}
                            className="text-xs text-slate-500"
                          >
                            Order:
                          </label>
                          <input
                            id={`qty-${item.productId}`}
                            type="number"
                            min="1"
                            value={item.qtyOrdered}
                            onChange={(e) =>
                              updateItemQty(
                                groupIdx,
                                item.productId,
                                Number(e.target.value)
                              )
                            }
                            className="w-20 rounded-lg border border-slate-200 px-2.5 py-1.5 text-right font-mono text-sm font-semibold text-slate-900 focus:border-emerald-600 focus:outline-none"
                          />
                          <span className="text-xs font-medium text-slate-600 min-w-[44px]">
                            {item.reorderUnitLabel}
                          </span>
                        </div>

                        <span className="font-mono text-sm font-semibold text-slate-900 tabular-nums min-w-[76px] text-right">
                          {formatINR(item.estimatedCost)}
                        </span>

                        <button
                          type="button"
                          onClick={() => removeItem(groupIdx, item.productId)}
                          aria-label={`Remove ${item.productName} from order`}
                          className="rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-600 cursor-pointer"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Generated WhatsApp Purchase Order Message Preview */}
                {previewOpen && activePO && (
                  <div className="border-t border-emerald-200 bg-emerald-50/40 p-5 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">
                          WhatsApp Purchase Order Ready
                        </h4>
                        <p className="text-xs text-slate-600">
                          Opening WhatsApp prepares the draft message. Confirm dispatch manually after sending.
                        </p>
                      </div>
                      <span
                        className={`rounded-md px-2.5 py-1 text-xs font-semibold ${
                          activePO.order.status === 'DISPATCHED'
                            ? 'bg-emerald-600 text-white'
                            : 'border border-amber-300 bg-amber-50 text-amber-800'
                        }`}
                      >
                        {activePO.order.status === 'DISPATCHED'
                          ? 'DISPATCH CONFIRMED'
                          : 'AWAITING DISPATCH CONFIRMATION'}
                      </span>
                    </div>

                    <pre className="whitespace-pre-wrap rounded-xl border border-slate-200 bg-white p-4 font-mono text-xs text-slate-800 leading-relaxed">
                      {activePO.order.messageText}
                    </pre>

                    <div className="flex flex-wrap items-center gap-2">
                      <a
                        href={activePO.whatsappUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                        <span>Open in WhatsApp</span>
                      </a>

                      <button
                        type="button"
                        onClick={() =>
                          handleCopyMessage(
                            activePO.order.messageText,
                            groupKey
                          )
                        }
                        className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                      >
                        {copiedId === groupKey ? (
                          <>
                            <Check className="h-3.5 w-3.5 text-emerald-600" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="h-3.5 w-3.5" />
                            <span>Copy Message</span>
                          </>
                        )}
                      </button>

                      {activePO.order.id > 0 &&
                        activePO.order.status !== 'DISPATCHED' && (
                          <button
                            type="button"
                            onClick={() =>
                              handleConfirmDispatched(activePO.order.id)
                            }
                            className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-300 bg-white px-3.5 py-2 text-xs font-semibold text-emerald-700 hover:bg-emerald-50 cursor-pointer"
                          >
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            <span>Confirm Sent / Dispatched</span>
                          </button>
                        )}
                    </div>
                  </div>
                )}
              </section>
            );
          })}
        </div>
      )}

      {/* Saved Purchase Orders Log */}
      {recentOrders.length > 0 && (
        <section className="rounded-xl border border-slate-200 bg-white">
          <div className="border-b border-slate-200 px-5 py-3.5">
            <h3 className="text-sm font-bold text-slate-900">
              Recent Generated Purchase Orders
            </h3>
          </div>
          <ul className="divide-y divide-slate-100">
            {recentOrders.slice(0, 6).map((po) => (
              <li
                key={po.id}
                className="flex flex-wrap items-center justify-between gap-3 px-5 py-3 text-xs"
              >
                <div>
                  <p className="font-semibold text-slate-900">
                    PO #{po.id} · {po.wholesalerName}
                  </p>
                  <p className="text-slate-500">
                    {po.items.length} item(s) · Est.{' '}
                    <span className="font-mono">
                      {formatINR(po.totalEstimatedCost)}
                    </span>{' '}
                    · {new Date(po.createdAt).toLocaleString('en-IN')}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`rounded-md px-2 py-0.5 font-semibold ${
                      po.status === 'DISPATCHED'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-amber-50 text-amber-800 border border-amber-200'
                    }`}
                  >
                    {po.status}
                  </span>
                  {po.status !== 'DISPATCHED' && (
                    <button
                      type="button"
                      onClick={() => handleConfirmDispatched(po.id)}
                      className="rounded-md border border-slate-200 px-2.5 py-1 font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                    >
                      Mark Dispatched
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
};
