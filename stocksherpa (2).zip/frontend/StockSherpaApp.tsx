import {
  AlertTriangle,
  Clock,
  FileText,
  LayoutDashboard,
  Menu,
  Package,
  Plus,
  RefreshCw,
  ScanBarcode,
  Settings,
  ShoppingCart,
  WifiOff,
  X,
} from 'lucide-react';
import React, {useCallback, useEffect, useRef, useState} from 'react';
import {
  buildReorderGroups,
  calculateFinancialMetrics,
  enrichProduct,
} from '../shared/businessLogic.ts';
import type {
  Category,
  DashboardSummary,
  OfflineSyncOperation,
  ProductDTO,
  ProductInput,
  StockLog,
  StoreProfile,
  Wholesaler,
  WholesalerOrderGroup,
} from '../shared/types.ts';
import {BarcodeScannerModal} from './components/BarcodeScannerModal.tsx';
import {DashboardView} from './components/DashboardView.tsx';
import {ExpiryView} from './components/ExpiryView.tsx';
import {InventoryView} from './components/InventoryView.tsx';
import {PWAInstallButton} from './components/PWAInstallButton.tsx';
import {ProductDetailDrawer} from './components/ProductDetailDrawer.tsx';
import {ProductModal} from './components/ProductModal.tsx';
import {ReorderView} from './components/ReorderView.tsx';
import {SettingsAndWholesalersView} from './components/SettingsAndWholesalersView.tsx';
import {StockLedgerView} from './components/StockLedgerView.tsx';
import {SyncQueueDrawer} from './components/SyncQueueDrawer.tsx';
import {TemplateLibraryModal} from './components/TemplateLibraryModal.tsx';
import {useOnlineStatus} from './hooks/useOnlineStatus.ts';
import {api} from './services/api.ts';
import {
  enqueuePendingOperation,
  generateOperationId,
  getLastSyncTimestamp,
  getPendingOperations,
  getSyncConflicts,
  loadCategoriesCache,
  loadProductsCache,
  loadStoreProfileCache,
  loadWholesalersCache,
  partitionSyncResults,
  saveProductsCache,
  setLastSyncTimestamp,
  setPendingOperations,
  setSyncConflicts,
  type SyncConflictItem,
} from './services/offlineSync.ts';

type ActiveTab =
  | 'dashboard'
  | 'inventory'
  | 'reorder'
  | 'expiry'
  | 'ledger'
  | 'settings';

export const StockSherpaApp: React.FC = () => {
  const isOnline = useOnlineStatus();
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [inventoryStatusFilter, setInventoryStatusFilter] = useState<
    'ALL' | 'LOW_STOCK' | 'OUT_OF_STOCK' | 'IN_STOCK'
  >('ALL');

  const [products, setProducts] = useState<ProductDTO[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [wholesalers, setWholesalers] = useState<Wholesaler[]>([]);
  const [storeProfile, setStoreProfile] = useState<StoreProfile | null>(null);
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [lowStockItems, setLowStockItems] = useState<ProductDTO[]>([]);
  const [expiringItems, setExpiringItems] = useState<ProductDTO[]>([]);
  const [reorderGroups, setReorderGroups] = useState<WholesalerOrderGroup[]>(
    []
  );
  const [stockLogs, setStockLogs] = useState<StockLog[]>([]);
  const [loading, setLoading] = useState(true);

  const [pendingOps, setPendingOpsState] = useState<OfflineSyncOperation[]>(() =>
    getPendingOperations()
  );
  const [conflicts, setConflictsState] = useState<SyncConflictItem[]>(() =>
    getSyncConflicts()
  );
  const [lastSyncAt, setLastSyncAtState] = useState<string | null>(() =>
    getLastSyncTimestamp()
  );
  const [isSyncing, setIsSyncing] = useState(false);

  // Modals & Drawers
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductDTO | null>(null);
  const [prefillBarcode, setPrefillBarcode] = useState<string | undefined>(
    undefined
  );
  const [selectedProduct, setSelectedProduct] = useState<ProductDTO | null>(
    null
  );
  const [scannerOpen, setScannerOpen] = useState(false);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [syncDrawerOpen, setSyncDrawerOpen] = useState(false);
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);

  const [toast, setToast] = useState<{
    type: 'success' | 'error' | 'warning';
    message: string;
  } | null>(null);

  const showToast = useCallback(
    (type: 'success' | 'error' | 'warning', message: string) => {
      setToast({type, message});
    },
    []
  );

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(null), 4000);
    return () => window.clearTimeout(t);
  }, [toast]);

  const recomputeLocalDerivedState = useCallback(
    (nextProducts: ProductDTO[]) => {
      const low = nextProducts.filter(
        (p) => p.stockStatus === 'LOW_STOCK' || p.stockStatus === 'OUT_OF_STOCK'
      );
      const expiring = nextProducts.filter(
        (p) => p.daysUntilExpiry !== null && p.daysUntilExpiry <= 30
      );
      setLowStockItems(low);
      setExpiringItems(expiring);
      setReorderGroups(buildReorderGroups(nextProducts));

      setSummary((prev) => {
        const financials = calculateFinancialMetrics(nextProducts);
        return {
          totalProducts: nextProducts.length,
          totalInventoryQty: financials.totalInventoryQty,
          inventoryValueAtCost: financials.inventoryValueAtCost,
          expectedRetailTurnover: financials.expectedRetailTurnover,
          expectedGrossProfit: financials.expectedGrossProfit,
          grossProfitMarginPct: financials.grossProfitMarginPct,
          inventoryTurnoverRatio: prev?.inventoryTurnoverRatio ?? null,
          totalSalesCogs: prev?.totalSalesCogs ?? 0,
          lowStockCount: nextProducts.filter(
            (p) => p.stockStatus === 'LOW_STOCK'
          ).length,
          outOfStockCount: nextProducts.filter(
            (p) => p.stockStatus === 'OUT_OF_STOCK'
          ).length,
          expiringCount: nextProducts.filter(
            (p) =>
              p.expiryStatus === 'EXPIRING_7' ||
              p.expiryStatus === 'EXPIRING_15' ||
              p.expiryStatus === 'EXPIRING_30'
          ).length,
          expiredCount: nextProducts.filter(
            (p) => p.expiryStatus === 'EXPIRED'
          ).length,
          recentActivities: prev?.recentActivities ?? [],
        };
      });
    },
    []
  );

  const fetchAllData = useCallback(async () => {
    try {
      const [
        prods,
        cats,
        whs,
        profile,
        dash,
        low,
        exp,
        reorder,
        logs,
      ] = await Promise.all([
        api.getProducts(),
        api.getCategories(),
        api.getWholesalers(),
        api.getStoreProfile(),
        api.getDashboardSummary(),
        api.getLowStockAlerts(),
        api.getExpiringAlerts(30),
        api.getReorderGroups(),
        api.getStockLogs(),
      ]);
      setProducts(prods);
      setCategories(cats);
      setWholesalers(whs);
      setStoreProfile(profile);
      setSummary(dash);
      setLowStockItems(low);
      setExpiringItems(exp);
      setReorderGroups(reorder.groups);
      setStockLogs(logs);
    } catch {
      // Offline fallback from cached localStorage snapshot
      const cachedProds = loadProductsCache();
      if (cachedProds.length > 0) {
        setProducts(cachedProds);
        setCategories(loadCategoriesCache());
        setWholesalers(loadWholesalersCache());
        setStoreProfile(loadStoreProfileCache());
        recomputeLocalDerivedState(cachedProds);
      }
    } finally {
      setLoading(false);
    }
  }, [recomputeLocalDerivedState]);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  const syncInFlightRef = useRef(false);

  const runSync = useCallback(async () => {
    const queue = getPendingOperations();
    if (queue.length === 0 || !navigator.onLine || syncInFlightRef.current) {
      return;
    }

    syncInFlightRef.current = true;
    setIsSyncing(true);
    try {
      const results = await api.syncOfflineBatch(queue);
      const {
        remainingPending,
        newConflicts,
        appliedCount,
        duplicateCount,
        errorMessages,
      } = partitionSyncResults(queue, results);

      setPendingOperations(remainingPending);
      setPendingOpsState(remainingPending);

      if (newConflicts.length > 0) {
        const existingConflicts = getSyncConflicts();
        const existingIds = new Set(
          existingConflicts.map((c) => c.operation.operationId)
        );
        const merged = [
          ...existingConflicts,
          ...newConflicts.filter(
            (c) => !existingIds.has(c.operation.operationId)
          ),
        ];
        setSyncConflicts(merged);
        setConflictsState(merged);
        showToast(
          'warning',
          `${newConflicts.length} offline adjustment(s) flagged as conflict for manual review.`
        );
      } else if (appliedCount > 0 || duplicateCount > 0) {
        showToast(
          'success',
          `Synchronized ${appliedCount} offline stock change(s).`
        );
      }

      if (errorMessages.length > 0) {
        showToast('error', errorMessages[0]);
      }

      const nowIso = new Date().toISOString();
      setLastSyncTimestamp(nowIso);
      setLastSyncAtState(nowIso);

      await fetchAllData();
    } catch {
      // Keep pending queue safely intact
    } finally {
      syncInFlightRef.current = false;
      setIsSyncing(false);
    }
  }, [fetchAllData, showToast]);

  useEffect(() => {
    if (isOnline && pendingOps.length > 0) {
      runSync();
    }
  }, [isOnline, pendingOps.length, runSync]);

  const handleAdjustStock = async (product: ProductDTO, delta: number) => {
    if (product.currentQty + delta < 0) {
      showToast(
        'error',
        `Cannot reduce ${product.name} below 0. Available: ${product.currentQty}.`
      );
      return;
    }

    const operationId = generateOperationId();
    const txType = delta < 0 ? 'SALE' : 'RESTOCK';
    const prevSnapshot = [...products];

    // Optimistic UI update
    const updatedOptimistic = products.map((p) => {
      if (p.id !== product.id) return p;
      const updated = enrichProduct({
        ...p,
        currentQty: p.currentQty + delta,
        updatedAt: new Date().toISOString(),
      });
      return updated;
    });
    setProducts(updatedOptimistic);
    saveProductsCache(updatedOptimistic);
    recomputeLocalDerivedState(updatedOptimistic);

    if (selectedProduct?.id === product.id) {
      const updatedSelected = updatedOptimistic.find(
        (p) => p.id === product.id
      );
      if (updatedSelected) setSelectedProduct(updatedSelected);
    }

    if (!isOnline) {
      const queued = enqueuePendingOperation({
        operationId,
        productId: product.id,
        productName: product.name,
        sku: product.sku,
        delta,
        expectedPrevQty: product.currentQty,
        transactionType: txType,
        notes: 'Recorded offline on counter',
        createdAt: new Date().toISOString(),
      });
      setPendingOpsState(queued);
      showToast(
        'warning',
        `Offline: queued ${delta > 0 ? `+${delta}` : delta} for ${product.name}.`
      );
      return;
    }

    try {
      await api.adjustStock({
        productId: product.id,
        delta,
        transactionType: txType,
        operationId,
        notes:
          delta < 0
            ? `Quick sale (${delta})`
            : `Quick restock (+${delta})`,
      });
      await fetchAllData();
    } catch (err) {
      // Distinguish network drop vs validation error
      if (!navigator.onLine || err instanceof TypeError) {
        const queued = enqueuePendingOperation({
          operationId,
          productId: product.id,
          productName: product.name,
          sku: product.sku,
          delta,
          expectedPrevQty: product.currentQty,
          transactionType: txType,
          notes: 'Queued after network drop',
          createdAt: new Date().toISOString(),
        });
        setPendingOpsState(queued);
        showToast(
          'warning',
          `Connection lost: queued ${delta > 0 ? `+${delta}` : delta} for ${product.name}.`
        );
      } else {
        // Rollback optimistic change on server rejection
        setProducts(prevSnapshot);
        saveProductsCache(prevSnapshot);
        recomputeLocalDerivedState(prevSnapshot);
        showToast(
          'error',
          err instanceof Error ? err.message : 'Stock adjustment failed.'
        );
      }
    }
  };

  const handleSaveProduct = async (
    input: ProductInput,
    editingId?: number
  ) => {
    if (editingId) {
      await api.updateProduct(editingId, input);
      showToast('success', `Updated "${input.name}".`);
    } else {
      await api.createProduct(input);
      showToast('success', `Added "${input.name}" to catalog.`);
    }
    await fetchAllData();
  };

  const handleDeleteProduct = async (id: number) => {
    await api.deleteProduct(id);
    showToast('success', 'Product deleted from catalog.');
    await fetchAllData();
  };

  const handleResolveConflict = async (
    operationId: string,
    strategy: 'APPLY_DELTA' | 'OVERWRITE_LOCAL' | 'DISCARD'
  ) => {
    const target = conflicts.find(
      (c) => c.operation.operationId === operationId
    );
    if (!target) return;

    if (strategy === 'DISCARD') {
      const next = conflicts.filter(
        (c) => c.operation.operationId !== operationId
      );
      setSyncConflicts(next);
      setConflictsState(next);
      showToast('success', 'Discarded conflicting offline change.');
      return;
    }

    const opPayload: OfflineSyncOperation = {
      ...target.operation,
      resolutionMode: strategy,
      localTargetQty: Math.max(
        0,
        target.operation.expectedPrevQty + target.operation.delta
      ),
    };

    try {
      const results = await api.syncOfflineBatch([opPayload]);
      const res = results[0];
      if (res && (res.status === 'APPLIED' || res.status === 'DUPLICATE_IGNORED')) {
        const next = conflicts.filter(
          (c) => c.operation.operationId !== operationId
        );
        setSyncConflicts(next);
        setConflictsState(next);
        showToast('success', `Conflict resolved for ${target.operation.productName}.`);
        await fetchAllData();
      } else {
        showToast('error', res?.message || 'Unable to resolve conflict.');
      }
    } catch (err) {
      showToast(
        'error',
        err instanceof Error ? err.message : 'Conflict resolution failed.'
      );
    }
  };

  const handleDiscardPending = (operationId: string) => {
    const next = pendingOps.filter((o) => o.operationId !== operationId);
    setPendingOperations(next);
    setPendingOpsState(next);
  };

  const reorderCount = reorderGroups.reduce(
    (sum, g) => sum + g.items.length,
    0
  );
  const syncBadgeCount = pendingOps.length + conflicts.length;

  const navItems: Array<{
    id: ActiveTab;
    label: string;
    icon: React.ComponentType<{className?: string}>;
    badge?: number;
  }> = [
    {id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard},
    {id: 'inventory', label: 'Inventory', icon: Package},
    {
      id: 'reorder',
      label: 'Reorder',
      icon: ShoppingCart,
      badge: reorderCount > 0 ? reorderCount : undefined,
    },
    {
      id: 'expiry',
      label: 'Expiry Tracker',
      icon: Clock,
      badge: expiringItems.length > 0 ? expiringItems.length : undefined,
    },
    {id: 'ledger', label: 'Stock Ledger', icon: FileText},
    {id: 'settings', label: 'Store & Suppliers', icon: Settings},
  ];

  const tabTitles: Record<ActiveTab, string> = {
    dashboard: 'Store Dashboard',
    inventory: 'Product Catalog & Stock',
    reorder: 'Smart Reorder Assistant',
    expiry: 'Perishable Expiry Tracker',
    ledger: 'Stock Audit Ledger',
    settings: 'Store Profile & Wholesalers',
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col md:flex-row">
      {/* Desktop Left Sidebar */}
      <aside className="hidden md:flex md:w-60 md:flex-col md:fixed md:inset-y-0 border-r border-slate-200 bg-white">
        <div className="flex h-16 items-center px-6 border-b border-slate-200">
          <span className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
            StockSherpa
          </span>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1" aria-label="Main navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setInventoryStatusFilter('ALL');
                  setActiveTab(item.id);
                }}
                className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium transition-colors cursor-pointer ${
                  active
                    ? 'bg-emerald-50 text-emerald-800 font-semibold'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <span className="flex items-center gap-2.5 whitespace-nowrap">
                  <Icon
                    className={`h-4 w-4 ${
                      active ? 'text-emerald-600' : 'text-slate-400'
                    }`}
                  />
                  <span>{item.label}</span>
                </span>
                {item.badge !== undefined && (
                  <span className="font-mono text-xs font-semibold text-red-600 tabular-nums">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-200 p-4 space-y-2">
          <button
            type="button"
            onClick={() => setScannerOpen(true)}
            className="flex w-full items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            <ScanBarcode className="h-4 w-4 text-emerald-600" />
            <span>Barcode Scanner</span>
          </button>

          {(syncBadgeCount > 0 || !isOnline) && (
            <button
              type="button"
              onClick={() => setSyncDrawerOpen(true)}
              className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-xs font-semibold cursor-pointer ${
                conflicts.length > 0
                  ? 'bg-red-50 text-red-700 border border-red-200'
                  : 'bg-amber-50 text-amber-800 border border-amber-200'
              }`}
            >
              <span className="flex items-center gap-1.5">
                <RefreshCw className="h-3.5 w-3.5" />
                <span>Sync Queue</span>
              </span>
              <span className="font-mono tabular-nums">{syncBadgeCount}</span>
            </button>
          )}
        </div>
      </aside>

      {/* Main Content Shell */}
      <div className="flex-1 md:pl-60 flex flex-col min-w-0">
        {/* Top Bar Contract: Compact Mobile (52px) + Clean Desktop (64px) */}
        <header className="sticky top-0 z-30 flex h-[52px] md:h-16 items-center justify-between gap-4 border-b border-slate-200 bg-white/95 backdrop-blur-md px-4 md:px-8">
          <div className="flex items-center gap-3 min-w-0">
            <span className="md:hidden font-display text-base font-bold text-slate-900 whitespace-nowrap shrink-0">
              StockSherpa
            </span>
            <h1 className="hidden md:block text-base font-bold text-slate-900 truncate">
              {tabTitles[activeTab]}
            </h1>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            {!isOnline && (
              <button
                type="button"
                onClick={() => setSyncDrawerOpen(true)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-amber-300 bg-amber-50 px-2.5 py-1.5 text-xs font-semibold text-amber-900 cursor-pointer whitespace-nowrap"
              >
                <WifiOff className="h-3.5 w-3.5" />
                <span>Offline ({pendingOps.length})</span>
              </button>
            )}

            {isOnline && syncBadgeCount > 0 && (
              <button
                type="button"
                onClick={() => setSyncDrawerOpen(true)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-red-300 bg-red-50 px-2.5 py-1.5 text-xs font-semibold text-red-700 cursor-pointer whitespace-nowrap"
              >
                <AlertTriangle className="h-3.5 w-3.5" />
                <span>Sync Review ({syncBadgeCount})</span>
              </button>
            )}

            <PWAInstallButton />

            <button
              type="button"
              onClick={() => {
                setEditingProduct(null);
                setPrefillBarcode(undefined);
                setProductModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <Plus className="h-4 w-4" />
              <span>Add Product</span>
            </button>
          </div>
        </header>

        {/* Main Viewport */}
        <main className="flex-1 p-4 pb-20 md:p-8 md:pb-10 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              summary={summary}
              lowStockItems={lowStockItems}
              expiringItems={expiringItems}
              isLoading={loading}
              onNavigate={(tab) => {
                setInventoryStatusFilter('ALL');
                setActiveTab(tab);
              }}
              onQuickFilterLowStock={() => {
                setInventoryStatusFilter('LOW_STOCK');
                setActiveTab('inventory');
              }}
            />
          )}

          {activeTab === 'inventory' && (
            <InventoryView
              products={products}
              categories={categories}
              initialStatusFilter={inventoryStatusFilter}
              onAdjustStock={handleAdjustStock}
              onViewProduct={setSelectedProduct}
              onEditProduct={(p) => {
                setEditingProduct(p);
                setPrefillBarcode(undefined);
                setProductModalOpen(true);
              }}
              onAddProduct={() => {
                setEditingProduct(null);
                setPrefillBarcode(undefined);
                setProductModalOpen(true);
              }}
              onOpenScanner={() => setScannerOpen(true)}
              onOpenTemplates={() => setTemplatesOpen(true)}
            />
          )}

          {activeTab === 'reorder' && (
            <ReorderView
              groups={reorderGroups}
              storeProfile={storeProfile}
              onRefresh={fetchAllData}
            />
          )}

          {activeTab === 'expiry' && (
            <ExpiryView
              products={products}
              onViewProduct={setSelectedProduct}
            />
          )}

          {activeTab === 'ledger' && (
            <StockLedgerView logs={stockLogs} onRefresh={fetchAllData} />
          )}

          {activeTab === 'settings' && (
            <SettingsAndWholesalersView
              storeProfile={storeProfile}
              wholesalers={wholesalers}
              onProfileUpdated={setStoreProfile}
              onWholesalersUpdated={fetchAllData}
            />
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar (< 768px) — Fixed 56px height */}
      <nav
        aria-label="Mobile navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-14 border-t border-slate-200 bg-white/95 backdrop-blur-md grid grid-cols-5 items-center"
      >
        <button
          type="button"
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center justify-center h-full text-[10px] font-medium cursor-pointer ${
            activeTab === 'dashboard' ? 'text-emerald-700 font-semibold' : 'text-slate-500'
          }`}
        >
          <LayoutDashboard className="h-5 w-5" />
          <span className="mt-0.5">Home</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('inventory')}
          className={`flex flex-col items-center justify-center h-full text-[10px] font-medium cursor-pointer ${
            activeTab === 'inventory' ? 'text-emerald-700 font-semibold' : 'text-slate-500'
          }`}
        >
          <Package className="h-5 w-5" />
          <span className="mt-0.5">Stock</span>
        </button>

        <button
          type="button"
          onClick={() => setScannerOpen(true)}
          className="flex flex-col items-center justify-center h-full text-[10px] font-medium text-emerald-700 cursor-pointer"
        >
          <ScanBarcode className="h-5 w-5" />
          <span className="mt-0.5">Scan</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('reorder')}
          className={`relative flex flex-col items-center justify-center h-full text-[10px] font-medium cursor-pointer ${
            activeTab === 'reorder' ? 'text-emerald-700 font-semibold' : 'text-slate-500'
          }`}
        >
          <ShoppingCart className="h-5 w-5" />
          <span className="mt-0.5">Reorder</span>
          {reorderCount > 0 && (
            <span className="absolute top-1.5 right-3 font-mono text-[9px] font-bold text-red-600">
              {reorderCount}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setMobileMoreOpen(true)}
          className="flex flex-col items-center justify-center h-full text-[10px] font-medium text-slate-500 cursor-pointer"
        >
          <Menu className="h-5 w-5" />
          <span className="mt-0.5">More</span>
        </button>
      </nav>

      {/* Mobile More Menu Sheet */}
      {mobileMoreOpen && (
        <div
          className="md:hidden fixed inset-0 z-50 flex items-end bg-slate-900/50"
          onClick={() => setMobileMoreOpen(false)}
        >
          <div
            className="w-full rounded-t-3xl bg-white p-5 space-y-2"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-slate-200" />
            <button
              type="button"
              onClick={() => {
                setActiveTab('expiry');
                setMobileMoreOpen(false);
              }}
              className="flex w-full items-center justify-between rounded-xl px-4 py-3 text-sm font-semibold text-slate-800 hover:bg-slate-50"
            >
              <span className="flex items-center gap-3">
                <Clock className="h-4 w-4 text-amber-600" />
                <span>Expiry Tracker</span>
              </span>
              <span className="font-mono text-xs text-slate-500">
                {expiringItems.length}
              </span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('ledger');
                setMobileMoreOpen(false);
              }}
              className="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold text-slate-800 hover:bg-slate-50"
            >
              <FileText className="h-4 w-4 text-slate-600" />
              <span>Stock Ledger</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('settings');
                setMobileMoreOpen(false);
              }}
              className="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold text-slate-800 hover:bg-slate-50"
            >
              <Settings className="h-4 w-4 text-slate-600" />
              <span>Store Profile & Suppliers</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setSyncDrawerOpen(true);
                setMobileMoreOpen(false);
              }}
              className="flex w-full items-center justify-between rounded-xl px-4 py-3 text-sm font-semibold text-slate-800 hover:bg-slate-50"
            >
              <span className="flex items-center gap-3">
                <RefreshCw className="h-4 w-4 text-emerald-600" />
                <span>Offline Sync Queue</span>
              </span>
              <span className="font-mono text-xs text-slate-500">
                {syncBadgeCount}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {toast && (
        <div
          role="status"
          className={`fixed bottom-16 md:bottom-5 right-4 z-50 flex items-center gap-2.5 rounded-xl border px-4 py-3 text-xs font-semibold shadow-lg ${
            toast.type === 'error'
              ? 'border-red-200 bg-red-50 text-red-800'
              : toast.type === 'warning'
                ? 'border-amber-200 bg-amber-50 text-amber-900'
                : 'border-emerald-200 bg-emerald-50 text-emerald-900'
          }`}
        >
          <span>{toast.message}</span>
          <button
            type="button"
            onClick={() => setToast(null)}
            className="rounded p-0.5 hover:bg-black/5 cursor-pointer"
            aria-label="Dismiss notification"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* Modals & Drawers */}
      <ProductModal
        isOpen={productModalOpen}
        editingProduct={editingProduct}
        prefillBarcode={prefillBarcode}
        categories={categories}
        wholesalers={wholesalers}
        onClose={() => setProductModalOpen(false)}
        onSubmit={handleSaveProduct}
      />

      <ProductDetailDrawer
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onEdit={(p) => {
          setEditingProduct(p);
          setPrefillBarcode(undefined);
          setProductModalOpen(true);
        }}
        onDelete={handleDeleteProduct}
        onAdjustStock={handleAdjustStock}
      />

      <TemplateLibraryModal
        isOpen={templatesOpen}
        onClose={() => setTemplatesOpen(false)}
        onImported={fetchAllData}
      />

      <BarcodeScannerModal
        isOpen={scannerOpen}
        products={products}
        onClose={() => setScannerOpen(false)}
        onSelectProduct={setSelectedProduct}
        onAddProductWithBarcode={(code) => {
          setEditingProduct(null);
          setPrefillBarcode(code);
          setProductModalOpen(true);
        }}
        onAdjustStock={handleAdjustStock}
      />

      <SyncQueueDrawer
        isOpen={syncDrawerOpen}
        isOnline={isOnline}
        isSyncing={isSyncing}
        pendingOps={pendingOps}
        conflicts={conflicts}
        lastSyncAt={lastSyncAt}
        onClose={() => setSyncDrawerOpen(false)}
        onSyncNow={runSync}
        onResolveConflict={handleResolveConflict}
        onDiscardPending={handleDiscardPending}
      />
    </div>
  );
};
