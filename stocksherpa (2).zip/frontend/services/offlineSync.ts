import type {
  Category,
  OfflineSyncOperation,
  ProductDTO,
  StoreProfile,
  SyncOperationResult,
  Wholesaler,
} from '../../shared/types.ts';

const KEYS = {
  PRODUCTS_CACHE: 'stocksherpa_products_cache_v1',
  CATEGORIES_CACHE: 'stocksherpa_categories_cache_v1',
  WHOLESALERS_CACHE: 'stocksherpa_wholesalers_cache_v1',
  STORE_PROFILE_CACHE: 'stocksherpa_store_profile_v1',
  PENDING_OPS: 'stocksherpa_pending_ops_v1',
  CONFLICTS: 'stocksherpa_sync_conflicts_v1',
  LAST_SYNC: 'stocksherpa_last_sync_v1',
};

export interface SyncConflictItem {
  operation: OfflineSyncOperation;
  serverQty: number;
  message: string;
}

export function generateOperationId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `op-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function safeReadJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function safeWriteJson(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Ignore quota errors gracefully
  }
}

export function saveProductsCache(products: ProductDTO[]): void {
  safeWriteJson(KEYS.PRODUCTS_CACHE, products);
}

export function loadProductsCache(): ProductDTO[] {
  return safeReadJson<ProductDTO[]>(KEYS.PRODUCTS_CACHE, []);
}

export function saveCategoriesCache(categories: Category[]): void {
  safeWriteJson(KEYS.CATEGORIES_CACHE, categories);
}

export function loadCategoriesCache(): Category[] {
  return safeReadJson<Category[]>(KEYS.CATEGORIES_CACHE, []);
}

export function saveWholesalersCache(wholesalers: Wholesaler[]): void {
  safeWriteJson(KEYS.WHOLESALERS_CACHE, wholesalers);
}

export function loadWholesalersCache(): Wholesaler[] {
  return safeReadJson<Wholesaler[]>(KEYS.WHOLESALERS_CACHE, []);
}

export function saveStoreProfileCache(profile: StoreProfile): void {
  safeWriteJson(KEYS.STORE_PROFILE_CACHE, profile);
}

export function loadStoreProfileCache(): StoreProfile | null {
  return safeReadJson<StoreProfile | null>(KEYS.STORE_PROFILE_CACHE, null);
}

export function getPendingOperations(): OfflineSyncOperation[] {
  return safeReadJson<OfflineSyncOperation[]>(KEYS.PENDING_OPS, []);
}

export function enqueuePendingOperation(op: OfflineSyncOperation): OfflineSyncOperation[] {
  const current = getPendingOperations();
  const next = [...current, op];
  safeWriteJson(KEYS.PENDING_OPS, next);
  return next;
}

export function setPendingOperations(ops: OfflineSyncOperation[]): void {
  safeWriteJson(KEYS.PENDING_OPS, ops);
}

export function getSyncConflicts(): SyncConflictItem[] {
  return safeReadJson<SyncConflictItem[]>(KEYS.CONFLICTS, []);
}

export function setSyncConflicts(conflicts: SyncConflictItem[]): void {
  safeWriteJson(KEYS.CONFLICTS, conflicts);
}

export function getLastSyncTimestamp(): string | null {
  return localStorage.getItem(KEYS.LAST_SYNC);
}

export function setLastSyncTimestamp(iso: string): void {
  localStorage.setItem(KEYS.LAST_SYNC, iso);
}

export function partitionSyncResults(
  sentOps: OfflineSyncOperation[],
  results: SyncOperationResult[]
): {
  remainingPending: OfflineSyncOperation[];
  newConflicts: SyncConflictItem[];
  appliedCount: number;
  duplicateCount: number;
  errorMessages: string[];
} {
  const opMap = new Map(sentOps.map((o) => [o.operationId, o]));
  const remainingPending: OfflineSyncOperation[] = [];
  const newConflicts: SyncConflictItem[] = [];
  let appliedCount = 0;
  let duplicateCount = 0;
  const errorMessages: string[] = [];

  for (const res of results) {
    const op = opMap.get(res.operationId);
    if (!op) continue;

    if (res.status === 'APPLIED') {
      appliedCount += 1;
    } else if (res.status === 'DUPLICATE_IGNORED') {
      duplicateCount += 1;
    } else if (res.status === 'CONFLICT') {
      newConflicts.push({
        operation: op,
        serverQty: res.serverQty ?? op.expectedPrevQty,
        message: res.message,
      });
    } else {
      errorMessages.push(`${op.productName}: ${res.message}`);
      remainingPending.push(op);
    }
  }

  return {
    remainingPending,
    newConflicts,
    appliedCount,
    duplicateCount,
    errorMessages,
  };
}
