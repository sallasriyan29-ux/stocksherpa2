import type {
  CatalogTemplate,
  Category,
  DashboardSummary,
  OfflineSyncOperation,
  ProductDTO,
  ProductInput,
  PurchaseOrderRecord,
  StockLog,
  StoreProfile,
  SyncOperationResult,
  TransactionType,
  Wholesaler,
  WholesalerOrderGroup,
} from '../../shared/types.ts';
import {
  saveCategoriesCache,
  saveProductsCache,
  saveStoreProfileCache,
  saveWholesalersCache,
} from './offlineSync.ts';

export class ApiError extends Error {
  status: number;
  code?: string;

  constructor(status: number, message: string, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
    ...init,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ApiError(
      res.status,
      data.error || `Request failed (${res.status})`,
      data.code
    );
  }
  return data as T;
}

export const api = {
  async getProducts(): Promise<ProductDTO[]> {
    const data = await requestJson<{products: ProductDTO[]}>('/api/products');
    saveProductsCache(data.products);
    return data.products;
  },

  async createProduct(input: ProductInput): Promise<ProductDTO> {
    const data = await requestJson<{product: ProductDTO}>('/api/products', {
      method: 'POST',
      body: JSON.stringify(input),
    });
    return data.product;
  },

  async updateProduct(id: number, input: ProductInput): Promise<ProductDTO> {
    const data = await requestJson<{product: ProductDTO}>(`/api/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(input),
    });
    return data.product;
  },

  async deleteProduct(id: number): Promise<void> {
    await requestJson(`/api/products/${id}`, {method: 'DELETE'});
  },

  async adjustStock(params: {
    productId: number;
    delta: number;
    transactionType: TransactionType;
    operationId: string;
    notes?: string;
  }): Promise<{product: ProductDTO; log: StockLog | null; duplicateIgnored: boolean}> {
    return requestJson('/api/stock/adjust', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async syncOfflineBatch(
    operations: OfflineSyncOperation[]
  ): Promise<SyncOperationResult[]> {
    const data = await requestJson<{results: SyncOperationResult[]}>(
      '/api/stock/sync',
      {
        method: 'POST',
        body: JSON.stringify({operations}),
      }
    );
    return data.results;
  },

  async getStockLogs(productId?: number): Promise<StockLog[]> {
    const url = productId
      ? `/api/stock/logs/${productId}`
      : '/api/stock/logs?limit=100';
    const data = await requestJson<{logs: StockLog[]}>(url);
    return data.logs;
  },

  async getDashboardSummary(): Promise<DashboardSummary> {
    const data = await requestJson<{summary: DashboardSummary}>(
      '/api/dashboard/summary'
    );
    return data.summary;
  },

  async getLowStockAlerts(): Promise<ProductDTO[]> {
    const data = await requestJson<{items: ProductDTO[]}>('/api/alerts/low-stock');
    return data.items;
  },

  async getExpiringAlerts(days = 30): Promise<ProductDTO[]> {
    const data = await requestJson<{items: ProductDTO[]}>(
      `/api/alerts/expiring?days=${days}`
    );
    return data.items;
  },

  async getReorderGroups(): Promise<{
    groups: WholesalerOrderGroup[];
    totalItems: number;
    totalEstimatedCost: number;
  }> {
    return requestJson('/api/reorder');
  },

  async generatePurchaseOrder(payload: {
    wholesalerId: number | null;
    wholesalerName: string;
    wholesalerPhone: string;
    status: 'DRAFT' | 'DISPATCHED';
    items: Array<{productId: number; qtyOrdered: number}>;
  }): Promise<{order: PurchaseOrderRecord; whatsappUrl: string}> {
    return requestJson('/api/reorder/generate', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async getPurchaseOrders(): Promise<PurchaseOrderRecord[]> {
    const data = await requestJson<{orders: PurchaseOrderRecord[]}>(
      '/api/reorder/orders'
    );
    return data.orders;
  },

  async markOrderDispatched(orderId: number): Promise<PurchaseOrderRecord> {
    const data = await requestJson<{order: PurchaseOrderRecord}>(
      `/api/reorder/orders/${orderId}/dispatch`,
      {method: 'PATCH'}
    );
    return data.order;
  },

  async getCategories(): Promise<Category[]> {
    const data = await requestJson<{categories: Category[]}>('/api/categories');
    saveCategoriesCache(data.categories);
    return data.categories;
  },

  async getWholesalers(): Promise<Wholesaler[]> {
    const data = await requestJson<{wholesalers: Wholesaler[]}>('/api/wholesalers');
    saveWholesalersCache(data.wholesalers);
    return data.wholesalers;
  },

  async createWholesaler(input: {
    name: string;
    phone: string;
    contactPerson?: string;
    notes?: string;
  }): Promise<Wholesaler> {
    const data = await requestJson<{wholesaler: Wholesaler}>('/api/wholesalers', {
      method: 'POST',
      body: JSON.stringify(input),
    });
    return data.wholesaler;
  },

  async updateWholesaler(
    id: number,
    input: {
      name: string;
      phone: string;
      contactPerson?: string;
      notes?: string;
    }
  ): Promise<Wholesaler> {
    const data = await requestJson<{wholesaler: Wholesaler}>(
      `/api/wholesalers/${id}`,
      {
        method: 'PUT',
        body: JSON.stringify(input),
      }
    );
    return data.wholesaler;
  },

  async getTemplates(): Promise<Array<CatalogTemplate & {alreadyInStore: boolean}>> {
    const data = await requestJson<{
      templates: Array<CatalogTemplate & {alreadyInStore: boolean}>;
    }>('/api/templates');
    return data.templates;
  },

  async importTemplate(sku: string): Promise<ProductDTO> {
    const data = await requestJson<{product: ProductDTO}>(
      `/api/templates/${encodeURIComponent(sku)}/import`,
      {method: 'POST'}
    );
    return data.product;
  },

  async getStoreProfile(): Promise<StoreProfile> {
    const data = await requestJson<{profile: StoreProfile}>('/api/store-profile');
    saveStoreProfileCache(data.profile);
    return data.profile;
  },

  async updateStoreProfile(input: {
    shopName: string;
    ownerName: string;
    phone: string;
    address: string;
    gstin: string | null;
  }): Promise<StoreProfile> {
    const data = await requestJson<{profile: StoreProfile}>('/api/store-profile', {
      method: 'PUT',
      body: JSON.stringify(input),
    });
    saveStoreProfileCache(data.profile);
    return data.profile;
  },
};
